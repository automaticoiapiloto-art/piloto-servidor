/*
 * popup.js — lógica do painel lateral.
 * Fonte de verdade da config: chrome.storage.local 'piloto_config_v1'.
 * Métricas e status vêm do content script via runtime.
 */
(() => {
  'use strict';

  const KEY = 'piloto_config_v1';
  const KEY_LIC = 'piloto_license_key';
  let cfg = null;

  const $ = (id) => document.getElementById(id);

  // ---------- abas ----------
  function abaAtivar(nome) {
    for (const btn of document.querySelectorAll('.aba')) btn.classList.toggle('ativa', btn.dataset.aba === nome);
    for (const t of document.querySelectorAll('.tela')) t.classList.toggle('ativa', t.id === 'tela-' + nome);
  }
  for (const btn of document.querySelectorAll('.aba')) {
    btn.addEventListener('click', () => abaAtivar(btn.dataset.aba));
  }

  // ---------- config: carregar / gravar ----------
  async function carregar() {
    const r = await chrome.storage.local.get(KEY);
    cfg = r[KEY] || {};
    renderTudo();
  }
  function fundir(dst, src) {
    for (const k of Object.keys(src)) {
      const v = src[k];
      if (v && typeof v === 'object' && !Array.isArray(v) && dst[k] && typeof dst[k] === 'object' && !Array.isArray(dst[k])) fundir(dst[k], v);
      else dst[k] = v;
    }
    return dst;
  }
  async function salvar(patch) {
    if (!cfg) cfg = {};
    fundir(cfg, patch);
    await chrome.storage.local.set({ [KEY]: cfg });
  }
  function ler(path, fb) {
    let cur = cfg || {};
    for (const p of path.split('.')) { if (cur == null) return fb; cur = cur[p]; }
    return cur == null ? fb : cur;
  }
  const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

  // ---------- render tudo ----------
  function renderTudo() {
    // chat
    $('broadcast-enabled').checked = !!ler('chat.broadcast.enabled', false);
    $('broadcast-min').value = ler('chat.broadcast.minSec', 60);
    $('broadcast-max').value = ler('chat.broadcast.maxSec', 180);
    $('broadcast-random').checked = ler('chat.broadcast.randomize', true);
    renderMsgs();
    $('qa-enabled').checked = !!ler('chat.qa.enabled', false);
    renderQA();
    $('sale-enabled').checked = !!ler('chat.saleAlert.enabled', false);
    $('sale-tpl').value = ler('chat.saleAlert.template', 'Vendido para {nome}!');
    $('cart-enabled').checked = !!ler('chat.cartAlert.enabled', false);
    $('cart-tpl').value = ler('chat.cartAlert.template', '{nome} adicionou ao carrinho!');
    // IA
    $('ia-enabled').checked = !!ler('chat.ia.enabled', false);
    $('ia-produto').value = ler('chat.ia.produto', '');
    $('ia-faq').value = ler('chat.ia.faq', '');
    $('ia-palavras').value = ler('chat.ia.palavrasChave', '');
    // vitrine
    $('repin-enabled').checked = !!ler('rePin.enabled', false);
    $('repin-modo').value = ler('rePin.modo', 'produto');
    $('repin-intervalo').value = ler('rePin.intervalSec', 10);
    $('repin-piscar').checked = !!ler('rePin.blink', false);
    $('repin-aleatorio').checked = !!ler('rePin.aleatorio', false);
    $('kit-enabled').checked = !!ler('vitrineKit.enabled', false);
    $('kit-id').value = ler('vitrineKit.setId', '');
    $('kit-nome').value = ler('vitrineKit.setNome', '');
    $('flash-enabled').checked = !!ler('flashOffer.enabled', false);
    // vcam
    $('vcam-enabled').checked = !!ler('vcam.enabled', false);
    $('vcam-loop').checked = ler('vcam.loop', true);
    renderVideos();
    // simulive
    $('autostart-enabled').checked = !!ler('autoStart.enabled', false);
    renderSerie();
    $('autoend-enabled').checked = !!ler('autoEnd.enabled', false);
    if (ler('autoEnd.endAtTs', 0)) {
      const dt = new Date(ler('autoEnd.endAtTs', 0));
      const s = dt.toISOString().slice(0, 16);
      $('autoend-dt').value = s;
    }
    // espelho
    $('espelho-enabled').checked = !!ler('espelho.enabled', false);
    $('espelho-pin').value = ler('espelho.pin', '');
    renderQR();
    // cfg
    $('cfg-plataforma').value = ler('plataforma', 'tiktok-shop');
    $('mod-enabled').checked = !!ler('moderacao.enabled', false);
    $('mod-palavras').value = (ler('moderacao.palavras', []) || []).join(', ');
    $('tap-enabled').checked = !!ler('tap.enabled', false);
    $('tap-intervalo').value = ler('tap.intervaloSeg', 30);
    $('guardiao-aviso').checked = !!ler('seguranca.guardiaoAviso', false);
    $('chat-liberado-toggle').checked = ler('seguranca.chatOpen', null) === true;
    // licença
    chrome.storage.local.get(KEY_LIC).then((r) => { $('lic-key').value = r[KEY_LIC] || ''; });
    $('lic-servidor').value = ler('licenca.servidor', '');
  }

  // ---------- listas: msgs, qa, serie, videos ----------
  function renderMsgs() {
    const ul = $('msgs-lista'); ul.innerHTML = '';
    for (const m of (ler('chat.broadcast.messages', []) || [])) {
      const li = document.createElement('li');
      li.innerHTML = `
        <input type="checkbox" ${m.enabled === false ? '' : 'checked'} data-id="${m.id}" class="on">
        <input type="text" value="${esc(m.text)}" data-id="${m.id}" class="txt" placeholder="Mensagem para o chat">
        <button class="secundaria del" data-id="${m.id}">×</button>`;
      ul.appendChild(li);
    }
    for (const i of ul.querySelectorAll('.on')) i.onchange = () => patchMsg(i.dataset.id, { enabled: i.checked });
    for (const i of ul.querySelectorAll('.txt')) i.onchange = () => patchMsg(i.dataset.id, { text: i.value });
    for (const b of ul.querySelectorAll('.del')) b.onclick = () => delMsg(b.dataset.id);
  }
  function patchMsg(id, patch) {
    const arr = (ler('chat.broadcast.messages', []) || []).map((m) => m.id === id ? Object.assign({}, m, patch) : m);
    salvar({ chat: { broadcast: { messages: arr } } });
  }
  function delMsg(id) {
    const arr = (ler('chat.broadcast.messages', []) || []).filter((m) => m.id !== id);
    cfg.chat = cfg.chat || {}; cfg.chat.broadcast = cfg.chat.broadcast || {}; cfg.chat.broadcast.messages = arr;
    chrome.storage.local.set({ [KEY]: cfg }).then(renderMsgs);
  }
  $('btn-add-msg').onclick = () => {
    const arr = (ler('chat.broadcast.messages', []) || []).slice();
    arr.push({ id: 'm' + Date.now(), text: '', enabled: true });
    salvar({ chat: { broadcast: { messages: arr } } }).then(renderMsgs);
  };

  function renderQA() {
    const ul = $('qa-lista'); ul.innerHTML = '';
    for (const q of (ler('chat.qa.respostas', []) || [])) {
      const li = document.createElement('li');
      li.innerHTML = `
        <input type="text" placeholder="gatilhos separados por vírgula" value="${esc((q.gatilhos || []).join(', '))}" data-id="${q.id}" class="g">
        <input type="text" placeholder="resposta" value="${esc(q.resposta)}" data-id="${q.id}" class="r">
        <button class="secundaria del" data-id="${q.id}">×</button>`;
      ul.appendChild(li);
    }
    for (const i of ul.querySelectorAll('.g')) i.onchange = () => patchQA(i.dataset.id, { gatilhos: i.value.split(',').map((s) => s.trim()).filter(Boolean) });
    for (const i of ul.querySelectorAll('.r')) i.onchange = () => patchQA(i.dataset.id, { resposta: i.value });
    for (const b of ul.querySelectorAll('.del')) b.onclick = () => delQA(b.dataset.id);
  }
  function patchQA(id, patch) {
    const arr = (ler('chat.qa.respostas', []) || []).map((q) => q.id === id ? Object.assign({}, q, patch) : q);
    salvar({ chat: { qa: { respostas: arr } } });
  }
  function delQA(id) {
    const arr = (ler('chat.qa.respostas', []) || []).filter((q) => q.id !== id);
    cfg.chat = cfg.chat || {}; cfg.chat.qa = cfg.chat.qa || {}; cfg.chat.qa.respostas = arr;
    chrome.storage.local.set({ [KEY]: cfg }).then(renderQA);
  }
  $('btn-add-qa').onclick = () => {
    const arr = (ler('chat.qa.respostas', []) || []).slice();
    arr.push({ id: 'q' + Date.now(), gatilhos: [], resposta: '', enabled: true });
    salvar({ chat: { qa: { respostas: arr } } }).then(renderQA);
  };

  async function renderVideos() {
    const ul = $('vcam-lista'); ul.innerHTML = '';
    try {
      const db = await abrirDB();
      const tx = db.transaction('videos', 'readonly');
      const req = tx.objectStore('videos').getAll();
      req.onsuccess = () => {
        const idAtual = ler('vcam.videoId', '');
        for (const v of req.result || []) {
          const li = document.createElement('li');
          li.innerHTML = `
            <input type="radio" name="vcam-sel" value="${v.id}" ${v.id === idAtual ? 'checked' : ''}>
            <span style="flex:1">${esc(v.name || v.id)}</span>
            <button class="secundaria del-video" data-id="${v.id}">×</button>`;
          ul.appendChild(li);
        }
        for (const r of ul.querySelectorAll('input[name="vcam-sel"]')) r.onchange = () => salvar({ vcam: { videoId: r.value } });
        for (const b of ul.querySelectorAll('.del-video')) b.onclick = () => apagarVideo(b.dataset.id);
      };
    } catch (_) {}
  }
  async function apagarVideo(id) {
    const db = await abrirDB();
    const tx = db.transaction('videos', 'readwrite');
    tx.objectStore('videos').delete(id);
    tx.oncomplete = () => { if (ler('vcam.videoId', '') === id) salvar({ vcam: { videoId: '' } }); renderVideos(); };
  }

  function renderSerie() {
    const ul = $('serie-lista'); ul.innerHTML = '';
    for (const s of (ler('autoStart.series', []) || [])) {
      const dtI = s.tsInicio ? new Date(s.tsInicio - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '';
      const dtF = s.tsFim ? new Date(s.tsFim - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '';
      const li = document.createElement('li');
      li.innerHTML = `
        <div style="display:grid;grid-template-columns:1fr;gap:8px;width:100%">
          <input type="text" placeholder="nome (ex: Live CRIE) — opcional" value="${esc(s.nome || '')}" data-id="${s.id}" class="s-nome">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <label style="margin:0;font-size:11px;color:var(--tx2)">Início
              <input type="datetime-local" value="${dtI}" data-id="${s.id}" class="s-ini">
            </label>
            <label style="margin:0;font-size:11px;color:var(--tx2)">Fim
              <input type="datetime-local" value="${dtF}" data-id="${s.id}" class="s-fim">
            </label>
          </div>
          <input type="text" placeholder="videoId (opcional — pra trocar a câmera virtual)" value="${esc(s.videoId || '')}" data-id="${s.id}" class="s-v">
          <button class="secundaria del" data-id="${s.id}" style="align-self:flex-start">Remover</button>
        </div>`;
      ul.appendChild(li);
    }
    for (const i of ul.querySelectorAll('.s-nome')) i.onchange = () => patchSerie(i.dataset.id, { nome: i.value });
    for (const i of ul.querySelectorAll('.s-ini')) i.onchange = () => patchSerie(i.dataset.id, { tsInicio: i.value ? new Date(i.value).getTime() : 0, disparado: false });
    for (const i of ul.querySelectorAll('.s-fim')) i.onchange = () => patchSerie(i.dataset.id, { tsFim: i.value ? new Date(i.value).getTime() : 0, encerradoDisparado: false });
    for (const i of ul.querySelectorAll('.s-v')) i.onchange = () => patchSerie(i.dataset.id, { videoId: i.value });
    for (const b of ul.querySelectorAll('.del')) b.onclick = () => delSerie(b.dataset.id);
  }
  function patchSerie(id, patch) {
    const arr = (ler('autoStart.series', []) || []).map((s) => s.id === id ? Object.assign({}, s, patch) : s);
    salvar({ autoStart: { series: arr } });
  }
  function delSerie(id) {
    const arr = (ler('autoStart.series', []) || []).filter((s) => s.id !== id);
    cfg.autoStart = cfg.autoStart || {}; cfg.autoStart.series = arr;
    chrome.storage.local.set({ [KEY]: cfg }).then(renderSerie);
  }
  $('btn-add-serie').onclick = () => {
    const arr = (ler('autoStart.series', []) || []).slice();
    arr.push({ id: 's' + Date.now(), nome: '', tsInicio: 0, tsFim: 0, videoId: '', disparado: false, encerradoDisparado: false });
    salvar({ autoStart: { series: arr } }).then(renderSerie);
  };

  // ---------- switches simples ----------
  const chg = (id, path) => $(id).addEventListener('change', (e) => {
    const val = e.target.type === 'checkbox' ? e.target.checked : (e.target.type === 'number' ? Number(e.target.value) : e.target.value);
    const parts = path.split('.');
    const patch = {};
    let cur = patch;
    for (let i = 0; i < parts.length - 1; i++) { cur[parts[i]] = {}; cur = cur[parts[i]]; }
    cur[parts[parts.length - 1]] = val;
    salvar(patch);
  });
  chg('broadcast-enabled', 'chat.broadcast.enabled');
  chg('broadcast-min', 'chat.broadcast.minSec');
  chg('broadcast-max', 'chat.broadcast.maxSec');
  chg('broadcast-random', 'chat.broadcast.randomize');
  chg('qa-enabled', 'chat.qa.enabled');
  chg('sale-enabled', 'chat.saleAlert.enabled');
  chg('sale-tpl', 'chat.saleAlert.template');
  chg('cart-enabled', 'chat.cartAlert.enabled');
  chg('cart-tpl', 'chat.cartAlert.template');
  chg('ia-enabled', 'chat.ia.enabled');
  chg('ia-produto', 'chat.ia.produto');
  chg('ia-faq', 'chat.ia.faq');
  chg('ia-palavras', 'chat.ia.palavrasChave');
  chg('tap-enabled', 'tap.enabled');
  chg('tap-intervalo', 'tap.intervaloSeg');
  chg('repin-enabled', 'rePin.enabled');
  chg('repin-modo', 'rePin.modo');
  chg('repin-intervalo', 'rePin.intervalSec');
  chg('repin-piscar', 'rePin.blink');
  chg('repin-aleatorio', 'rePin.aleatorio');
  chg('kit-enabled', 'vitrineKit.enabled');
  chg('kit-id', 'vitrineKit.setId');
  chg('kit-nome', 'vitrineKit.setNome');
  chg('flash-enabled', 'flashOffer.enabled');
  chg('vcam-enabled', 'vcam.enabled');
  chg('vcam-loop', 'vcam.loop');
  chg('autostart-enabled', 'autoStart.enabled');
  chg('autoend-enabled', 'autoEnd.enabled');
  $('autoend-dt').addEventListener('change', (e) => salvar({ autoEnd: { endAtTs: new Date(e.target.value).getTime() } }));
  chg('espelho-enabled', 'espelho.enabled');
  $('espelho-pin').addEventListener('change', (e) => { salvar({ espelho: { pin: e.target.value } }); renderQR(); });

  $('btn-testar-lic').onclick = async () => {
    const url = $('lic-servidor').value.trim();
    const chave = $('lic-key').value.trim();
    const status = $('lic-status');
    if (!url || !chave) { status.textContent = 'Preencha URL e chave.'; return; }
    status.textContent = 'Testando ' + url + '/api/ativar ...';
    try {
      const r = await chrome.runtime.sendMessage({
        __piloto: true, kind: 'httpProxy',
        url: url + '/api/ativar', method: 'POST',
        body: { chave, fingerprint: 'painel-teste-' + Date.now() },
      });
      if (!r) { status.textContent = 'ERRO: sem resposta do service worker.'; return; }
      if (!r.ok) { status.textContent = 'ERRO de rede: ' + (r.error || '?'); return; }
      if (r.status !== 200) { status.textContent = 'ERRO ' + r.status + ': ' + (r.payload && r.payload.erro || '?'); return; }
      const p = r.payload;
      status.textContent = 'OK — token emitido, plano ' + (p.payload && p.payload.plano) + ', válido até ' + new Date(p.ate * 1000).toLocaleDateString('pt-BR');
    } catch (e) {
      status.textContent = 'ERRO: ' + (e && e.message || e);
    }
  };

  $('btn-salvar-cfg').onclick = async () => {
    await salvar({
      plataforma: $('cfg-plataforma').value,
      moderacao: {
        enabled: $('mod-enabled').checked,
        palavras: $('mod-palavras').value.split(',').map((s) => s.trim()).filter(Boolean),
      },
      seguranca: {
        guardiaoAviso: $('guardiao-aviso').checked,
        chatOpen: $('chat-liberado-toggle').checked ? true : null,
      },
      licenca: {
        servidor: $('lic-servidor').value.trim(),
      },
    });
    const chave = $('lic-key').value.trim();
    if (chave) await chrome.storage.local.set({ [KEY_LIC]: chave });
    const fb = $('salvar-feedback');
    if (fb) {
      fb.style.opacity = '1';
      setTimeout(() => { fb.style.opacity = '0'; }, 2000);
    }
    avisar('Salvo');
  };

  // ---------- vcam: gravar novo vídeo no IndexedDB ----------
  $('vcam-file').addEventListener('change', async (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const db = await abrirDB();
    const tx = db.transaction('videos', 'readwrite');
    const id = 'v' + Date.now();
    tx.objectStore('videos').put({ id, blob: f, name: f.name, at: Date.now() });
    await new Promise((r, rj) => { tx.oncomplete = r; tx.onerror = () => rj(tx.error); });
    await salvar({ vcam: { videoId: id } });
    $('vcam-info').textContent = `${f.name} — ${(f.size / 1024 / 1024).toFixed(1)} MB gravado.`;
    renderVideos();
  });
  function abrirDB() {
    return new Promise((r, rj) => {
      const req = indexedDB.open('piloto', 1);
      req.onupgradeneeded = () => { req.result.createObjectStore('videos', { keyPath: 'id' }); };
      req.onsuccess = () => r(req.result);
      req.onerror = () => rj(req.error);
    });
  }

  $('btn-vcam-play').onclick = () => mandarTab({ __piloto: true, kind: 'vcamcmd', cmd: 'play' });
  $('btn-vcam-pause').onclick = () => mandarTab({ __piloto: true, kind: 'vcamcmd', cmd: 'pause' });
  $('btn-vcam-reset').onclick = () => mandarTab({ __piloto: true, kind: 'vcamcmd', cmd: 'reset' });

  async function mandarTab(msg) {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs || !tabs[0]) return;
    try { await chrome.tabs.sendMessage(tabs[0].id, msg); } catch (_) {}
  }
  $('btn-iniciar-live').onclick = () => mandarTab({ __piloto: true, kind: 'comando', comando: 'iniciarLive' });
  $('btn-encerrar-live').onclick = () => mandarTab({ __piloto: true, kind: 'comando', comando: 'encerrarAgora' });
  $('btn-pausar').onclick = () => mandarTab({ __piloto: true, kind: 'comando', comando: 'pausar' });

  $('btn-testar-ia').onclick = async () => {
    const autor = $('ia-teste-autor').value.trim() || 'teste';
    const texto = $('ia-teste-txt').value.trim();
    const produto = ler('chat.ia.produto', '');
    const faq = ler('chat.ia.faq', '');
    const status = $('ia-teste-status');
    const resultado = $('ia-teste-resultado');
    const respTxt = $('ia-teste-texto');

    resultado.style.display = 'none';
    if (!texto) { status.textContent = 'Preencha a pergunta.'; return; }
    if (!produto) { status.textContent = 'Preencha o campo "Sobre o produto" primeiro.'; return; }
    status.textContent = 'Perguntando pra IA (5-15s)...';

    // pega o token da licença
    const stLic = await chrome.storage.local.get('piloto_license_v1');
    const token = stLic.piloto_license_v1 && stLic.piloto_license_v1.token;
    if (!token) { status.textContent = 'Licença não ativada — vá em Ajustes.'; return; }
    const servidor = ler('licenca.servidor', '') || 'https://pilotoautomaticoia.com.br';

    try {
      const r = await chrome.runtime.sendMessage({
        __piloto: true, kind: 'httpProxy',
        url: servidor + '/api/ia/responder', method: 'POST',
        headers: { authorization: 'Bearer ' + token },
        body: { produto, faq, autor, pergunta: texto },
      });
      if (!r || !r.ok) { status.textContent = 'Erro de rede: ' + (r && r.error || '?'); return; }
      if (r.status !== 200) { status.textContent = 'Erro ' + r.status + ': ' + (r.payload && r.payload.erro || '?') + (r.payload && r.payload.detalhe ? ' — ' + r.payload.detalhe : ''); return; }
      const resp = r.payload && r.payload.resposta;
      if (!resp) { status.textContent = 'IA respondeu vazio (a pergunta pode ter parecido spam pra ela)'; return; }
      status.textContent = '';
      respTxt.textContent = resp;
      resultado.style.display = 'block';
    } catch (e) {
      status.textContent = 'Erro: ' + (e && e.message || e);
    }
  };

  // ---------- QR code do espelho (SVG simples, sem libs externas) ----------
  function renderQR() {
    const pin = ler('espelho.pin', '');
    const cont = $('qr-container');
    cont.innerHTML = '';
    if (!pin) { $('espelho-status').textContent = 'Sem código de pareamento.'; return; }
    const url = 'https://pilotoautomaticoia.com.br/espelho/' + encodeURIComponent(pin);
    // fallback: mostra a URL como texto grande (o PWA local do espelho aceita colar a URL)
    cont.innerHTML = `
      <div class="qr-fake">${esc(pin)}</div>
      <p class="hint">Cole no PWA: <code>${esc(url)}</code></p>`;
    $('espelho-status').textContent = 'Aguardando pareamento...';
  }

  // ---------- feed + métricas ao vivo ----------
  async function tickFeed() {
    try {
      const r = await chrome.runtime.sendMessage({ __piloto: true, kind: 'lerFeed' });
      if (r && r.feed) {
        const ul = $('feed-lista'); ul.innerHTML = '';
        for (let i = r.feed.length - 1; i >= 0; i--) {
          const e = r.feed[i];
          const hh = new Date(e.ts).toLocaleTimeString().slice(0, 5);
          const li = document.createElement('li');
          li.innerHTML = `<span class="ts">${hh}</span> ${esc(e.msg)}`;
          ul.appendChild(li);
        }
      }
    } catch (_) {}
  }
  async function tickDiag() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs || !tabs[0]) return;
      const r = await chrome.tabs.sendMessage(tabs[0].id, { __piloto: true, kind: 'diag' });
      if (!r) { setStatus('vivo', 'erro', 'sem contato'); return; }

      // plataforma
      $('plataforma-lbl').textContent = r.plataforma || '?';
      if (r.aoVivo) setStatus('vivo', 'aovivo', r.plataforma + ' ao vivo');
      else setStatus('vivo', '', (r.plataforma || '?') + ' fora do ar');

      // licença
      if (r.licenca) {
        const l = r.licenca;
        if (l.bloqueada) setStatus('lic', 'bloq', 'licença: bloqueada');
        else if (l.plano === 'trial') setStatus('lic', 'trial', 'trial');
        else setStatus('lic', 'ok', l.plano || 'ativa');
      }

      // espelho
      const dEsp = (r.motores || []).find((m) => m.nome === 'espelho');
      if (!dEsp || !dEsp.ligado) setStatus('esp', '', 'espelho off');
      else if (dEsp.diag && dEsp.diag.morto) setStatus('esp', 'erro', 'espelho erro');
      else if (dEsp.diag && dEsp.diag.erros > 0) setStatus('esp', 'trial', 'espelho instável');
      else setStatus('esp', 'ok', 'espelho ok');

      // métricas
      const d = {};
      for (const m of (r.motores || [])) { if (m && m.diag) d[m.nome] = m.diag; }
      if (d['tempo-live'] && d['tempo-live'].tempoMs != null) {
        $('metrica-tempo').textContent = fmtMs(d['tempo-live'].tempoMs);
      }
      if (d['dinheiro']) {
        $('metrica-vendas').textContent = String(d['dinheiro'].vendas || 0);
        $('metrica-gmv').textContent = 'R$ ' + Number(d['dinheiro'].gmvOficial || d['dinheiro'].gmv || 0).toFixed(2).replace('.', ',');
        $('metrica-ticket').textContent = 'R$ ' + Number(d['dinheiro'].ticket || 0).toFixed(2).replace('.', ',');
      }
      if (r.state) {
        if (r.state.assistiramTotal != null) $('metrica-viewers').textContent = String(r.state.assistiramTotal);
        if (r.state.exibicoes != null) $('metrica-exibicoes').textContent = String(r.state.exibicoes);
        if (r.state.chatAvisosVenda != null) $('metrica-avisos').textContent = String(r.state.chatAvisosVenda);
      }
    } catch (_) {
      setStatus('vivo', 'erro', 'sem contato');
    }
  }

  function setStatus(qual, classe, texto) {
    const pt = $('pt-' + qual);
    const lb = $(qual + '-lbl');
    if (pt) { pt.className = 'pontinho' + (classe ? ' ' + classe : ''); }
    if (lb) { lb.textContent = texto; }
  }
  function fmtMs(ms) {
    if (!ms || ms < 0) ms = 0;
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m + ':' + (ss < 10 ? '0' : '') + ss;
  }
  setInterval(tickFeed, 3000); tickFeed();
  setInterval(tickDiag, 2000); tickDiag();

  // ---------- Leads (atualiza a cada 3s pelo diag) ----------
  async function tickLeads() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tabs || !tabs[0]) return;
      const r = await chrome.tabs.sendMessage(tabs[0].id, { __piloto: true, kind: 'lerLeads' });
      if (!r || !r.leads) return;
      renderLeads(r.leads);
    } catch (_) {}
  }
  function renderLeads(leads) {
    const ul = $('leads-lista'); ul.innerHTML = '';
    const vazio = $('leads-vazio');
    if (!leads || !leads.length) { vazio.style.display = ''; return; }
    vazio.style.display = 'none';
    for (const l of leads) {
      const li = document.createElement('li');
      const hh = new Date(l.ts).toLocaleTimeString().slice(0, 5);
      li.innerHTML = `
        <div class="lead-topo">
          <span class="lead-autor">${esc(l.autor)}</span>
          <span class="lead-ts">${hh}</span>
        </div>
        <div><span class="lead-palavra">${esc(l.palavra)}</span></div>
        <div class="lead-txt">${esc(l.texto)}</div>
        <div class="lead-acoes">
          <button class="secundaria" data-copy="${esc(l.autor)}">Copiar @${esc(l.autor)}</button>
        </div>`;
      ul.appendChild(li);
    }
    for (const b of ul.querySelectorAll('button[data-copy]')) {
      b.addEventListener('click', () => {
        navigator.clipboard.writeText('@' + b.dataset.copy).then(() => avisar('@' + b.dataset.copy + ' copiado'));
      });
    }
  }
  setInterval(tickLeads, 3000); tickLeads();

  function avisar(msg) { document.title = msg; setTimeout(() => { document.title = 'Piloto Automatico IA'; }, 1200); }

  // ouvir mudanças de storage (outra janela salvou)
  chrome.storage.onChanged.addListener((chgObj, area) => {
    if (area === 'local' && chgObj[KEY]) { cfg = chgObj[KEY].newValue || {}; renderTudo(); }
  });

  // ---------- onboarding ----------
  async function verificarOnboarding() {
    const r = await chrome.storage.local.get([KEY_LIC, KEY, 'piloto_conta_v1']);
    const chave = r[KEY_LIC];
    const cfgAtual = r[KEY] || {};
    const lic = cfgAtual.licenca || {};
    const conta = r.piloto_conta_v1 || null;
    const agora = Math.floor(Date.now() / 1000);
    const expirouLic = lic.exp && lic.exp < agora;

    // Se tem conta salva com sessao ainda valida — renova o token Ed25519
    // sozinho (sem mostrar tela de login) e mantem tudo fluindo.
    if (conta && conta.email && conta.tokenSessao && conta.ate > agora + 60 && expirouLic) {
      try {
        const fp = await fingerprintDaMaquina();
        const rr = await chrome.runtime.sendMessage({
          __piloto: true, kind: 'httpProxy',
          url: urlServidor() + '/api/contas/ativar', method: 'POST',
          body: { email: conta.email, tokenSessao: conta.tokenSessao, fingerprint: fp },
        });
        if (rr && rr.ok && rr.status === 200 && rr.payload && rr.payload.token) {
          const p = rr.payload;
          const plano = (p.payload && p.payload.plano) || 'ativa';
          const exp = (p.payload && p.payload.exp) || 0;
          await chrome.storage.local.set({
            [KEY_LIC]: (p.payload && p.payload.chave) || chave,
            piloto_license_v1: { token: p.token, tokenPayload: p.payload, ate: p.ate },
          });
          await salvar({ licenca: { plano, exp } });
          $('onboarding').hidden = true;
          return;
        }
      } catch (_) {}
    }

    if (!chave && !conta) { $('onboarding').hidden = false; return; }
    if (!chave && conta) { $('onboarding').hidden = false; return; }
    if (expirouLic && (lic.plano === 'trial' || !lic.plano) && !conta) { $('onboarding').hidden = false; return; }
    $('onboarding').hidden = true;
  }

  // fingerprint estavel do computador — MESMA logica do license.js.
  // Sem isto, testes de ativar consumiriam o limite de 3 maquinas.
  async function fingerprintDaMaquina() {
    try {
      const n = self.navigator || {};
      const ua = String(n.userAgent || '');
      const plataforma = (ua.match(/\(([^)]*)\)/) || [, ''])[1].split(';')[0].trim();
      const fuso = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
      const lang = n.language || '';
      const cores = n.hardwareConcurrency || 0;
      const mem = n.deviceMemory || 0;
      const bruto = [plataforma, fuso, lang, cores, mem].join('|');
      const bytes = new TextEncoder().encode(bruto);
      const hash = await crypto.subtle.digest('SHA-256', bytes);
      return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 32);
    } catch (_) { return 'unk-' + Math.random().toString(36).slice(2); }
  }

  // tabs Entrar / Criar conta
  const tabLogin = $('onb-tab-login');
  const tabReg = $('onb-tab-registro');
  const formLogin = $('onb-form-login');
  const formReg = $('onb-form-registro');
  function mostrarTab(qual) {
    if (qual === 'login') {
      tabLogin.classList.add('ativa'); tabReg.classList.remove('ativa');
      formLogin.hidden = false; formReg.hidden = true;
    } else {
      tabReg.classList.add('ativa'); tabLogin.classList.remove('ativa');
      formReg.hidden = false; formLogin.hidden = true;
    }
    $('onb-status').textContent = '';
  }
  tabLogin.addEventListener('click', () => mostrarTab('login'));
  tabReg.addEventListener('click', () => mostrarTab('registro'));

  // servidor helper (localiza URL do backend)
  const urlServidor = () => (ler('licenca.servidor', '') || 'https://pilotoautomaticoia.com.br');

  // apos ter tokenSessao + email, chama /ativar pra pegar o token Ed25519
  async function ativarComSessao(email, tokenSessao) {
    const st = $('onb-status');
    const fp = await fingerprintDaMaquina();
    const r = await chrome.runtime.sendMessage({
      __piloto: true, kind: 'httpProxy',
      url: urlServidor() + '/api/contas/ativar', method: 'POST',
      body: { email, tokenSessao, fingerprint: fp },
    });
    if (r && r.ok && r.status === 200 && r.payload && r.payload.token) {
      const p = r.payload;
      const plano = (p.payload && p.payload.plano) || 'ativa';
      const exp = (p.payload && p.payload.exp) || 0;
      // guarda tudo pra proxima abertura: sessao + chave + payload
      await chrome.storage.local.set({
        piloto_conta_v1: { email, tokenSessao, ate: exp },
        [KEY_LIC]: (p.payload && p.payload.chave) || '',
        piloto_license_v1: { token: p.token, tokenPayload: p.payload, ate: p.ate },
      });
      await salvar({ licenca: { plano, exp } });
      st.textContent = 'Bem-vindo! Plano: ' + plano;
      setTimeout(() => { $('onboarding').hidden = true; }, 600);
      return true;
    }
    const erro = (r && r.payload && r.payload.erro) || 'servidor não respondeu';
    st.textContent = 'Erro: ' + erro;
    return false;
  }

  $('onb-btn-login').addEventListener('click', async () => {
    const email = $('onb-login-email').value.trim();
    const senha = $('onb-login-senha').value;
    const st = $('onb-status');
    if (!email || !senha) { st.textContent = 'Preencha email e senha.'; return; }
    st.textContent = 'Entrando...';
    try {
      const r = await chrome.runtime.sendMessage({
        __piloto: true, kind: 'httpProxy',
        url: urlServidor() + '/api/contas/login', method: 'POST',
        body: { email, senha },
      });
      if (r && r.ok && r.status === 200 && r.payload && r.payload.tokenSessao) {
        st.textContent = 'Validando licença...';
        await ativarComSessao(r.payload.email, r.payload.tokenSessao);
      } else {
        const erro = (r && r.payload && r.payload.erro) || 'servidor não respondeu';
        st.textContent = 'Erro: ' + erro;
      }
    } catch (e) {
      st.textContent = 'Erro: ' + (e && e.message || e);
    }
  });

  $('onb-btn-registro').addEventListener('click', async () => {
    const email = $('onb-reg-email').value.trim();
    const senha = $('onb-reg-senha').value;
    const chave = $('onb-reg-chave').value.trim();
    const st = $('onb-status');
    if (!email || !senha || !chave) { st.textContent = 'Preencha email, senha e chave.'; return; }
    if (senha.length < 6) { st.textContent = 'Senha muito curta (mínimo 6).'; return; }
    st.textContent = 'Criando conta...';
    try {
      const r = await chrome.runtime.sendMessage({
        __piloto: true, kind: 'httpProxy',
        url: urlServidor() + '/api/contas/register', method: 'POST',
        body: { email, senha, chave },
      });
      if (r && r.ok && r.status === 200 && r.payload && r.payload.ok) {
        // registrou — faz login automatico
        st.textContent = 'Conta criada! Entrando...';
        const rl = await chrome.runtime.sendMessage({
          __piloto: true, kind: 'httpProxy',
          url: urlServidor() + '/api/contas/login', method: 'POST',
          body: { email, senha },
        });
        if (rl && rl.ok && rl.payload && rl.payload.tokenSessao) {
          await ativarComSessao(rl.payload.email, rl.payload.tokenSessao);
        } else {
          st.textContent = 'Conta criada, mas falha no login automático — clique Entrar.';
        }
      } else {
        const erro = (r && r.payload && r.payload.erro) || 'servidor não respondeu';
        st.textContent = 'Erro: ' + erro;
      }
    } catch (e) {
      st.textContent = 'Erro: ' + (e && e.message || e);
    }
  });

  // corrige tambem o botao "Testar licenca" pra usar o mesmo fingerprint
  const btnTestarOrig = $('btn-testar-lic').onclick;
  $('btn-testar-lic').onclick = async () => {
    const url = $('lic-servidor').value.trim();
    const chave = $('lic-key').value.trim();
    const status = $('lic-status');
    if (!url || !chave) { status.textContent = 'Preencha URL e chave.'; return; }
    status.textContent = 'Testando ' + url + '/api/ativar ...';
    const fp = await fingerprintDaMaquina();
    try {
      const r = await chrome.runtime.sendMessage({
        __piloto: true, kind: 'httpProxy',
        url: url + '/api/ativar', method: 'POST',
        body: { chave, fingerprint: fp },
      });
      if (!r) { status.textContent = 'ERRO: sem resposta do service worker.'; return; }
      if (!r.ok) { status.textContent = 'ERRO de rede: ' + (r.error || '?'); return; }
      if (r.status !== 200) { status.textContent = 'ERRO ' + r.status + ': ' + (r.payload && r.payload.erro || '?'); return; }
      const p = r.payload;
      status.textContent = 'OK — token emitido, plano ' + (p.payload && p.payload.plano) + ', válido até ' + new Date(p.ate * 1000).toLocaleDateString('pt-BR');
    } catch (e) {
      status.textContent = 'ERRO: ' + (e && e.message || e);
    }
  };

  carregar().then(() => verificarOnboarding());
})();
