/*
 * license.js — cliente de licenca.
 *
 * Como funciona (quando o servidor estiver no ar):
 *  - o pacote do comprador vem carimbado com licenca.json na raiz
 *    ({chave, servidor?}) OU o vendedor cola a chave manualmente no painel
 *    (chrome.storage.local: 'piloto_license_key');
 *  - no boot, tenta ativar/renovar: POST {servidor}/api/ativar {chave, fingerprint}
 *    -> token Ed25519 (~10 dias). A extensao verifica OFFLINE com a chave
 *    publica embutida (Web Crypto SubtleCrypto).
 *  - o resultado vive em chrome.storage.local (piloto_lic_status). O painel
 *    e os motores olham CL.vida.licBloqueada() (que ouve o canal 'licenca').
 *  - Sem servidor / sem chave: 7 dias de trial e depois bloqueia SO os motores
 *    que iniciam acao — pausar/encerrar/parar sempre passam.
 *
 * Filosofia: FAIL-OPEN. Erro de crypto/rede/storage nunca trava a live de um
 * cliente pagante. O corte definitivo eh do servidor (assinatura inativa).
 *
 * OBS: enquanto nao ha servidor no ar (pilotoautomaticoia.com.br placeholder), o
 * cliente ativa em modo dev com trial infinito, publicando bloqueada=false.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (CL.licenca && CL.licenca._pronto) return;

  const KEY_STORE = 'piloto_license_v1';
  const KEY_MANUAL = 'piloto_license_key';
  const TRIAL_DIAS = 7;
  const RENOVA_ANTES_SEG = 3 * 86400;
  const ENTRE_TENTATIVAS_MS = 30 * 60000;

  // servidor: lido a cada chamada (a config pode chegar depois deste arquivo).
  function servidor() {
    try {
      const c = self.CL && self.CL.cfg && self.CL.cfg();
      if (c && c.licenca && c.licenca.servidor) return String(c.licenca.servidor);
    } catch (_) {}
    return 'https://pilotoautomaticoia.com.br';
  }
  // Ed25519 chave publica (base64 raw 32 bytes) — cole aqui a saida de
  // `npm run gerar-chaves` do servidor. Enquanto ficar vazia, o cliente aceita
  // o payload sem verificar (fail-open dev). Em producao NUNCA deixe vazio.
  const PUB_KEY_B64 = 'wUfiBlrReGGYZxZQA2xj2Kp6gvsP8NzZncgGxuABn8g=';

  const agoraSeg = () => Math.floor(Date.now() / 1000);
  const b64ToBytes = (b64) => Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const b64uToBytes = (s) => {
    s = String(s).replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    return b64ToBytes(s);
  };

  async function ler() {
    try { const r = await chrome.storage.local.get(KEY_STORE); return r[KEY_STORE] || {}; }
    catch (_) { return {}; }
  }
  async function grava(st) { try { await chrome.storage.local.set({ [KEY_STORE]: st }); } catch (_) {} }
  async function chaveManual() {
    try { const r = await chrome.storage.local.get(KEY_MANUAL); return (r[KEY_MANUAL] || '').trim(); }
    catch (_) { return ''; }
  }
  async function carimbo() {
    try {
      const r = await fetch(chrome.runtime.getURL('licenca.json'));
      if (!r.ok) return null;
      const j = await r.json();
      return j && j.chave ? j : null;
    } catch (_) { return null; }
  }

  async function fingerprint() {
    // identidade estavel do computador — sem armazenamento local, recalculada.
    // Copiar chrome.storage pra outra maquina nao copia o hardware; apagar
    // chrome.storage nao muda o hardware.
    try {
      const n = self.navigator || {};
      const ua = String(n.userAgent || '');
      const plataforma = (ua.match(/\(([^)]*)\)/) || [, ''])[1].split(';')[0].trim();
      const fuso = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
      const lang = n.language || '';
      const cores = n.hardwareConcurrency || 0;
      const mem = n.deviceMemory || 0;
      const bruto = [plataforma, fuso, lang, cores, mem].join('|');
      const bytes = new TextEncoder().encode(bruto);
      const hash = await crypto.subtle.digest('SHA-256', bytes);
      return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 32);
    } catch (_) {
      return 'unk-' + Math.random().toString(36).slice(2);
    }
  }

  async function verificarToken(tokenB64u) {
    if (!PUB_KEY_B64) return null; // sem servidor real ainda: apenas parseia o payload
    try {
      const partes = tokenB64u.split('.');
      if (partes.length !== 2) return null;
      const payloadStr = new TextDecoder().decode(b64uToBytes(partes[0]));
      const payload = JSON.parse(payloadStr);
      const sig = b64uToBytes(partes[1]);
      const dados = new TextEncoder().encode(partes[0]);
      const chave = await crypto.subtle.importKey('raw', b64ToBytes(PUB_KEY_B64), { name: 'Ed25519' }, false, ['verify']);
      const ok = await crypto.subtle.verify('Ed25519', chave, sig, dados);
      if (!ok) return null;
      return payload;
    } catch (_) { return null; }
  }

  async function tentarAtivar(chave) {
    try {
      const fp = await fingerprint();
      // roteia pelo background pra contornar mixed content (HTTPS page -> HTTP localhost)
      const r = await chrome.runtime.sendMessage({
        __piloto: true,
        kind: 'httpProxy',
        url: servidor() + '/api/ativar',
        method: 'POST',
        body: { chave, fingerprint: fp },
      });
      if (!r || !r.ok || r.status !== 200) return null;
      const j = r.payload;
      return j && j.token ? j : null;
    } catch (_) { return null; }
  }

  function anunciar(bloqueada, msg, extra) {
    if (CL.bus) {
      CL.bus.publicar('licenca', { bloqueada: !!bloqueada, msg: msg || '' });
      if (extra) CL.bus.publicar('licenca:info', extra);
    }
  }

  // le tokenPayload salvo pelo login via email/senha (contas.js)
  async function tokenPayloadDoLogin() {
    try {
      const r = await chrome.storage.local.get('piloto_license_v1');
      const p = r.piloto_license_v1;
      if (p && p.tokenPayload && p.tokenPayload.exp > agoraSeg() + 60) return p.tokenPayload;
    } catch (_) {}
    return null;
  }

  let ultimaTentativaAt = 0;
  async function ciclo() {
    const st = await ler();
    const stamp = await carimbo();
    const manual = await chaveManual();
    let chave = (stamp && stamp.chave) || manual || '';

    // ATALHO: se o usuario logou via email/senha, ja temos um tokenPayload
    // valido em piloto_license_v1 — libera direto sem passar por trial.
    const payloadLogin = await tokenPayloadDoLogin();
    if (payloadLogin) {
      if (!chave && payloadLogin.chave) chave = payloadLogin.chave;
      st.tokenPayload = payloadLogin;
      anunciar(false, '', { plano: payloadLogin.plano || 'ativa', exp: payloadLogin.exp, chave: chave || payloadLogin.chave || '' });
      return { estado: 'ativo-login', ate: payloadLogin.exp };
    }

    // sem chave: trial de 7 dias (persistente). Depois trava so' acoes que iniciam.
    if (!chave) {
      if (!st.trialStart) { st.trialStart = agoraSeg(); await grava(st); }
      const restante = TRIAL_DIAS * 86400 - (agoraSeg() - st.trialStart);
      if (restante > 0) {
        anunciar(false, '');
        return { estado: 'trial', restante };
      }
      anunciar(true, 'Trial de 7 dias expirou. Ative uma chave nos Ajustes.');
      return { estado: 'trial-expirado' };
    }

    // temos chave; se ha token valido em cache, usa
    if (st.tokenPayload && st.tokenPayload.exp > agoraSeg() + 60) {
      anunciar(false, '', { plano: st.tokenPayload.plano || 'basico', exp: st.tokenPayload.exp, chave });
      // renova antecipado se falta pouco
      if (st.tokenPayload.exp - agoraSeg() < RENOVA_ANTES_SEG && agoraSeg() - ultimaTentativaAt > ENTRE_TENTATIVAS_MS / 1000) {
        ultimaTentativaAt = agoraSeg();
        const novo = await tentarAtivar(chave);
        if (novo && novo.token) {
          const payload = await verificarToken(novo.token) || novo.payload || null;
          if (payload && payload.exp) {
            st.tokenPayload = payload;
            st.token = novo.token;
            await grava(st);
          }
        }
      }
      anunciar(false, '');
      return { estado: 'ativo', ate: st.tokenPayload.exp };
    }

    // sem token valido: pede um
    if (agoraSeg() - ultimaTentativaAt < ENTRE_TENTATIVAS_MS / 1000 && st.tokenPayload) {
      // ainda dentro do intervalo — usa o cache mesmo vencido em fail-open
      anunciar(false, '');
      return { estado: 'stale', ate: st.tokenPayload.exp };
    }
    ultimaTentativaAt = agoraSeg();
    const novo = await tentarAtivar(chave);
    if (novo && novo.token) {
      const payload = await verificarToken(novo.token) || novo.payload || { exp: agoraSeg() + 10 * 86400 };
      st.token = novo.token; st.tokenPayload = payload; await grava(st);
      anunciar(false, '', { plano: payload.plano || 'basico', exp: payload.exp, chave });
      return { estado: 'ativo', ate: payload.exp };
    }
    // servidor nao respondeu — fail-open (livre) mas registra
    anunciar(false, '');
    return { estado: 'sem-servidor' };
  }

  CL.licenca = {
    _pronto: true,
    status: () => ler(),
    reciclar: ciclo,
  };
  ciclo();
  // re-roda quando a config carrega (storage.js eh async — a URL do
  // servidor pode chegar depois deste arquivo)
  if (CL.onCfgChange) CL.onCfgChange(() => ciclo());
  // renova/valida a cada 30 min
  setInterval(ciclo, 30 * 60000);
})();
