/*
 * vida.js — CL.vida: estado de ciclo de vida da live e da extensao.
 *
 * Fonte unica para: estou ao vivo? estou pausado? estou encerrando?
 * a licenca me bloqueia esta acao? sou o frame de topo?
 *
 * O que fica AQUI: leitura. Quem escreve o estado sao os motores donos da
 * fatia (coletor-room publica o roomId/aoVivo; tempo-live decide encerrando;
 * license.js decide licBloqueada). A vida so l e expoe o boolean.
 */
(() => {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (CL.vida) return;

  const IS_TOP = (() => { try { return window.top === window; } catch (_) { return true; } })();

  const st = {
    aoVivo: false,
    startTs: 0,
    roomId: '',
    pausado: false,
    encerrando: false,
    licBloqueada: false,
    licMsg: '',
  };

  // um coletor decide se estamos ao vivo (canal 'sala'); outro pode publicar 'vida'
  // com {evento: 'pausado'|'retomado'|'encerrando'|'live-comecou'|'live-acabou'}
  function assinarQuandoOnibus() {
    if (!CL.bus) return;
    CL.bus.assinar('sala', (s) => {
      if (!s) return;
      if (typeof s.aoVivo === 'boolean') st.aoVivo = s.aoVivo;
      if (typeof s.roomId === 'string') st.roomId = s.roomId;
      if (typeof s.startTs === 'number' && s.startTs > 0) st.startTs = s.startTs;
    });
    CL.bus.assinar('vida', (v) => {
      if (!v) return;
      if (v.evento === 'pausado') st.pausado = true;
      else if (v.evento === 'retomado') st.pausado = false;
      else if (v.evento === 'encerrando') st.encerrando = true;
      else if (v.evento === 'live-comecou') { st.encerrando = false; st.aoVivo = true; }
      else if (v.evento === 'live-acabou') { st.encerrando = false; st.aoVivo = false; }
    });
    CL.bus.assinar('licenca', (l) => {
      if (!l) return;
      st.licBloqueada = !!l.bloqueada;
      st.licMsg = l.msg || '';
    });
  }
  // barramento.js e injetado antes deste arquivo, mas o teste unitario pode montar
  // o CL fora de ordem; a chamada aqui e segura se ja existe, ou o motor pode chamar
  // CL.vida.reengatar() depois. Sem custo em runtime real.
  assinarQuandoOnibus();

  CL.vida = {
    IS_TOP,
    aoVivo: () => !!st.aoVivo,
    pausado: () => !!st.pausado,
    encerrando: () => !!st.encerrando,
    roomId: () => st.roomId,
    startTs: () => st.startTs || 0,
    licBloqueada(oque) {
      if (!st.licBloqueada) return false;
      // oque e' descricao humana pra motor logar por que nao pode agir; nao muda o
      // resultado, so vira parte do feed quando alguem chamar CL.portas.feed.
      return { motivo: st.licMsg || 'Licenca inativa', oque: oque || '' };
    },
    // pra harness de teste
    _reengatar: assinarQuandoOnibus,
    _snapshot: () => Object.assign({}, st),
    _publicar: (patch) => Object.assign(st, patch || {}),
  };
})();
