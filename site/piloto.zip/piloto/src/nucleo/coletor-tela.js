/*
 * coletor-tela.js — observa o container do chat na tela (MutationObserver) e
 * publica 'tela:chat' por comentario novo. Reserva quando o WS falha (rara).
 *
 * NAO decide se responder — motores decidem pela propria cfg. O coletor so
 * entrega o fato.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.bus || !CL.repetir) return;

  let mo = null;
  let ancora = null;

  // heuristica para achar o container do chat: div com muitos <div> filhos
  // acumulando texto novo. Marca-agua muda; entao a gente procura pelo shape.
  function acharContainerChat() {
    // 1) selectors comuns em varias versoes de UI
    const cands = document.querySelectorAll('[class*="chat"] [class*="list"], [class*="Chat"] [class*="List"], [data-e2e*="chat"]');
    for (const el of cands) {
      if (el.children && el.children.length > 3) return el;
    }
    // 2) fallback: qualquer elemento com muitos filhos ao lado de um botao "Enviar"
    return null;
  }

  function textoDoComentario(node) {
    if (!node || node.nodeType !== 1) return { autor: '', texto: '' };
    const t = (node.innerText || node.textContent || '').replace(/\s+/g, ' ').trim();
    if (!t) return { autor: '', texto: '' };
    // heuristica: "Fulano: mensagem"
    const m = t.match(/^([^:]{1,40}):\s*(.+)$/);
    if (m) return { autor: m[1].trim(), texto: m[2].trim() };
    return { autor: '', texto: t };
  }

  function ligar() {
    if (mo) return;
    ancora = acharContainerChat();
    if (!ancora) return;
    mo = new MutationObserver((muts) => {
      for (const m of muts) {
        for (const n of m.addedNodes || []) {
          if (n.nodeType !== 1) continue;
          const { autor, texto } = textoDoComentario(n);
          if (!texto) continue;
          if (CL.portas && CL.portas.ecoProprio(texto)) continue; // meu proprio post
          CL.bus.publicar('tela:chat', { autor, texto, ts: Date.now() });
        }
      }
    });
    mo.observe(ancora, { childList: true, subtree: false });
  }
  function desligar() {
    if (!mo) return;
    try { mo.disconnect(); } catch (_) {}
    mo = null; ancora = null;
  }

  // procura o container periodicamente ate achar (a UI carrega tardio)
  CL.repetir(() => {
    if (mo && ancora && document.contains(ancora)) return;
    if (mo) desligar();
    ligar();
  }, 3000);
})();
