/*
 * portas.js — CL.portas: unica camada por onde saem ACOES na conta do vendedor.
 *
 * Motor nunca posta chat direto, nunca chama live_product/pin direto, nunca
 * envia notificacao direto. Ele chama uma porta daqui. Assim as travas de
 * seguranca (licenca / pausa / motor morto) moram num lugar so.
 *
 * CHAT = fila unica global: todos os motores enfileiram aqui; a fila espaca
 * envios com gap de 1s, tenta 3x com 4s de respiro, e nunca descarta.
 */
(() => {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (CL.portas) return;

  const F = () => CL.finder;

  // ---------- eco do proprio post: se saiu por mim, nao trate como comentario alheio
  const meusEnvios = []; // {texto, ts}
  const ECO_MAX = 40;
  const ECO_VIDA_MS = 30_000;
  function marcarEco(texto) {
    meusEnvios.push({ texto: String(texto || '').trim(), ts: Date.now() });
    while (meusEnvios.length > ECO_MAX) meusEnvios.shift();
  }
  function ecoProprio(texto) {
    const t = String(texto || '').trim();
    if (!t) return false;
    const corte = Date.now() - ECO_VIDA_MS;
    for (let i = meusEnvios.length - 1; i >= 0; i--) {
      const m = meusEnvios[i];
      if (m.ts < corte) return false;
      if (m.texto === t) return true;
    }
    return false;
  }

  // ---------- fila unica global de chat ----------
  const GAP_MS = 1000;
  const RETRIES = 3;
  const RESPIRO_MS = 4000;
  const fila = []; // {texto, origem, aoResultado, tentativas}
  let ocupado = false;
  let ultimoEnvioAt = 0;

  async function enviarChatBruto(texto) {
    // implementacao troca por plataforma via CL.plataforma. Padrao: API do TikTok Shop.
    if (CL.plataforma && typeof CL.plataforma.postarChat === 'function') {
      return CL.plataforma.postarChat(texto);
    }
    return false;
  }

  async function processarFila() {
    if (ocupado) return;
    if (!fila.length) return;
    ocupado = true;
    try {
      while (fila.length) {
        const item = fila[0];
        // travas: se aparecerem no meio, drena com falha (o motor decide o que fazer)
        if (CL.vida && CL.vida.pausado()) { fila.shift(); item.aoResultado && item.aoResultado(false, 'pausado'); continue; }
        const lic = CL.vida && CL.vida.licBloqueada && CL.vida.licBloqueada('enviar mensagem');
        if (lic) { fila.shift(); item.aoResultado && item.aoResultado(false, 'licenca'); continue; }

        // gap tecnico
        const agora = Date.now();
        const espera = ultimoEnvioAt + GAP_MS - agora;
        if (espera > 0) await new Promise((r) => setTimeout(r, espera));

        let sucesso = false;
        try {
          marcarEco(item.texto);
          sucesso = await enviarChatBruto(item.texto);
        } catch (_) { sucesso = false; }
        ultimoEnvioAt = Date.now();

        if (sucesso) {
          fila.shift();
          item.aoResultado && item.aoResultado(true);
          continue;
        }
        item.tentativas = (item.tentativas || 0) + 1;
        if (item.tentativas >= RETRIES) {
          fila.shift();
          item.aoResultado && item.aoResultado(false, 'esgotou');
          feed('chat', 'Nao consegui postar apos ' + RETRIES + ' tentativas: ' + item.texto.slice(0, 40));
          continue;
        }
        // respiro entre retries e volta pro topo (nao muda ordem)
        await new Promise((r) => setTimeout(r, RESPIRO_MS));
      }
    } finally {
      ocupado = false;
    }
  }

  function chat(texto, origem, aoResultado) {
    const t = String(texto || '').trim();
    if (!t) { aoResultado && aoResultado(false, 'vazio'); return; }
    fila.push({ texto: t, origem: origem || '?', aoResultado, tentativas: 0 });
    processarFila();
  }

  // ---------- fixar / fixar lista ----------
  async function fixar(productId) {
    if (CL.vida && CL.vida.pausado()) return false;
    if (CL.vida && CL.vida.licBloqueada && CL.vida.licBloqueada('fixar')) return false;
    if (CL.plataforma && typeof CL.plataforma.fixar === 'function') return CL.plataforma.fixar(productId);
    return false;
  }
  async function fixarLista(ids) {
    if (CL.vida && CL.vida.pausado()) return false;
    if (CL.vida && CL.vida.licBloqueada && CL.vida.licBloqueada('fixar lista')) return false;
    if (CL.plataforma && typeof CL.plataforma.fixarLista === 'function') return CL.plataforma.fixarLista(ids);
    return false;
  }
  async function recolocarKit(setId) {
    if (CL.vida && CL.vida.aoVivo()) return false; // vitrine-kit so age FORA DO AR
    if (CL.plataforma && typeof CL.plataforma.recolocarKit === 'function') return CL.plataforma.recolocarKit(setId);
    return false;
  }

  // ---------- notificacoes do sistema ----------
  function notificar(tag, titulo, corpo) {
    try {
      chrome.runtime.sendMessage({ __piloto: true, kind: 'notify', tag, titulo, corpo });
    } catch (_) {}
  }

  // ---------- feed do painel ----------
  function feed(tipo, msg) {
    try {
      chrome.runtime.sendMessage({ __piloto: true, kind: 'feed', tipo: tipo || 'info', msg: String(msg || ''), ts: Date.now() });
    } catch (_) {}
    // publica tambem no barramento local (espelho consome pra levar pro celular)
    if (CL.bus) CL.bus.publicar('feed', { tipo: tipo || 'info', msg: String(msg || ''), ts: Date.now() });
  }

  CL.portas = {
    chat,
    fixar,
    fixarLista,
    recolocarKit,
    notificar,
    feed,
    ecoProprio,
    _drenar: () => { fila.length = 0; }, // usado no desligarTudo
  };
})();
