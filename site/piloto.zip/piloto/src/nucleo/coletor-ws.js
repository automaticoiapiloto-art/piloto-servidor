/*
 * coletor-ws.js — ponte com netcapture.js. Recebe __pt_livefeed com o conteudo
 * dos frames de WebSocket da live. Faz parse defensivo (JSON solto e/ou
 * protobuf simples) e publica no barramento:
 *   'stats'     -> {"product_stats": {<id>: {product_clicks, add_to_cart_cnt, sales}}}
 *   'atividade' -> {tipo: 'entrou'|'clique'|'carrinho'|'venda', nome?, produtoId?, valor?, ts}
 *
 * Frame binario nem sempre eh protobuf declarado — o TikTok solta objetos JSON
 * cru dentro de blocos binarios. Tentativa em ordem: 1) JSON.parse do texto
 * inteiro; 2) extrair substring JSON balanceada; 3) protobuf minimo pra
 * message.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.bus || !CL.api) return;

  const decoder = new TextDecoder('utf-8', { fatal: false });
  let avisouParse = false;

  function parseSolto(bytes) {
    let txt = '';
    try { txt = decoder.decode(new Uint8Array(bytes)); } catch (_) { return null; }
    // caso simples: o texto inteiro e JSON valido
    try { return JSON.parse(txt); } catch (_) {}
    // caso comum: pedaço binario + JSON depois — procura primeira { e casa balanceada
    const de = txt.indexOf('{');
    if (de < 0) return null;
    let nivel = 0, fim = -1;
    for (let i = de; i < txt.length; i++) {
      const c = txt.charCodeAt(i);
      if (c === 0x7B) nivel++;         // {
      else if (c === 0x7D) {           // }
        nivel--;
        if (nivel === 0) { fim = i + 1; break; }
      }
    }
    if (fim < 0) return null;
    try { return JSON.parse(txt.slice(de, fim)); } catch (_) { return null; }
  }

  function processar(obj) {
    if (!obj || typeof obj !== 'object') return;

    // product_stats
    if (obj.product_stats && typeof obj.product_stats === 'object') {
      CL.bus.publicar('stats', obj.product_stats);
    }

    // eventos de atividade — varias formas possiveis; normaliza pra {tipo, ...}
    if (obj.event) {
      const nome = (obj.user && (obj.user.nickname || obj.user.name)) || obj.nick_name || '';
      const produtoId = String(obj.product_id || obj.item_id || '');
      const valor = obj.price ? CL.util.precoBR(String(obj.price)) : (obj.total_price ? CL.util.precoBR(String(obj.total_price)) : null);
      let tipo = null;
      const ev = String(obj.event).toLowerCase();
      if (/enter|entrou|join/.test(ev)) tipo = 'entrou';
      else if (/click|clique|tap/.test(ev)) tipo = 'clique';
      else if (/cart|carrinho|add_to_cart/.test(ev)) tipo = 'carrinho';
      else if (/order|venda|purchase|paid/.test(ev)) tipo = 'venda';
      if (tipo) CL.bus.publicar('atividade', {
        tipo,
        nome: CL.util.nomeSeguro(nome),
        produtoId,
        valor: valor || null,
        messageId: obj.message_id || obj.msg_id || '',
        ts: Date.now(),
      });
    }
  }

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    const d = ev.data;
    if (!d.__pt_livefeed) return;
    if (!d.token || d.token !== CL.api.capToken()) return;

    if (d.dados && d.dados.tipo === 'ws-bin' && Array.isArray(d.dados.bytes)) {
      const obj = parseSolto(d.dados.bytes);
      if (obj) processar(obj);
      else if (!avisouParse) {
        avisouParse = true;
        CL.portas && CL.portas.feed('coletor', 'Frames da live vieram num formato nao reconhecido — reserva DOM ativa.');
      }
    } else if (d.dados && d.dados.tipo === 'ws-txt' && d.dados.texto) {
      try { processar(JSON.parse(d.dados.texto)); } catch (_) {}
    }
  });

  // netcap tambem manda __pt_netcap com respostas do fetch — algumas rotas
  // trazem stats/atividade tambem. Fica de reserva.
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data || !ev.data.__pt_netcap) return;
    if (!ev.data.token || ev.data.token !== CL.api.capToken()) return;
    const en = ev.data.entry;
    if (!en || !en.resp) return;
    if (en.url && (/\/product_stats/i.test(en.url) || /\/room\/activity/i.test(en.url))) {
      try { processar(JSON.parse(en.resp)); } catch (_) {}
    }
  });
})();
