/*
 * coletor-room.js — sala + numeros oficiais. Poll a cada 5s (sala) e 10s
 * (numeros). Publica 'sala' e 'oficial' no barramento. Nao decide nada.
 *
 * Rotas usadas (TikTok Shop, medidas na captura de 03/08):
 *   GET  live_room_info/get         -> {room_id, live_room_info.start_time, ...}
 *   POST insights/api/v1/live/room/status  {room_id} -> {status, ended_at, ...}
 *   POST insights/api/v1/live/core/stats   {room_id} -> {gmv, itens, ...}
 *
 * status 1 = ao vivo | status 3 = encerrada. Qualquer outro -> "na duvida, nao
 * decide nada", nao publica sala com aoVivo.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.bus || !CL.api || !CL.repetir) return;

  let ultimoRoomId = '';
  let ultimoStatus = 0;
  let apiStartTs = 0;

  async function pollRoom() {
    try {
      const r = await CL.api.call('live_room_info/get', 'GET');
      if (!CL.api.ok(r)) return;
      const d = (r.data && r.data.data) || {};
      const info = (d.live_room_info && typeof d.live_room_info === 'object') ? d.live_room_info : d;
      const rid = typeof d.room_id === 'string' ? d.room_id : (typeof info.room_id === 'string' ? info.room_id : '');
      // start_time (segundos) — sanidade
      const stSeg = Number(info.start_time || d.start_time || 0);
      if (rid && stSeg > 1e9) {
        const ms = stSeg * 1000;
        if (ms < Date.now() + 120_000 && Date.now() - ms < 48 * 3600 * 1000) apiStartTs = ms;
      }

      // room/status oficial
      let status = 0;
      if (rid) {
        const rs = await CL.api.call('/api/v1/insights/live/room/status', 'POST', { room_id: rid });
        if (CL.api.ok(rs)) {
          const dd = (rs.data && rs.data.data) || {};
          status = Number(dd.status || 0);
        }
      }

      if (rid !== ultimoRoomId || status !== ultimoStatus) {
        const aoVivo = status === 1;
        CL.bus.publicar('sala', {
          roomId: rid,
          aoVivo,
          startTs: apiStartTs,
          status,
        });
        // eventos de vida (transicoes)
        if (ultimoStatus !== 1 && status === 1) CL.bus.publicar('vida', { evento: 'live-comecou', roomId: rid });
        if (ultimoStatus === 1 && status !== 1) CL.bus.publicar('vida', { evento: 'live-acabou', roomId: rid, ultStatus: status });
        ultimoRoomId = rid;
        ultimoStatus = status;
      }
    } catch (_) {}
  }

  async function pollNumeros() {
    if (!ultimoRoomId || ultimoStatus !== 1) return;
    try {
      const r = await CL.api.call('/api/v1/insights/live/core/stats', 'POST', { room_id: ultimoRoomId });
      if (!CL.api.ok(r)) return;
      const d = (r.data && r.data.data) || {};
      CL.bus.publicar('oficial', {
        gmv: d.gmv || d.total_gmv || null,
        itens: d.item_num || d.itens || null,
        assistiram: d.total_view_uv || null,
        exibicoes: d.total_view_pv || null,
      });
    } catch (_) {}
  }

  // so roda em TikTok Shop (rotas insights/live_room_info sao dele). Em
  // YouTube/site proprio, o adapter da plataforma preenche CL.state direto.
  function podeRodar() {
    return CL.plataforma && (CL.plataforma.nome === 'tiktok-shop');
  }

  if (CL.vida && CL.vida.IS_TOP && podeRodar()) {
    CL.repetir(pollRoom, 5000);
    CL.repetir(pollNumeros, 10_000);
    pollRoom();
  }
})();
