/*
 * barramento.js — barramento pub/sub minimalista.
 *
 * Regra unica: um assinante que quebra nao derruba os outros. Cada entrega roda
 * dentro do proprio try/catch. Coletores publicam UMA vez; quantos motores
 * quiserem assinam. Nenhuma decisao mora aqui.
 *
 * Timers da extensao nascem em CL.repetir para que desligarTudo() consiga
 * parar tudo de uma vez (nada de setInterval solto sem dono).
 */
(() => {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (CL.bus) return; // idempotente: recarga de frame nao duplica o barramento

  const canais = new Map();

  CL.bus = {
    assinar(canal, fn) {
      if (typeof fn !== 'function') return () => {};
      let lista = canais.get(canal);
      if (!lista) { lista = []; canais.set(canal, lista); }
      lista.push(fn);
      return () => {
        const l = canais.get(canal);
        if (!l) return;
        const i = l.indexOf(fn);
        if (i >= 0) l.splice(i, 1);
      };
    },
    publicar(canal, dado) {
      const lista = canais.get(canal);
      if (!lista || !lista.length) return;
      for (const fn of lista.slice()) {
        try { fn(dado); } catch (_) {}
      }
    },
    canais() { return Array.from(canais.keys()); },
  };

  // ------- registro de motores -------
  const motores = [];
  CL.registrarMotor = (m) => {
    if (!m || !m.nome) return;
    if (motores.some((x) => x.nome === m.nome)) return; // um motor por nome
    motores.push(m);
  };
  CL.motores = () => motores.slice();

  // ------- timers com dono -------
  const timers = new Set();
  let mortos = false;
  CL.repetir = (fn, ms) => {
    if (mortos) return null;
    const id = setInterval(() => { try { fn(); } catch (_) {} }, ms);
    timers.add(id);
    return id;
  };
  CL.esperar = (fn, ms) => {
    if (mortos) return null;
    const id = setTimeout(() => {
      timers.delete(id);
      try { fn(); } catch (_) {}
    }, ms);
    timers.add(id);
    return id;
  };
  CL.pararTimer = (id) => {
    if (id == null) return;
    clearInterval(id);
    clearTimeout(id);
    timers.delete(id);
  };
  CL.matarTimers = () => {
    mortos = true;
    for (const id of timers) { clearInterval(id); clearTimeout(id); }
    timers.clear();
  };
})();
