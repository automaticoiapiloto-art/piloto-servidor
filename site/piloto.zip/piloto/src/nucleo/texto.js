/*
 * texto.js — funcoes puras (sem estado) compartilhadas: preco, normalizacao,
 * casamento de gatilho, nome seguro, sanitizacao de texto de chat.
 *
 * Regra: NADA aqui guarda memoria entre chamadas. Qualquer motor pode chamar.
 */
(() => {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (CL.util && CL.util.precoBR) return;
  CL.util = CL.util || {};

  // "R$ 54,99" -> 54.99. Formato brasileiro: ponto = milhar, virgula = decimal.
  CL.util.precoBR = function precoBR(txt) {
    if (typeof txt !== 'string') return null;
    const m = txt.match(/(\d[\d.]*,\d{2}|\d[\d.]*)/);
    if (!m) return null;
    const n = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
    return Number.isFinite(n) && n > 0 ? n : null;
  };

  // minusculas + sem acento — pra COMPARACAO, nunca pra exibicao
  CL.util.normalizar = function normalizar(s) {
    return (s || '').toString().toLowerCase()
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/\s+/g, ' ').trim();
  };

  // acha `alvo` (ja normalizado) como PALAVRA CRUA em `texto` — bordas em
  // nao-letra/digito. "cor" casa "qual cor?" mas NAO "correr"/"decorar".
  function palavraCrua(texto, alvo) {
    const isLetra = (c) => (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
    let de = 0;
    for (;;) {
      const i = texto.indexOf(alvo, de);
      if (i < 0) return false;
      const antes = i === 0 ? '' : texto[i - 1];
      const dps = i + alvo.length >= texto.length ? '' : texto[i + alvo.length];
      if (!isLetra(antes) && !isLetra(dps)) return true;
      de = i + 1;
    }
  }
  CL.util.palavraCrua = palavraCrua;

  // Gatilho de Q&A: 1) texto puro (>= 2 chars) casa como palavra crua;
  //                 2) combo "tamanho+p+numeracao" — todas as partes na mesma frase.
  CL.util.matchGatilho = function matchGatilho(comentario, gatilho) {
    const t = CL.util.normalizar(comentario);
    const g = CL.util.normalizar(gatilho);
    if (!t || !g) return false;
    if (g.indexOf('+') > 0) {
      const partes = g.split('+').map((s) => s.trim()).filter(Boolean);
      if (!partes.length) return false;
      return partes.every((p) => palavraCrua(t, p));
    }
    if (g.length < 2) return false; // 1 char sozinho casa demais
    return palavraCrua(t, g);
  };

  // Nome de comprador vindo do TikTok e' cru: HTML-decode + tira invisiveis.
  // Retorna string vazia pra qualquer coisa suspeita (proibido citar "").
  const INVISIVEIS = /[​-‏‪-‮⁠-⁤﻿]/g;
  CL.util.nomeSeguro = function nomeSeguro(nome) {
    if (typeof nome !== 'string') return '';
    let s = nome.replace(INVISIVEIS, '').replace(/\s+/g, ' ').trim();
    if (!s || s.length > 60) return '';
    // proibido nome que e so pontuacao/emojis (nada pra chamar no chat)
    if (!/[A-Za-z0-9À-ſ]/.test(s)) return '';
    return s;
  };

  // Produto do catalogo: recorta ate 40 chars do 1o pedaco significativo do titulo,
  // preservando palavra inteira.
  CL.util.produtoSeguro = function produtoSeguro(titulo) {
    if (typeof titulo !== 'string') return '';
    const t = titulo.replace(INVISIVEIS, '').replace(/\s+/g, ' ').trim();
    if (!t) return '';
    if (t.length <= 40) return t;
    const corte = t.slice(0, 40);
    const ult = corte.lastIndexOf(' ');
    return (ult > 10 ? corte.slice(0, ult) : corte) + '...';
  };

  // Renderiza template com placeholders {nome}/{produto}/{preco}. Se um placeholder
  // resolve pra vazio, o template inteiro devolve null — nunca chame nome no chat
  // com o texto do placeholder aparecendo cru.
  CL.util.renderTemplate = function renderTemplate(tpl, vars) {
    if (typeof tpl !== 'string' || !tpl) return null;
    let faltou = false;
    const saida = tpl.replace(/\{(\w+)\}/g, (_, k) => {
      const v = vars && vars[k];
      if (v == null || v === '') { faltou = true; return ''; }
      return String(v);
    });
    if (faltou) return null;
    return saida;
  };

  // Comparador estavel de listas de produtos (id+preco): ordena por id antes de
  // concatenar — a API pode devolver a mesma vitrine em ordens diferentes.
  CL.util.assinaturaVitrine = function assinaturaVitrine(lista) {
    if (!Array.isArray(lista)) return '';
    return lista.map((p) => `${p.id}:${p.preco || 0}`).sort().join('|');
  };
})();
