/*
 * coletor-vitrine.js — poll a cada 5s de live_product/list. Publica 'vitrine'
 * apenas quando a lista MUDA (assinatura por ids+precos).
 *
 * Se a rota devolve 200 + corpo vazio (recusa silenciosa por falta de header
 * x-tt-store-region), publica UM aviso no feed e continua tentando.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.bus || !CL.api || !CL.repetir || !CL.util) return;

  let ultimaAssinatura = '';
  let avisouVazio = false;
  const diag = { ok: 0, falha: 0, vazio: 0 };

  async function poll() {
    if (!CL.vida || !CL.vida.IS_TOP) return; // um puxador so
    try {
      const r = await CL.api.call('live_product/list', 'GET');
      if (r && r.vazio) {
        diag.vazio++;
        if (!avisouVazio) {
          avisouVazio = true;
          CL.portas && CL.portas.feed('vitrine', 'Nao consegui ler a sacolinha (recursos que dependem da lista podem falhar).');
        }
        return;
      }
      if (!CL.api.ok(r)) { diag.falha++; return; }
      const prods = ((r.data && r.data.data && r.data.data.products) || []).map((p, i) => ({
        id: String(p.product_id || p.id || ''),
        titulo: String(p.title || p.product_name || ''),
        preco: CL.util.precoBR(String(p.formatted_price || p.price || '')) || Number(p.price_cent ? p.price_cent / 100 : 0),
        indice: i,
      })).filter((p) => p.id);

      const ass = CL.util.assinaturaVitrine(prods);
      if (ass !== ultimaAssinatura) {
        ultimaAssinatura = ass;
        CL.bus.publicar('vitrine', prods);
      }
      diag.ok++;
    } catch (_) { diag.falha++; }
  }

  // vitrine so existe em TikTok Shop
  if (CL.plataforma && CL.plataforma.nome === 'tiktok-shop') {
    CL.repetir(poll, 5000);
    poll();
  }

  CL._diagVitrine = () => Object.assign({}, diag);
})();
