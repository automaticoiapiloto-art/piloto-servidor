/*
 * plano.js — CL.plano: decide o que cada plano de licenca desbloqueia.
 *
 * O servidor emite chaves carimbadas com um `plano` (basico/pro/premium/dev).
 * O motor consulta CL.plano.permite('nome-da-feature') antes de ligar features
 * avancadas. NAO substitui a trava de licenca (que bloqueia acao quando lic
 * bloqueada) — decide o que cada nivel oferece quando lic ativa.
 *
 * O plano vivo eh publicado pelo license.js no barramento 'licenca:info'
 * ({plano, exp, chave}). Se nao chega, assume 'basico' (fail-restrict pra
 * features caras, fail-open pra features basicas).
 */
(() => {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (CL.plano) return;

  // matriz plano -> features permitidas.
  // Ajustar aqui quando quiser mudar o pacote de venda.
  const MATRIZ = {
    dev: {
      // dev libera tudo — usado no test/dono
      _tudo: true,
    },
    trial: {
      fixador: true,
      respostas: true,
      mensagens: true,
      moderacao: true,
      // NAO libera: vcam, simulive, espelho, kit-vitrine, oferta-relampago
    },
    basico: {
      fixador: true,
      respostas: true,
      mensagens: true,
      moderacao: true,
      carrinho: true,
      'venda-chat': true,
      dinheiro: true,
      'chat-liberado': true,
      'guardiao-aviso': true,
      'tempo-live': true,
    },
    pro: {
      // basico +
      vcam: true,
      simulive: true,
      espelho: true,
      oferta: true,
      ia: true,
      _herda: 'basico',
    },
    premium: {
      // tudo (equivalente ao dev, mas com validade)
      _tudo: true,
    },
  };

  function planoAtual() {
    const cfg = CL.cfg && CL.cfg();
    return (cfg && cfg.licenca && cfg.licenca.plano) || 'trial';
  }

  function permite(feature) {
    const nome = planoAtual();
    let cur = MATRIZ[nome] || MATRIZ.trial;
    // segue heranca
    for (let i = 0; i < 5; i++) {
      if (cur._tudo) return true;
      if (cur[feature]) return true;
      if (cur._herda) cur = MATRIZ[cur._herda] || {};
      else break;
    }
    return false;
  }

  function upgrade(feature) {
    return {
      motivo: 'plano-insuficiente',
      feature,
      atual: planoAtual(),
      mensagem: 'Este recurso exige um plano superior.',
    };
  }

  CL.plano = {
    atual: planoAtual,
    permite,
    upgrade,
    matriz: () => JSON.parse(JSON.stringify(MATRIZ)),
  };

  // consome 'licenca:info' do license.js e persiste o plano em cfg
  if (CL.bus) {
    CL.bus.assinar('licenca:info', (info) => {
      if (!info || !info.plano) return;
      // se plano mudou, publica no cfg pra os motores que checam ligado(cfg)
      const cfg = CL.cfg && CL.cfg();
      if (cfg && cfg.licenca && cfg.licenca.plano !== info.plano) {
        CL.setCfg && CL.setCfg({ licenca: { plano: info.plano, exp: info.exp || 0 } });
      }
    });
  }
})();
