/*
 * transporte.js — CL.api: fala com apibridge.js (mundo da pagina) para leituras
 * e acoes que precisam da assinatura da pagina do TikTok (X-Bogus/msToken).
 *
 * Todo motor que precisa bater na API do TikTok chama CL.api.call — ele NAO
 * conhece apibridge, so o CL.api. Assim, quando trocarmos de plataforma
 * (YouTube nao usa X-Bogus), so o adapter muda.
 *
 * Canal com netcapture/vcam/apibridge: CAP_TOKEN unico. O content.js anuncia
 * via __cl_capctl no boot; sem token no anuncio, ninguem responde.
 */
(() => {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (CL.api) return;

  // segredo do canal (mesmo token que o content.js anuncia via __cl_capctl)
  const CAP_TOKEN = (self.crypto && crypto.randomUUID)
    ? crypto.randomUUID()
    : 'pt-' + Math.random().toString(36).slice(2) + Date.now().toString(36);

  const pendentes = new Map();
  let seq = 0;

  window.addEventListener('message', (ev) => {
    if (ev.source !== window) return;
    const d = ev.data;
    if (!d || !d.__pt_apires) return;
    if (d.token !== CAP_TOKEN) return;
    const done = pendentes.get(d.id);
    if (!done) return;
    pendentes.delete(d.id);
    done(d.ok ? d.payload : null);
  });

  function chamar(path, method, body, timeoutMs) {
    return new Promise((resolve) => {
      const id = 'a' + (++seq);
      pendentes.set(id, resolve);
      try {
        window.postMessage({
          __pt_apireq: true,
          token: CAP_TOKEN,
          id,
          path,
          method: method || 'GET',
          body: body || null,
        }, location.origin);
      } catch (_) {}
      setTimeout(() => {
        if (!pendentes.has(id)) return;
        pendentes.delete(id);
        resolve(null);
      }, timeoutMs || 8000);
    });
  }

  function ok(r) {
    if (!r) return false;
    if (typeof r === 'object' && r.error) return false;
    if (r.data && (r.data.code === 0 || r.data.status_code === 0)) return true;
    if (r.status_code === 0 || r.code === 0) return true;
    return !!r;
  }

  // capToken: usado pelos coletores (netcapture/vcam) pra validar o canal
  // __cl_livefeed/__cl_vcam com o MESMO segredo do content.js.
  CL.api = {
    call: chamar,
    ok,
    capToken: () => CAP_TOKEN,
    // "estado da via direta" — o apibridge pode reportar se cada rota ja passou
    // por auditoria (modo prova). Fica opcional.
    viaDireta: () => ({}),
  };

  // publica o token no barramento assim que a pagina carrega — quem monta
  // apibridge/netcapture/vcam ouve o __pt_capctl e passa a aceitar CAP_TOKEN.
  function anunciar() {
    try {
      window.postMessage({ __pt_capctl: true, token: CAP_TOKEN, enabled: true, feed: true }, location.origin);
    } catch (_) {}
  }
  anunciar();
  // re-anuncia periodicamente: apibridge pode carregar depois em iframes tardios
  if (CL.repetir) CL.repetir(anunciar, 5000);
  else setInterval(anunciar, 5000);
})();
