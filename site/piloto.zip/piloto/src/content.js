/*
 * content.js — a COLA. Ultimo script carregado no mundo isolado.
 *
 * O que ele faz:
 *   1. Escolhe o adapter de plataforma (TikTok Shop / YouTube / proprio) a
 *      partir da URL da pagina e injeta como CL.plataforma.
 *   2. Chama iniciar() em cada motor registrado, quando a config permitir.
 *   3. Escuta mensagens do popup e do background (comandos + config).
 *   4. Vigia se a extensao foi desativada (porta 'pt-vivo' com o background).
 *
 * Regra: content nao decide nada de motor. Ele so' liga a maquina — motor
 * decide pela propria fatia de cfg se roda ou nao no seu tick.
 */
(() => {
  'use strict';
  const CL = (self.CL = self.CL || {});

  // ---------- escolhe adapter de plataforma pela URL ----------
  function detectarPlataforma() {
    const h = location.hostname;
    if (h.indexOf('shop.tiktok.com') >= 0 || h.indexOf('seller-br.tiktok.com') >= 0) return 'tiktok-shop';
    if (h.indexOf('business.tiktokshop.com') >= 0) return 'tiktok-shop';
    if (h === 'live.tiktok.com' || (/tiktok\.com$/.test(h) && /\/live\/?$/i.test(location.pathname))) return 'tiktok-live';
    if (h.indexOf('studio.youtube.com') >= 0) return 'youtube-studio';
    if (h.indexOf('youtube.com') >= 0) return 'youtube';
    return 'desconhecida';
  }
  const plataformaAtiva = detectarPlataforma();

  // adapter padrao (vazio) — os arquivos em src/plataformas/*.js sobrescrevem
  // CL.plataforma quando detectam que a pagina eh a deles. Aqui fica o fallback
  // pra qualquer motor que peca uma porta antes de o adapter carregar.
  if (!CL.plataforma) {
    CL.plataforma = {
      nome: plataformaAtiva,
      async postarChat() { return false; },
      async fixar() { return false; },
      async fixarLista() { return false; },
      async desfixar() { return false; },
      async recolocarKit() { return false; },
      async encerrarLive() { return false; },
      async lerViolacoes() { return null; },
      async bloquearUsuario() { return false; },
      async ajustarChat() { return false; },
      async iniciarLive() { return false; },
    };
  }

  // ---------- inicia motores conforme cfg ----------
  const motoresLigados = new Set();
  function tickIniciar() {
    if (!CL.cfgCarregado || !CL.cfgCarregado()) return;
    const cfg = CL.cfg();
    for (const m of CL.motores()) {
      if (motoresLigados.has(m.nome)) continue;
      let ligar = true;
      if (typeof m.ligado === 'function') {
        try { ligar = !!m.ligado(cfg); } catch (_) { ligar = false; }
      }
      if (!ligar) continue;
      try {
        m.iniciar && m.iniciar();
        motoresLigados.add(m.nome);
      } catch (_) {}
    }
  }
  // 1a chamada quando o cfg carregar; depois a cada 3s (motor novo virou true)
  if (CL.onCfgChange) CL.onCfgChange(tickIniciar);
  if (CL.repetir) CL.repetir(tickIniciar, 3000);
  tickIniciar();

  // ---------- desligar tudo (reload/nova live pode chamar) ----------
  function resetPorLive() {
    for (const m of CL.motores()) {
      try { m.resetPorLive && m.resetPorLive(); } catch (_) {}
    }
  }
  if (CL.bus) {
    CL.bus.assinar('vida', (v) => {
      if (v && v.evento === 'live-comecou') resetPorLive();
    });
  }

  // ---------- ponte com o painel (side panel) via runtime ----------
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.__piloto) return;
    if (msg.kind === 'diag') {
      const st = CL.state || {};
      const cfg = CL.cfg && CL.cfg();
      const licInfo = (cfg && cfg.licenca) || {};
      // olha o snapshot da vida pra saber se lic ta bloqueada
      let bloqueada = false;
      try { const v = CL.vida._snapshot(); bloqueada = v.licBloqueada; } catch (_) {}
      // plano real: le do token gravado pelo license.js (que tem a verdade)
      // e cacheia pra o proximo tick (evita async no diag)
      chrome.storage.local.get('piloto_license_v1').then((r) => {
        const s = r.piloto_license_v1;
        if (s && s.tokenPayload && s.tokenPayload.plano) {
          self.__pilotoLic = { plano: s.tokenPayload.plano, exp: s.tokenPayload.exp || 0 };
        }
      }).catch(() => {});
      const licReal = self.__pilotoLic || {};
      const dg = {
        plataforma: plataformaAtiva,
        aoVivo: CL.vida && CL.vida.aoVivo(),
        roomId: CL.vida && CL.vida.roomId(),
        licenca: {
          plano: licReal.plano || licInfo.plano || 'trial',
          exp: licReal.exp || licInfo.exp || 0,
          bloqueada,
        },
        state: {
          assistiramTotal: st.assistiramTotal,
          exibicoes: st.exibicoes,
          gmvOficial: st.gmvOficial,
          itensOficial: st.itensOficial,
          salesCount: st.salesCount,
          salesTotal: st.salesTotal,
          chatAvisosVenda: st.chatAvisosVenda,
        },
        motores: CL.motores().map((m) => ({
          nome: m.nome,
          ligado: motoresLigados.has(m.nome),
          diag: (() => { try { return m.diag ? m.diag() : null; } catch (_) { return null; } })(),
        })),
      };
      sendResponse(dg);
      return true;
    }
    if (msg.kind === 'lerLeads') {
      const leads = (CL.state && CL.state.leads) || [];
      sendResponse({ leads: leads.slice(0, 100) });
      return true;
    }
    if (msg.kind === 'simularChat' && CL.bus) {
      CL.bus.publicar('tela:chat', { autor: msg.autor || 'teste', texto: msg.texto || '', ts: Date.now() });
      sendResponse({ ok: true });
      return true;
    }
    if (msg.kind === 'cfgPatch' && msg.patch) {
      CL.setCfg && CL.setCfg(msg.patch).then(() => sendResponse({ ok: true }));
      return true; // resposta assincrona
    }
    if (msg.kind === 'comando') {
      // comandos do painel: 'iniciarLive'|'pararLive'|'encerrarAgora'|'pausar'|'retomar'
      if (CL.bus) CL.bus.publicar('painel:comando', msg);
      sendResponse({ ok: true });
      return true;
    }
    return false;
  });

  // ---------- vigia se a extensao morreu (porta com o background) ----------
  function vigiarExtensao() {
    try {
      const p = chrome.runtime.connect({ name: 'pt-vivo' });
      p.onDisconnect.addListener(() => {
        // se caiu, pode ser reload de extensao — tenta reabrir depois de 5s
        setTimeout(vigiarExtensao, 5000);
      });
    } catch (_) {
      setTimeout(vigiarExtensao, 5000);
    }
  }
  vigiarExtensao();

  // sinal pro popup: "boot do content ok" (usado no health-check)
  try {
    chrome.runtime.sendMessage({ __piloto: true, kind: 'boot', plataforma: plataformaAtiva, url: location.href });
  } catch (_) {}

  // ---------- ponte com vcam.js (world: MAIN) ----------
  // O video foi gravado pelo popup no IndexedDB. Aqui a gente le o blob e
  // manda pro vcam via blob URL + postMessage __pt_vcam com a config.
  let vcamBlobUrl = '';
  let vcamVideoIdAtual = '';

  function abrirDB() {
    return new Promise((r, rj) => {
      const req = indexedDB.open('piloto', 1);
      req.onupgradeneeded = () => { req.result.createObjectStore('videos', { keyPath: 'id' }); };
      req.onsuccess = () => r(req.result);
      req.onerror = () => rj(req.error);
    });
  }
  async function lerVideo(id) {
    if (!id) return null;
    const db = await abrirDB();
    return new Promise((res, rj) => {
      const tx = db.transaction('videos', 'readonly');
      const req = tx.objectStore('videos').get(id);
      req.onsuccess = () => res(req.result ? req.result.blob : null);
      req.onerror = () => rj(req.error);
    });
  }

  async function aplicarVcam() {
    const feed = (msg) => { try { CL.portas && CL.portas.feed && CL.portas.feed('vcam-content', msg); } catch (_) {} };
    const cfg = CL.cfg && CL.cfg();
    if (!cfg || !cfg.vcam) { feed('sem cfg.vcam — toggle nunca foi ligado?'); return; }
    const querLigada = !!cfg.vcam.enabled;
    const videoId = cfg.vcam.videoId || '';
    feed('cfg lido: enabled=' + querLigada + ' videoId=' + (videoId ? videoId.slice(0, 8) + '...' : 'VAZIO'));

    // se o videoId mudou, cria novo blobUrl
    if (videoId !== vcamVideoIdAtual) {
      if (vcamBlobUrl) { try { URL.revokeObjectURL(vcamBlobUrl); } catch (_) {} vcamBlobUrl = ''; }
      vcamVideoIdAtual = videoId;
      if (videoId) {
        try {
          const blob = await lerVideo(videoId);
          if (blob) {
            vcamBlobUrl = URL.createObjectURL(blob);
            feed('blob lido do IndexedDB — ' + (blob.size / 1024 / 1024).toFixed(1) + ' MB');
          } else {
            feed('IndexedDB devolveu NULL — video sumiu?');
          }
        } catch (e) {
          feed('erro no IndexedDB: ' + ((e && e.message) || e));
        }
      }
    }

    // Se o usuario logou por email/senha (piloto_conta_v1 com sessao valida),
    // NUNCA considera licenca bloqueada — o servidor ja validou no login.
    // Assim a vcam nao trava mesmo que o license.js oscile trial/bloqueada.
    let licBloq = !!(CL.vida && CL.vida.licBloqueada && CL.vida.licBloqueada('camera virtual'));
    try {
      const rConta = await chrome.storage.local.get('piloto_conta_v1');
      const c = rConta && rConta.piloto_conta_v1;
      if (c && c.tokenSessao && c.ate > Math.floor(Date.now() / 1000)) licBloq = false;
    } catch (_) {}
    const willEnable = querLigada && !!vcamBlobUrl;
    feed('mandando pro vcam: enabled=' + willEnable + ' blobUrl=' + (!!vcamBlobUrl) + ' licBloqueada=' + licBloq);

    // anuncia pro vcam.js (world MAIN)
    const token = (CL.api && CL.api.capToken && CL.api.capToken()) || '';
    if (!token) feed('SEM TOKEN — vcam vai ignorar mensagem!');
    try {
      window.postMessage({
        __pt_vcam: true,
        token,
        cfg: {
          enabled: willEnable,
          licBloqueada: licBloq,
          loop: cfg.vcam.loop !== false,
          blobUrl: vcamBlobUrl,
        },
      }, location.origin);
    } catch (e) { feed('postMessage falhou: ' + ((e && e.message) || e)); }
  }

  function comandoVcam(cmd) {
    const token = (CL.api && CL.api.capToken && CL.api.capToken()) || '';
    try {
      window.postMessage({ __pt_vcamcmd: true, token, cmd }, location.origin);
    } catch (_) {}
  }

  if (CL.onCfgChange) CL.onCfgChange(aplicarVcam);
  aplicarVcam();

  // quando a live comeca, manda restart no vcam pra o video pegar do zero
  if (CL.bus) {
    CL.bus.assinar('vida', (v) => {
      if (v && v.evento === 'live-comecou') comandoVcam('restart');
    });
  }

  // painel pode mandar comando de vcam (play/pause/reset via mensagem tab)
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || !msg.__piloto || msg.kind !== 'vcamcmd') return;
    comandoVcam(msg.cmd);
  });

  // popup envia video em chunks (ArrayBuffer). Reconstruimos Blob no
  // IndexedDB da PÁGINA (mesma origem do vcam). O structured clone quebra o
  // File direto pra arquivos grandes — ArrayBuffer sobrevive.
  const uploadsEmCurso = new Map(); // id -> {name, mime, size, totalChunks, chunks: []}
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.__piloto) return;
    const feed = (m) => { try { CL.portas && CL.portas.feed && CL.portas.feed('vcam-content', m); } catch (_) {} };

    if (msg.kind === 'saveVideoInit') {
      uploadsEmCurso.set(msg.id, {
        name: msg.name || 'video',
        mime: msg.mime || 'video/mp4',
        size: msg.size || 0,
        totalChunks: msg.totalChunks || 0,
        chunks: new Array(msg.totalChunks || 0),
      });
      feed('upload iniciado: ' + msg.id + ' (' + msg.totalChunks + ' chunks)');
      sendResponse({ ok: true });
      return true;
    }

    if (msg.kind === 'saveVideoChunk') {
      const up = uploadsEmCurso.get(msg.id);
      if (!up) { sendResponse({ ok: false, error: 'upload nao iniciado' }); return true; }
      const bytes = msg.buffer && msg.buffer.byteLength ? msg.buffer.byteLength : 0;
      up.chunks[msg.index] = msg.buffer;
      up.bytesRecebidos = (up.bytesRecebidos || 0) + bytes;
      if (msg.index === 0) feed('primeiro chunk recebido: ' + bytes + ' bytes (buffer is ArrayBuffer? ' + (msg.buffer instanceof ArrayBuffer) + ')');
      if (msg.index % 100 === 0 || msg.index === up.totalChunks - 1) feed('chunk ' + msg.index + ': +' + bytes + ' bytes, acumulado ' + (up.bytesRecebidos / 1024 / 1024).toFixed(1) + ' MB');
      sendResponse({ ok: true });
      return true;
    }

    if (msg.kind === 'saveVideoDone') {
      const up = uploadsEmCurso.get(msg.id);
      if (!up) { sendResponse({ ok: false, error: 'upload nao iniciado' }); return true; }
      (async () => {
        try {
          for (let i = 0; i < up.totalChunks; i++) {
            if (!up.chunks[i]) throw new Error('chunk ' + i + ' faltando');
          }
          const blob = new Blob(up.chunks, { type: up.mime });
          feed('blob montado ' + (blob.size / 1024 / 1024).toFixed(1) + ' MB — gravando IndexedDB...');
          const db = await abrirDB();
          const tx = db.transaction('videos', 'readwrite');
          tx.objectStore('videos').put({ id: msg.id, blob, name: up.name, at: Date.now() });
          await new Promise((r, rj) => { tx.oncomplete = r; tx.onerror = () => rj(tx.error); });
          uploadsEmCurso.delete(msg.id);
          feed('video salvo no IndexedDB da pagina: ' + msg.id);
          sendResponse({ ok: true, id: msg.id });
        } catch (e) {
          uploadsEmCurso.delete(msg.id);
          sendResponse({ ok: false, error: (e && e.message) || String(e) });
        }
      })();
      return true;
    }
  });

  // recebe diagnostico do vcam.js e publica no feed do painel
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data || !ev.data.__pt_vcamdiag) return;
    const { etapa, extra } = ev.data;
    let txt = 'vcam: ' + etapa;
    if (extra) txt += ' ' + JSON.stringify(extra);
    try { CL.portas && CL.portas.feed && CL.portas.feed('vcam', txt); } catch (_) {}
  });
})();
