/*
 * storage.js — CL.cfg / CL.setCfg / CL.onCfgChange. Config em chrome.storage.local,
 * espelhada em memoria pra leitura sincrona (motor decide se roda ou nao no seu
 * proprio passo — nao pode aguardar Promise a cada tick).
 *
 * Chave: 'piloto_config_v1'. Estrutura abaixo (DEFAULT_CFG) e o que cada motor
 * espera achar. Ao adicionar campo novo: coloque o default aqui.
 */
;(function () {
  const CL = (self.CL = self.CL || {});
  if (CL.cfg && CL.setCfg) return;

  const KEY = 'piloto_config_v1';

  const DEFAULT_CFG = {
    plataforma: 'tiktok-shop', // tiktok-shop | tiktok-live | youtube | proprio
    rePin: {
      enabled: false,
      modo: 'produto', // 'produto' | 'lista'
      productId: '',
      intervalSec: 10,
      blink: false,
      delaySec: 3,
      aleatorio: false,
    },
    vitrineKit: {
      enabled: false,
      setId: '',
      setNome: '',
      fecharResumo: true,
    },
    flashOffer: { enabled: false },
    autoEnd: { enabled: false, endAtTs: 0 },
    autoStart: {
      enabled: false,
      series: [], // [{id, nome, tsInicio, tsFim, videoId, disparado, encerradoDisparado}]
      repetir: 0, // 0 = uma vez, 1..N = repete no dia seguinte etc
    },
    chat: {
      broadcast: {
        enabled: false,
        minSec: 60,
        maxSec: 180,
        randomize: true,
        messages: [], // [{id, text, enabled}]
      },
      qa: {
        enabled: false,
        respostas: [], // [{id, gatilhos:[], resposta, produtoId?, enabled}]
      },
      saleAlert: { enabled: false, template: 'Vendido para {nome}!' },
      cartAlert: { enabled: false, template: '{nome} adicionou ao carrinho!' },
      ia: {
        enabled: false,
        produto: '',      // descricao do produto/servico pra a IA conhecer
        faq: '',           // perguntas frequentes + respostas ideais
        palavrasChave: '', // "CRIE, comprar, quero" — vira lead na aba Leads
      },
    },
    seguranca: {
      chatOpen: null, // null = nao mexer; true = liberar; false = fechar
      guardiaoAviso: false, // so ALERTA (violacao detectada), nao encerra sozinho
    },
    espelho: {
      enabled: false,
      pin: '', // codigo curto pra parear o PWA no celular
      servidor: '', // opcional: sobrescreve licenca.servidor pra o espelho
    },
    vcam: {
      enabled: false,
      videoId: '', // referencia ao blob salvo no IndexedDB
      loop: true,
    },
    // configuracao do adapter "site proprio" (plataformas/proprio.js)
    proprio: {
      host: '',        // parte do hostname que ativa o adapter (ex: 'meusite.com.br')
      baseUrl: '',     // endpoint base do seu backend (ex: 'https://api.meusite.com.br')
      endpoints: {     // opcional: mapeamento por rota (default = '/' + nome)
        postarChat: '/live/chat',
        fixar: '/live/fixar',
        fixarLista: '/live/fixar-lista',
        desfixar: '/live/desfixar',
        recolocarKit: '/live/kit',
        encerrarLive: '/live/encerrar',
        lerViolacoes: '/live/violacoes',
        bloquearUsuario: '/live/bloquear',
        ajustarChat: '/live/chat-abrir',
      },
      headers: {},     // opcional: {'authorization': 'Bearer ...'}
    },
    // moderacao (chat por comportamento) — usada por motores/moderacao.js
    moderacao: {
      enabled: false,
      palavras: [],
    },
    // tap periodico no video (mantem Chrome ativo + gera coracao/like)
    tap: {
      enabled: false,
      intervaloSeg: 30,
    },
    // servidor de licenca — deixe vazio pra usar o padrao embutido
    // (pilotoautomaticoia.com.br). Em dev/self-hosted, aponte pra sua URL:
    //   http://localhost:8443 (npm start no servidor local)
    //   https://api.seudominio.com.br (producao)
    licenca: {
      servidor: '',
      plano: 'trial', // 'trial'|'basico'|'pro'|'premium'|'dev'
      exp: 0,         // timestamp em segundos
    },
  };

  let cache = clonar(DEFAULT_CFG);
  let carregado = false;
  const ouvintes = new Set();

  function clonar(o) {
    try { return JSON.parse(JSON.stringify(o)); } catch (_) { return o; }
  }
  function funde(dst, src) {
    for (const k of Object.keys(src)) {
      const v = src[k];
      if (v && typeof v === 'object' && !Array.isArray(v) && dst[k] && typeof dst[k] === 'object' && !Array.isArray(dst[k])) {
        funde(dst[k], v);
      } else {
        dst[k] = v;
      }
    }
    return dst;
  }

  async function carregar() {
    try {
      const r = await chrome.storage.local.get(KEY);
      const salvo = r && r[KEY] ? r[KEY] : {};
      cache = funde(clonar(DEFAULT_CFG), salvo);
    } catch (_) {
      cache = clonar(DEFAULT_CFG);
    }
    carregado = true;
    for (const fn of ouvintes) { try { fn(cache); } catch (_) {} }
  }

  chrome.storage.onChanged.addListener((chg, area) => {
    if (area !== 'local' || !chg[KEY]) return;
    cache = funde(clonar(DEFAULT_CFG), chg[KEY].newValue || {});
    for (const fn of ouvintes) { try { fn(cache); } catch (_) {} }
  });

  CL.cfg = () => cache; // leitura sincrona (motor precisa disso a cada tick)
  CL.cfgCarregado = () => carregado;
  CL.setCfg = async (patch) => {
    const novo = funde(clonar(cache), patch || {});
    await chrome.storage.local.set({ [KEY]: novo });
    cache = novo;
    for (const fn of ouvintes) { try { fn(cache); } catch (_) {} }
    return cache;
  };
  CL.onCfgChange = (fn) => { ouvintes.add(fn); return () => ouvintes.delete(fn); };
  CL.cfgDefaults = () => clonar(DEFAULT_CFG);

  carregar();
})();
