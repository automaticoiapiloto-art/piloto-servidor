/*
 * espelho.js — publica o estado da live no servidor de espelho (PWA no celular)
 * a cada 3s e escuta comandos remotos que voltam na resposta.
 *
 * URL padrao: cfg.espelho.servidor -> cfg.licenca.servidor -> https://pilotoautomaticoia.com.br
 * Fetch sai pelo background service worker (httpProxy) — evita bloqueio de
 * mixed content quando a pagina host eh HTTPS e o servidor eh HTTP localhost.
 *
 * Comandos que voltam do PWA sao publicados no barramento 'app:comando'; motores
 * como tempo-live e guardiao decidem o que fazer com {acao:'encerrar'|'falso_alarme'}.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor) return;

  let morto = false;
  let erros = 0;

  function urlBase() {
    const cfg = CL.cfg();
    const c = cfg.espelho && cfg.espelho.servidor;
    if (c) return String(c).replace(/\/$/, '');
    const l = cfg.licenca && cfg.licenca.servidor;
    if (l) return String(l).replace(/\/$/, '');
    return 'https://pilotoautomaticoia.com.br';
  }

  function body() {
    const cfg = CL.cfg();
    const st = CL.state || {};
    return {
      pin: cfg.espelho && cfg.espelho.pin,
      aoVivo: CL.vida.aoVivo(),
      pausado: CL.vida.pausado(),
      encerrando: CL.vida.encerrando(),
      roomId: CL.vida.roomId(),
      startTs: CL.vida.startTs(),
      salesCount: st.salesCount || 0,
      salesTotal: st.salesTotal || 0,
      gmvOficial: st.gmvOficial,
      itensOficial: st.itensOficial,
      assistiramTotal: st.assistiramTotal,
      chatAvisosVenda: st.chatAvisosVenda || 0,
      salesFeed: (st.salesFeed || []).slice(0, 20),
      plataforma: CL.plataforma && CL.plataforma.nome,
      versao: (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '',
    };
  }

  async function chamar(url, payload) {
    try {
      const r = await chrome.runtime.sendMessage({
        __piloto: true, kind: 'httpProxy',
        url, method: 'POST', body: payload,
      });
      if (!r || !r.ok) return null;
      return r.payload;
    } catch (_) { return null; }
  }

  async function tick() {
    if (morto) return;
    const cfg = CL.cfg();
    if (!cfg || !cfg.espelho || !cfg.espelho.enabled) return;
    const pin = cfg.espelho.pin;
    if (!pin) return;
    if (!CL.vida.IS_TOP) return;

    const url = urlBase() + '/espelho/' + encodeURIComponent(pin);
    const j = await chamar(url, body());
    if (j == null) {
      erros++;
      if (erros >= 5 && !morto) {
        morto = true;
        CL.portas.feed('espelho', 'Espelho no celular indisponivel — verifique a URL do servidor.');
      }
      return;
    }
    erros = 0; morto = false;
    if (j.acao) CL.bus.publicar('app:comando', { acao: j.acao, texto: j.texto });
  }

  // motores que ouvem 'app:comando' (dispara acoes remotas do PWA)
  CL.bus.assinar('app:comando', (m) => {
    if (!m) return;
    if (m.acao === 'encerrar') {
      CL.portas.feed('espelho', 'Comando "encerrar" recebido do celular.');
      CL.bus.publicar('vida', { evento: 'encerrando' });
      CL.plataforma && CL.plataforma.encerrarLive && CL.plataforma.encerrarLive().catch(() => {});
    } else if (m.acao === 'falso_alarme') {
      CL.portas.feed('espelho', 'Falso alarme confirmado pelo celular.');
      CL.bus.publicar('vida', { evento: 'retomado' });
    } else if (m.acao === 'postarChat' && m.texto) {
      CL.portas.feed('espelho', 'Chat do celular: ' + m.texto.slice(0, 50));
      CL.portas.chat(m.texto, 'celular', (ok) => {
        if (!ok) CL.portas.feed('espelho', 'Nao consegui postar a mensagem do celular.');
      });
    }
  });

  CL.registrarMotor({
    nome: 'espelho',
    ligado: (cfg) => !!(cfg && cfg.espelho && cfg.espelho.enabled && cfg.espelho.pin),
    iniciar() {
      CL.repetir(tick, 3000);
      tick();
    },
    resetPorLive() { erros = 0; morto = false; },
    diag() { return { morto, erros, servidor: urlBase() }; },
  });
})();
