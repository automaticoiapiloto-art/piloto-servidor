/*
 * moderacao.js — modera o chat por COMPORTAMENTO (palavrao, ataques a
 * plataforma, spam). Nunca por identidade/suspeita de concorrencia.
 *
 * Assina 'tela:chat' e 'atividade' (quando o WS traz userId). Se o texto do
 * comentario contem uma palavra da lista negra (padrao + configurada pelo
 * vendedor), chama CL.plataforma.bloquearUsuario (pela API) OU, sem userId,
 * so posta um aviso no feed pro vendedor decidir.
 *
 * Padrao vem de UMA lista curta editavel abaixo. Voce edita no painel na aba
 * Ajustes -> "Palavras extras".
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus || !CL.util) return;

  // Lista base: intencionalmente pequena. Cobrir mais casos e' trabalho do
  // vendedor (ele conhece o publico dele). Palavrao mais forte e ataques
  // genericos a live/plataforma.
  const BASE = [
    'porra', 'caralho', 'foda-se', 'foda se', 'fdp', 'vsf', 'vtnc', 'arrombado',
    'golpe', 'golpista', 'fraude', 'roubo', 'ladrao', 'estelionato',
    'boicote', 'boicotem', 'nao comprem',
  ];
  const diag = { bloqueios: 0, avisos: 0 };
  const jaTratados = new Set();

  function palavras(cfg) {
    const extras = (cfg.moderacao && cfg.moderacao.palavras) || [];
    return BASE.concat(extras).map((p) => CL.util.normalizar(p)).filter(Boolean);
  }
  function bateu(texto, lista) {
    const t = CL.util.normalizar(texto);
    for (const p of lista) {
      if (CL.util.palavraCrua(t, p)) return p;
    }
    return null;
  }

  async function tratar(autor, userId, texto) {
    const cfg = CL.cfg();
    if (!cfg || !cfg.moderacao || !cfg.moderacao.enabled) return;
    if (!CL.vida.aoVivo() || CL.vida.pausado()) return;
    if (!CL.vida.IS_TOP) return;

    const lista = palavras(cfg);
    if (!lista.length) return;
    const pega = bateu(texto, lista);
    if (!pega) return;

    const chave = (userId || autor) + '|' + texto;
    if (jaTratados.has(chave)) return;
    jaTratados.add(chave);
    if (jaTratados.size > 2000) {
      const arr = Array.from(jaTratados);
      for (let i = 0; i < arr.length / 2; i++) jaTratados.delete(arr[i]);
    }

    if (userId) {
      const ok = await CL.plataforma.bloquearUsuario(userId, 'moderacao: ' + pega);
      if (ok) {
        diag.bloqueios++;
        CL.portas.feed('moderacao', 'Bloqueado ' + (autor || '?') + ' (' + pega + ')');
      } else {
        diag.avisos++;
        CL.portas.feed('moderacao', 'Nao consegui bloquear ' + (autor || '?') + '. Palavra: ' + pega);
      }
    } else {
      // sem userId (comentario veio so pela tela): so avisa; o TikTok nao
      // tem API pra "bloquear pelo texto do comentario", so pelo userId.
      diag.avisos++;
      CL.portas.feed('moderacao', 'Comentario suspeito de ' + (autor || '?') + ': "' + texto.slice(0, 60) + '" — bloqueie manualmente.');
    }
  }

  CL.bus.assinar('tela:chat', (m) => {
    if (!m || !m.texto) return;
    tratar(m.autor || '', '', m.texto);
  });
  CL.bus.assinar('atividade', (ev) => {
    if (!ev || (ev.tipo !== 'chat' && ev.tipo !== 'entrou')) return;
    // WS pode publicar tipo 'chat' com nome+userId+texto — se der,
    // preferimos tratar por aqui (temos o userId real pra API).
    if (ev.texto) tratar(ev.nome || '', ev.userId || '', ev.texto);
  });

  CL.registrarMotor({
    nome: 'moderacao',
    ligado: (cfg) => !!(cfg && cfg.moderacao && cfg.moderacao.enabled),
    iniciar() {},
    resetPorLive() { jaTratados.clear(); diag.bloqueios = 0; diag.avisos = 0; },
    diag() { return Object.assign({}, diag); },
  });
})();
