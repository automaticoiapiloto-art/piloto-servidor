/*
 * mensagens.js — posta mensagens programadas no chat, em intervalos aleatorios
 * entre minSec e maxSec. Rotaciona (na ordem) ou sorteia (aleatorio).
 *
 * Envio sai pela CL.portas.chat (fila unica global; a porta re-tenta 3x
 * sozinha). Este motor so decide QUAL sai e QUANDO agendar a proxima.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor) return;

  let proximoAt = 0;
  let ultimoId = null;
  const diag = { env: 0, fal: 0, gate: '?' };
  let avisoFalhando = false;

  function sortear(cfg) {
    const b = cfg.chat.broadcast;
    const min = Math.max(30, b.minSec | 0);
    const max = Math.max(min, b.maxSec | 0);
    return (min + Math.floor(Math.random() * (max - min + 1))) * 1000;
  }

  function proxima(cfg, msgs) {
    if (cfg.chat.broadcast.randomize !== false && msgs.length > 1) {
      let i, m;
      for (let n = 0; n < 8; n++) {
        i = Math.floor(Math.random() * msgs.length);
        m = msgs[i];
        if (m.id !== ultimoId) return m;
      }
      return m;
    }
    let idx = 0;
    if (ultimoId) {
      const p = msgs.findIndex((m) => m.id === ultimoId);
      if (p >= 0) idx = (p + 1) % msgs.length;
    }
    return msgs[idx];
  }

  async function passo() {
    const cfg = CL.cfg();
    if (!cfg || !cfg.chat || !cfg.chat.broadcast || !cfg.chat.broadcast.enabled) {
      proximoAt = 0; diag.gate = 'desligada'; return;
    }
    if (!CL.vida.IS_TOP) return; // 1 postador so
    if (CL.vida.pausado() || CL.vida.encerrando() || !CL.vida.aoVivo()) {
      proximoAt = 0; diag.gate = CL.vida.pausado() ? 'pausado' : 'fora-do-ar'; return;
    }
    const msgs = (cfg.chat.broadcast.messages || []).filter((m) => m.enabled !== false && m.text && m.text.trim());
    if (!msgs.length) { proximoAt = 0; diag.gate = 'sem-msgs'; return; }

    const agora = Date.now();
    if (!proximoAt) { proximoAt = agora + sortear(cfg); diag.gate = 'agendada'; return; }
    if (agora < proximoAt) { diag.gate = 'faltam ' + Math.ceil((proximoAt - agora) / 1000) + 's'; return; }

    // ja reserva a proxima antes de enviar (evita reentrada durante o envio)
    proximoAt = agora + sortear(cfg);
    const msg = proxima(cfg, msgs);

    CL.portas.chat(msg.text, 'mensagens', (ok) => {
      if (ok) {
        ultimoId = msg.id;
        diag.env++;
        diag.gate = 'ok';
        CL.portas.notificar('chat', 'Mensagem postada', msg.text.slice(0, 70));
        CL.portas.feed('msg', 'Mensagem publicada no chat');
        return;
      }
      // rotaciona pra proxima ser DIFERENTE — TikTok recusa texto identico rapido
      if (msgs.length > 1) ultimoId = msg.id;
      proximoAt = Date.now() + 3000;
      diag.fal++;
      diag.gate = 'falhou';
      if (!avisoFalhando && diag.fal >= 3) {
        avisoFalhando = true;
        CL.portas.feed('mensagens', 'Mensagem programada nao esta conseguindo postar no chat');
      }
    });
  }

  CL.registrarMotor({
    nome: 'mensagens',
    ligado: (cfg) => !!(cfg && cfg.chat && cfg.chat.broadcast && cfg.chat.broadcast.enabled),
    iniciar() {
      CL.repetir(passo, 2000);
    },
    resetPorLive() {
      proximoAt = 0; ultimoId = null;
      diag.env = 0; diag.fal = 0; diag.gate = '?';
      avisoFalhando = false;
    },
    diag() { return Object.assign({}, diag); },
  });
})();
