/*
 * tempo-live.js — cronometro, encerramento programado, inicio automatico.
 *
 * - Sabe se a live esta no ar por CL.vida (que ouve o coletor-room);
 * - Publica no barramento 'tempo' {ms, hhmmss} a cada 1s;
 * - Encerramento: se cfg.autoEnd.endAtTs cair, pede CL.plataforma.encerrarLive
 *   E arma backstop no background (chrome.alarms via 'armEnd');
 * - Inicio automatico: cada item de cfg.autoStart.series tem {ts, videoId?}.
 *   No horario, chama iniciarLive (que a Fase 5 preenche por plataforma).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor) return;

  let inicioMs = 0;
  let ultimaAoVivo = false;
  let encerrandoJa = false;
  const diag = { tempoMs: 0, autoEndAt: 0, proximoStart: 0 };

  function hhmmss(ms) {
    if (!ms || ms < 0) ms = 0;
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const ss = s % 60;
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m + ':' + (ss < 10 ? '0' : '') + ss;
  }

  function tick() {
    const cfg = CL.cfg();
    const aoVivo = CL.vida.aoVivo();
    const startTs = CL.vida.startTs();

    if (aoVivo && !ultimaAoVivo) {
      inicioMs = startTs || Date.now();
    }
    ultimaAoVivo = aoVivo;

    if (aoVivo && inicioMs) {
      const dur = Date.now() - inicioMs;
      diag.tempoMs = dur;
      CL.bus && CL.bus.publicar('tempo', { ms: dur, hhmmss: hhmmss(dur) });
    } else {
      diag.tempoMs = 0;
    }

    // encerramento programado
    if (cfg.autoEnd && cfg.autoEnd.enabled && cfg.autoEnd.endAtTs > 0) {
      diag.autoEndAt = cfg.autoEnd.endAtTs;
      if (aoVivo && Date.now() >= cfg.autoEnd.endAtTs && !encerrandoJa) {
        encerrandoJa = true;
        CL.bus.publicar('vida', { evento: 'encerrando' });
        CL.portas.feed('tempo', 'Encerrando pela agenda...');
        CL.plataforma.encerrarLive().then((ok) => {
          if (!ok) CL.portas.feed('tempo', 'Falha na chamada de encerrar — tente encerrar manualmente.');
        });
      }
    } else {
      diag.autoEndAt = 0;
    }

    // agenda automatica de lives (autoStart)
    if (cfg.autoStart && cfg.autoStart.enabled && Array.isArray(cfg.autoStart.series)) {
      const now = Date.now();
      const proximaInicio = cfg.autoStart.series
        .filter((s) => s && s.tsInicio > now && !s.disparado)
        .sort((a, b) => a.tsInicio - b.tsInicio)[0];
      diag.proximoStart = proximaInicio ? proximaInicio.tsInicio : 0;

      // 1. hora de INICIAR uma live agendada?
      const paraIniciar = cfg.autoStart.series.find((s) =>
        s && s.tsInicio > 0 && Math.abs(s.tsInicio - now) < 60_000 && !s.disparado
      );
      if (paraIniciar && !aoVivo) {
        paraIniciar.disparado = true;
        CL.setCfg({ autoStart: { series: cfg.autoStart.series } });
        CL.portas.feed('tempo', 'Iniciando "' + (paraIniciar.nome || 'live agendada') + '"');
        if (paraIniciar.videoId) CL.setCfg({ vcam: { videoId: paraIniciar.videoId, enabled: true } });
        if (CL.plataforma && CL.plataforma.iniciarLive) {
          setTimeout(() => {
            CL.plataforma.iniciarLive().then((ok) => {
              CL.portas.feed('tempo', ok ? 'Live subiu' : 'Nao achei o botao Iniciar LIVE — sobe manual');
            }).catch(() => {});
          }, 2000);
        }
      }

      // 2. hora de ENCERRAR uma live agendada?
      const paraEncerrar = cfg.autoStart.series.find((s) =>
        s && s.tsFim > 0 && now >= s.tsFim && !s.encerradoDisparado && s.disparado
      );
      if (paraEncerrar && aoVivo && !encerrandoJa) {
        paraEncerrar.encerradoDisparado = true;
        encerrandoJa = true;
        CL.setCfg({ autoStart: { series: cfg.autoStart.series } });
        CL.portas.feed('tempo', 'Encerrando "' + (paraEncerrar.nome || 'live agendada') + '" pela agenda');
        CL.bus.publicar('vida', { evento: 'encerrando' });
        CL.plataforma.encerrarLive().catch(() => {});
      }
    }
  }

  function comandoPainel(msg) {
    if (!msg) return;
    if (msg.comando === 'encerrarAgora') {
      encerrandoJa = true;
      CL.bus.publicar('vida', { evento: 'encerrando' });
      CL.plataforma.encerrarLive().catch(() => {});
    } else if (msg.comando === 'iniciarLive') {
      if (CL.vida.aoVivo()) { CL.portas.feed('tempo', 'Live ja esta no ar.'); return; }
      CL.portas.feed('tempo', 'Procurando botao Iniciar LIVE na tela...');
      CL.plataforma.iniciarLive().then((ok) => {
        if (ok) {
          CL.portas.feed('tempo', '✓ Cliquei no botao Iniciar LIVE. Aguarde alguns segundos.');
        } else {
          CL.portas.feed('tempo', '✗ Nao achei o botao "Iniciar LIVE" na pagina. Verifique se voce esta na tela do streamer/dashboard.');
        }
      }).catch((e) => {
        CL.portas.feed('tempo', 'Erro ao tentar iniciar: ' + (e && e.message || e));
      });
    } else if (msg.comando === 'pausar') {
      CL.bus.publicar('vida', { evento: 'pausado' });
    } else if (msg.comando === 'retomar') {
      CL.bus.publicar('vida', { evento: 'retomado' });
    }
  }

  CL.registrarMotor({
    nome: 'tempo-live',
    ligado: () => true,
    iniciar() {
      CL.repetir(tick, 1000);
      CL.bus.assinar('painel:comando', comandoPainel);
    },
    resetPorLive() {
      inicioMs = CL.vida.startTs() || Date.now();
      encerrandoJa = false;
    },
    diag() { return Object.assign({}, diag); },
  });
})();
