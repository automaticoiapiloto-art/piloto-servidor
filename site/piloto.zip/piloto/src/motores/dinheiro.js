/*
 * dinheiro.js — conta vendas e soma GMV. UM motor so pra ticket medio (GMV/vendas)
 * nunca descasar.
 *
 * Duas fontes:
 *   1) 'atividade' tipo='venda' (via WS/API) — fonte primaria, tem messageId
 *   2) 'oficial' (do coletor-room) — reconciliacao: se o numero oficial da API
 *      subir mais do que a nossa contagem, o delta vira 'venda:contada' sem
 *      nome (para venda-chat, que so anuncia se tem nome).
 *
 * O que expoe: CL.state.salesCount, salesTotal, gmvOficial, itensOficial.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus) return;

  CL.state = CL.state || {};
  const defaults = {
    salesCount: 0,
    salesTotal: 0,
    salesFeed: [],
    gmvOficial: null,
    itensOficial: null,
    assistiramTotal: null,
    exibicoes: null,
    produtoStats: {},
  };
  for (const k of Object.keys(defaults)) if (CL.state[k] === undefined) CL.state[k] = defaults[k];

  const vistas = new Set(); // messageId ou "produto|valor|min"

  CL.bus.assinar('atividade', (ev) => {
    if (!ev || ev.tipo !== 'venda') return;
    const chave = ev.messageId || ((ev.produtoId || '') + '|' + (ev.valor || 0) + '|' + Math.floor(Date.now() / 60000));
    if (vistas.has(chave)) return;
    vistas.add(chave);
    CL.state.salesCount++;
    if (ev.valor) CL.state.salesTotal += Number(ev.valor);
    CL.state.salesFeed.unshift({ ts: Date.now(), nome: ev.nome || '', valor: ev.valor || null, produtoId: ev.produtoId || '' });
    if (CL.state.salesFeed.length > 200) CL.state.salesFeed.length = 200;
    // publica pra venda-chat anunciar (mesmo payload, sem duplicar)
    CL.bus.publicar('venda:contada', ev);
  });

  CL.bus.assinar('oficial', (o) => {
    if (!o) return;
    if (o.gmv != null) CL.state.gmvOficial = Number(o.gmv);
    if (o.itens != null) CL.state.itensOficial = Number(o.itens);
    if (o.assistiram != null) CL.state.assistiramTotal = Number(o.assistiram);
    if (o.exibicoes != null) CL.state.exibicoes = Number(o.exibicoes);
    // reconciliacao: se oficial > local por muito tempo, algo passou; nao inventa
    // eventos com nome — apenas alinha o contador com o oficial (a diferenca
    // fica como "vendas sem nome" pro painel).
    if (CL.state.itensOficial != null && CL.state.itensOficial > CL.state.salesCount) {
      CL.state.salesCount = CL.state.itensOficial;
    }
  });

  CL.bus.assinar('stats', (map) => {
    if (!map || typeof map !== 'object') return;
    CL.state.produtoStats = map;
  });

  CL.registrarMotor({
    nome: 'dinheiro',
    ligado: () => true,
    iniciar() {},
    resetPorLive() {
      CL.state.salesCount = 0;
      CL.state.salesTotal = 0;
      CL.state.salesFeed = [];
      CL.state.gmvOficial = null;
      CL.state.itensOficial = null;
      vistas.clear();
    },
    diag() {
      return {
        vendas: CL.state.salesCount,
        gmv: CL.state.salesTotal,
        gmvOficial: CL.state.gmvOficial,
        ticket: CL.state.salesCount ? CL.state.salesTotal / CL.state.salesCount : 0,
      };
    },
  });
})();
