/*
 * venda-chat.js — aviso no chat quando confirma uma venda. Assina 'atividade'
 * com tipo='venda' (evento do WS/API) E 'venda:contada' publicado pelo motor
 * dinheiro (varredura de tela). Dedup unico entre os dois caminhos.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus || !CL.util) return;

  let vitrineCache = [];
  const dedup = new Set(); // messageId ou "nome|produto|valor"
  const diag = { env: 0, fal: 0, dedup: 0 };

  CL.bus.assinar('vitrine', (l) => { if (Array.isArray(l)) vitrineCache = l; });

  function anunciar(payload) {
    const cfg = CL.cfg();
    if (!cfg || !cfg.chat || !cfg.chat.saleAlert || !cfg.chat.saleAlert.enabled) return;
    if (!CL.vida.IS_TOP) return;
    if (!CL.vida.aoVivo() || CL.vida.pausado() || CL.vida.encerrando()) return;
    if (CL.vida.licBloqueada('aviso de venda')) return;

    const nome = CL.util.nomeSeguro(payload.nome);
    if (!nome) return;

    const chave = payload.messageId || (nome.toLowerCase() + '|' + (payload.produtoId || '') + '|' + (payload.valor || ''));
    if (dedup.has(chave)) { diag.dedup++; return; }
    dedup.add(chave);
    // limita o tamanho pra live gigante nao crescer sem fim
    if (dedup.size > 5000) {
      const arr = Array.from(dedup);
      for (let i = 0; i < arr.length / 2; i++) dedup.delete(arr[i]);
    }

    const p = payload.produtoId ? vitrineCache.find((x) => x.id === payload.produtoId) : null;
    const produto = p ? CL.util.produtoSeguro(p.titulo) : '';
    const preco = payload.valor ? 'R$ ' + Number(payload.valor).toFixed(2).replace('.', ',') : (p && p.preco ? 'R$ ' + p.preco.toFixed(2).replace('.', ',') : '');

    const tpl = cfg.chat.saleAlert.template || 'Vendido para {nome}!';
    const texto = CL.util.renderTemplate(tpl, { nome, produto, preco });
    if (!texto) return;

    CL.portas.chat(texto, 'venda-chat', (ok) => {
      if (ok) {
        diag.env++;
        CL.state = CL.state || {};
        CL.state.chatAvisosVenda = (CL.state.chatAvisosVenda || 0) + 1;
      } else { diag.fal++; dedup.delete(chave); }
    });
  }

  CL.bus.assinar('atividade', (ev) => {
    if (!ev || ev.tipo !== 'venda') return;
    anunciar(ev);
  });
  CL.bus.assinar('venda:contada', (ev) => { anunciar(ev); });

  CL.registrarMotor({
    nome: 'venda-chat',
    ligado: (cfg) => !!(cfg && cfg.chat && cfg.chat.saleAlert && cfg.chat.saleAlert.enabled),
    iniciar() {},
    resetPorLive() { dedup.clear(); diag.env = 0; diag.fal = 0; diag.dedup = 0; },
    diag() { return Object.assign({}, diag); },
  });
})();
