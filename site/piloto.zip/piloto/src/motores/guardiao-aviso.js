/*
 * guardiao-aviso.js — modo AVISO puro (sem evasao). A cada 30s, le a lista
 * de violacoes reportadas pelo TikTok. Se algo aparecer, dispara notificacao
 * do sistema + feed no painel + evento 'guardiao:violacao' no barramento.
 *
 * NAO encerra a live sozinho. NAO oculta produto. NAO tenta esconder nada
 * da plataforma. Objetivo: voce fica sabendo antes de virar strike.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus) return;

  const vistas = new Set();
  const diag = { avisos: 0 };

  async function tick() {
    const cfg = CL.cfg();
    if (!cfg || !cfg.seguranca || !cfg.seguranca.guardiaoAviso) return;
    if (!CL.vida.aoVivo()) return;
    if (!CL.vida.IS_TOP) return;
    const dados = await CL.plataforma.lerViolacoes();
    if (!dados) return;
    const lista = dados.violation_list || dados.violations || [];
    for (const v of lista) {
      const chave = v.violation_id || v.id || (v.title + '|' + v.time);
      if (vistas.has(chave)) continue;
      vistas.add(chave);
      const titulo = v.title || v.reason || 'Violacao detectada';
      const corpo = v.description || v.msg || '';
      diag.avisos++;
      CL.portas.notificar('violacao', 'Aviso do TikTok: ' + titulo, corpo);
      CL.portas.feed('guardiao', 'Aviso do TikTok: ' + titulo + (corpo ? ' — ' + corpo : ''));
      CL.bus.publicar('guardiao:violacao', { titulo, corpo, ts: Date.now() });
    }
  }

  CL.registrarMotor({
    nome: 'guardiao-aviso',
    ligado: (cfg) => !!(cfg && cfg.seguranca && cfg.seguranca.guardiaoAviso),
    iniciar() {
      CL.repetir(tick, 30_000);
      tick();
    },
    resetPorLive() { vistas.clear(); diag.avisos = 0; },
    diag() { return Object.assign({}, diag); },
  });
})();
