/*
 * ia-respostas.js — responde comentarios do chat via IA e captura leads
 * por palavras-chave.
 *
 * Assina 'tela:chat' (e 'atividade' tipo='chat'). Pra cada comentario novo:
 *  1. Se contem palavra-chave configurada -> registra como LEAD em
 *     CL.state.leads (aba Leads mostra).
 *  2. Se e uma PERGUNTA real -> pede resposta pra IA (com delay natural
 *     de 5-15s pra parecer humano) e posta pela CL.portas.chat.
 *
 * Dedup por autor+texto na mesma live (evita responder mesmo comentario
 * quando o TikTok re-renderiza o chat).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus || !CL.util) return;

  CL.state = CL.state || {};
  CL.state.leads = CL.state.leads || [];

  const jaTratados = new Map(); // autor|texto -> ts
  const MAX = 3000;
  const cooldownPorAutor = new Map(); // autor -> ts (nao spam do proprio motor)
  const diag = { respostas: 0, leads: 0, ignoradas: 0, erros: 0 };

  function parecePergunta(txt) {
    if (!txt || txt.length < 3) return false;
    // filtros baratos: emojis puros, risadas, saudacoes muito curtas
    if (/^[\s\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]+$/u.test(txt)) return false;
    if (/^k+$/i.test(txt.replace(/\s/g, ''))) return false;
    if (txt.length < 5 && /^(oi|hi|ola|hello|hey|bom dia|boa tarde|boa noite)$/i.test(txt.trim())) return false;
    // pergunta explicita: tem ? ou palavra interrogativa
    if (txt.indexOf('?') >= 0) return true;
    const t = CL.util.normalizar(txt);
    if (/\b(quanto|quando|como|onde|qual|quais|tem|voce tem|tem em|posso|serve|funciona|entrega|manda|prazo|garantia|reembolso|parcelamento|parcela|pix|cartao|preco|valor|desconto)\b/.test(t)) return true;
    return false;
  }

  function bateuPalavraChave(txt, palavras) {
    if (!Array.isArray(palavras) || !palavras.length) return null;
    const t = CL.util.normalizar(txt);
    for (const p of palavras) {
      const norm = CL.util.normalizar(p);
      if (norm && CL.util.palavraCrua(t, norm)) return p;
    }
    return null;
  }

  function registrarLead(autor, texto, palavra) {
    const lead = {
      autor: autor || '(anonimo)',
      texto,
      palavra,
      ts: Date.now(),
      roomId: CL.vida.roomId(),
    };
    CL.state.leads.unshift(lead);
    if (CL.state.leads.length > 500) CL.state.leads.length = 500;
    diag.leads++;
    CL.portas.notificar('lead', 'Novo interessado no chat', autor + ' pediu "' + palavra + '"');
    CL.portas.feed('lead', autor + ' disse "' + palavra + '" — anotado nos leads');
    CL.bus.publicar('leads:novo', lead);
  }

  async function pedirRespostaIA(autor, pergunta) {
    const cfg = CL.cfg();
    const ia = cfg.chat && cfg.chat.ia;
    if (!ia || !ia.enabled) return null;

    // pega o token gravado pelo license.js
    const st = await chrome.storage.local.get('piloto_license_v1').catch(() => ({}));
    const token = st.piloto_license_v1 && st.piloto_license_v1.token;
    if (!token) return null;

    const servidor = (cfg.licenca && cfg.licenca.servidor) || 'https://pilotoautomaticoia.com.br';
    try {
      const r = await chrome.runtime.sendMessage({
        __piloto: true, kind: 'httpProxy',
        url: servidor + '/api/ia/responder', method: 'POST',
        headers: { authorization: 'Bearer ' + token },
        body: {
          produto: ia.produto || '',
          faq: ia.faq || '',
          autor: autor || '',
          pergunta: pergunta.slice(0, 300),
        },
      });
      if (!r || !r.ok || r.status !== 200) { diag.erros++; return null; }
      return r.payload && r.payload.resposta || null;
    } catch (_) { diag.erros++; return null; }
  }

  async function tratar(msg) {
    const cfg = CL.cfg();
    if (!cfg || !cfg.chat || !cfg.chat.ia) return;
    const ia = cfg.chat.ia;
    if (!ia.enabled) return;
    if (!CL.vida.IS_TOP) return;
    if (CL.vida.licBloqueada('responder com IA')) return;
    if (CL.plano && !CL.plano.permite('ia')) return;
    // gate normal: so responde durante live real. Excecao: plano dev
    // pode testar sem live no ar (facilita QA da IA).
    const isDev = cfg.licenca && cfg.licenca.plano === 'dev';
    if (!isDev && (!CL.vida.aoVivo() || CL.vida.pausado() || CL.vida.encerrando())) return;

    const texto = String(msg && msg.texto || '').trim();
    const autor = String(msg && msg.autor || '').trim();
    if (!texto) return;

    // dedup
    const dedupChave = autor + '|' + texto;
    if (jaTratados.has(dedupChave)) return;
    jaTratados.set(dedupChave, Date.now());
    if (jaTratados.size > MAX) {
      const arr = Array.from(jaTratados.entries()).sort((a, b) => a[1] - b[1]);
      for (let i = 0; i < arr.length / 2; i++) jaTratados.delete(arr[i][0]);
    }

    // 1. captura de lead por palavra-chave
    const palavras = (ia.palavrasChave || '').split(',').map((s) => s.trim()).filter(Boolean);
    const p = bateuPalavraChave(texto, palavras);
    if (p) registrarLead(autor, texto, p);

    // 2. resposta IA
    if (!parecePergunta(texto)) { diag.ignoradas++; return; }

    // cooldown por autor: nao responder mesmo autor 2x em 90s
    const ult = cooldownPorAutor.get(autor) || 0;
    if (Date.now() - ult < 90_000) return;
    cooldownPorAutor.set(autor, Date.now());

    // delay natural pra parecer humano (5-15s)
    const delayMs = 5000 + Math.floor(Math.random() * 10_000);
    CL.portas.feed('ia', 'IA vai responder "' + texto.slice(0, 40) + '..." em ' + Math.round(delayMs / 1000) + 's');
    setTimeout(async () => {
      const resposta = await pedirRespostaIA(autor, texto);
      if (!resposta) { CL.portas.feed('ia', 'IA nao gerou resposta pra "' + texto.slice(0, 40) + '"'); return; }
      // sempre loga o que a IA gerou (util pra debug e transparencia)
      CL.portas.feed('ia', 'IA gerou: ' + resposta);
      CL.portas.chat(resposta, 'ia', (ok) => {
        if (ok) { diag.respostas++; CL.portas.feed('ia', 'Resposta postada no chat.'); }
        else { diag.erros++; CL.portas.feed('ia', 'Nao consegui postar (talvez fora de uma live real).'); }
      });
    }, delayMs);
  }

  CL.bus.assinar('tela:chat', tratar);
  CL.bus.assinar('atividade', (ev) => {
    if (ev && ev.tipo === 'chat' && ev.texto) tratar({ autor: ev.nome, texto: ev.texto });
  });
  // troca de sala zera dedup
  CL.bus.assinar('vida', (v) => {
    if (v && v.evento === 'live-comecou') {
      jaTratados.clear();
      cooldownPorAutor.clear();
      CL.state.leads = [];
    }
  });

  CL.registrarMotor({
    nome: 'ia-respostas',
    ligado: (cfg) => !!(cfg && cfg.chat && cfg.chat.ia && cfg.chat.ia.enabled),
    iniciar() {},
    resetPorLive() {
      jaTratados.clear();
      cooldownPorAutor.clear();
      CL.state.leads = [];
      diag.respostas = 0; diag.leads = 0; diag.ignoradas = 0; diag.erros = 0;
    },
    diag() { return Object.assign({}, diag, { leads: CL.state.leads.length }); },
  });
})();
