/*
 * chat-liberado.js — espelha cfg.seguranca.chatOpen no ajuste "Permitir
 * comentarios" do TikTok. So age na MUDANCA de cfg (nao briga com o vendedor
 * se ele mexer na mao).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor) return;

  let ultimoValor = null;

  async function aplicar() {
    const cfg = CL.cfg();
    if (!cfg || !cfg.seguranca) return;
    const v = cfg.seguranca.chatOpen;
    if (v === null || v === undefined) return;
    if (v === ultimoValor) return;
    ultimoValor = v;
    if (!CL.vida.aoVivo()) return; // so tem sentido com live no ar
    if (!CL.vida.IS_TOP) return;
    const ok = await CL.plataforma.ajustarChat(!!v);
    CL.portas.feed('chat-cfg', ok ? ('Comentarios ' + (v ? 'liberados' : 'fechados')) : 'Nao consegui alterar comentarios');
  }

  CL.registrarMotor({
    nome: 'chat-liberado',
    ligado: (cfg) => !!(cfg && cfg.seguranca && cfg.seguranca.chatOpen !== null && cfg.seguranca.chatOpen !== undefined),
    iniciar() {
      if (CL.onCfgChange) CL.onCfgChange(aplicar);
      aplicar();
    },
    resetPorLive() {
      ultimoValor = null; // aplica de novo quando entra live
      aplicar();
    },
    diag() { return { ultimoValor }; },
  });
})();
