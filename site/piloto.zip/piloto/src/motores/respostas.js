/*
 * respostas.js — Q&A por gatilho no chat. Assina 'tela:chat', casa contra as
 * respostas cadastradas, envia pela CL.portas.chat (fila global).
 *
 * Dedup por autor|texto: TikTok re-renderiza o chat quando alguma coisa muda
 * na tela — a mesma mensagem volta como no' novo. Sem dedup a resposta sai 2x.
 * Marca vive a live inteira; troca de sala (nova live) zera o dedup.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus || !CL.util) return;

  const jaRespondi = new Map(); // "autor|texto" -> ts
  const MAX = 2000;
  let salaAtual = '';
  let vitrineCache = [];
  const diag = { env: 0, fal: 0 };

  CL.bus.assinar('sala', (s) => {
    if (!s || !s.roomId || s.roomId === salaAtual) return;
    if (salaAtual) jaRespondi.clear();
    salaAtual = s.roomId;
  });
  CL.bus.assinar('vitrine', (lista) => { if (Array.isArray(lista)) vitrineCache = lista; });

  function acharResposta(cfg, texto) {
    const respostas = (cfg.chat.qa.respostas || []).filter((r) => r.enabled !== false && r.resposta && (r.gatilhos || []).length);
    for (const r of respostas) {
      for (const g of r.gatilhos) {
        if (CL.util.matchGatilho(texto, g)) return r;
      }
    }
    return null;
  }

  function preencherTemplate(r, autor) {
    const nome = CL.util.nomeSeguro(autor) || '';
    const vars = { nome, produto: '', preco: '' };
    if (r.produtoId) {
      const p = vitrineCache.find((x) => x.id === r.produtoId);
      if (p) {
        vars.produto = CL.util.produtoSeguro(p.titulo);
        vars.preco = p.preco ? 'R$ ' + p.preco.toFixed(2).replace('.', ',') : '';
      }
    }
    // Se a resposta NAO tem placeholders, envia direto (sem passar por render).
    if (!/\{(\w+)\}/.test(r.resposta)) return r.resposta;
    // Se tem placeholders, exige que TODOS resolvam. Senao, nao envia
    // (evita "Olá {nome}, tudo bem?" aparecer literal no chat).
    return CL.util.renderTemplate(r.resposta, vars);
  }

  CL.bus.assinar('tela:chat', (msg) => {
    const cfg = CL.cfg();
    if (!cfg || !cfg.chat || !cfg.chat.qa || !cfg.chat.qa.enabled) return;
    if (!CL.vida.IS_TOP) return;
    if (!CL.vida.aoVivo() || CL.vida.pausado() || CL.vida.encerrando()) return;
    if (CL.vida.licBloqueada('responder chat')) return;

    const texto = String(msg && msg.texto || '').trim();
    const autor = String(msg && msg.autor || '').trim();
    if (!texto) return;

    const chave = autor + '|' + texto;
    if (jaRespondi.has(chave)) return;

    const r = acharResposta(cfg, texto);
    if (!r) return;

    jaRespondi.set(chave, Date.now());
    if (jaRespondi.size > MAX) {
      // corta os mais antigos (metade)
      const arr = Array.from(jaRespondi.entries()).sort((a, b) => a[1] - b[1]);
      for (let i = 0; i < arr.length / 2; i++) jaRespondi.delete(arr[i][0]);
    }

    const texto2 = preencherTemplate(r, autor);
    if (!texto2) { diag.fal++; return; } // placeholder faltou — nao envia cru
    CL.portas.chat(texto2, 'respostas', (ok) => {
      if (ok) diag.env++;
      else { diag.fal++; jaRespondi.delete(chave); } // libera pra retentar
    });
  });

  CL.registrarMotor({
    nome: 'respostas',
    ligado: (cfg) => !!(cfg && cfg.chat && cfg.chat.qa && cfg.chat.qa.enabled),
    iniciar() {},
    resetPorLive() { /* dedup ja zera na troca de sala */ diag.env = 0; diag.fal = 0; },
    diag() { return Object.assign({}, diag); },
  });
})();
