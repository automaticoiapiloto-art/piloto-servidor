/*
 * carrinho.js — aviso no chat quando alguem adiciona ao carrinho. Assina
 * 'atividade' com tipo='carrinho' e envia texto pela CL.portas.chat.
 *
 * Dedup por pessoa+produto na live: um aviso por comprador+produto por live.
 * Se o coletor-ws re-emite o mesmo evento (re-render, retry), a marca segura.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus || !CL.util) return;

  let vitrineCache = [];
  const dedup = new Set(); // "nome|produtoId" ja avisados nesta live
  const diag = { env: 0, fal: 0, dedup: 0 };

  CL.bus.assinar('vitrine', (l) => { if (Array.isArray(l)) vitrineCache = l; });

  CL.bus.assinar('atividade', (ev) => {
    if (!ev || ev.tipo !== 'carrinho') return;
    const cfg = CL.cfg();
    if (!cfg || !cfg.chat || !cfg.chat.cartAlert || !cfg.chat.cartAlert.enabled) return;
    if (!CL.vida.IS_TOP) return;
    if (!CL.vida.aoVivo() || CL.vida.pausado() || CL.vida.encerrando()) return;
    if (CL.vida.licBloqueada('aviso de carrinho')) return;

    const nome = CL.util.nomeSeguro(ev.nome);
    if (!nome) return; // nome vazio nao vira aviso

    const chave = nome.toLowerCase() + '|' + (ev.produtoId || '');
    if (dedup.has(chave)) { diag.dedup++; return; }
    dedup.add(chave);

    const p = ev.produtoId ? vitrineCache.find((x) => x.id === ev.produtoId) : null;
    const produto = p ? CL.util.produtoSeguro(p.titulo) : '';
    const preco = p && p.preco ? 'R$ ' + p.preco.toFixed(2).replace('.', ',') : '';

    const texto = CL.util.renderTemplate(cfg.chat.cartAlert.template || '{nome} adicionou ao carrinho!', { nome, produto, preco });
    if (!texto) return;

    CL.portas.chat(texto, 'carrinho', (ok) => {
      if (ok) diag.env++;
      else { diag.fal++; dedup.delete(chave); } // libera pra retentar
    });
  });

  CL.registrarMotor({
    nome: 'carrinho',
    ligado: (cfg) => !!(cfg && cfg.chat && cfg.chat.cartAlert && cfg.chat.cartAlert.enabled),
    iniciar() {},
    resetPorLive() { dedup.clear(); diag.env = 0; diag.fal = 0; diag.dedup = 0; },
    diag() { return Object.assign({}, diag); },
  });
})();
