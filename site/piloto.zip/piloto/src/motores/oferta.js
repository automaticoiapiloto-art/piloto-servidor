/*
 * oferta.js — oferta relampago: quando a nativa do TikTok encerra, recria.
 * Maquina de estados: watch -> m1 (clicou "Duplicar" do card encerrado) ->
 * m2 (clicou "Duplicar e comecar agora") -> volta pro watch com cooldown 30s.
 *
 * So clique na UI do TikTok (via CL.finder). Sem chamada de API.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.finder) return;

  let fase = 'watch';
  let t0 = 0;
  let cooldownAte = 0;

  function candidatosPorTexto(txt) {
    return CL.finder.porTexto(txt).map((x) => x.el);
  }

  function passo() {
    const cfg = CL.cfg();
    if (!cfg || !cfg.flashOffer || !cfg.flashOffer.enabled) { fase = 'watch'; return; }
    if (!CL.vida.aoVivo() || CL.vida.pausado() || CL.vida.encerrando()) return;
    if (CL.vida.licBloqueada('oferta relampago')) { fase = 'watch'; return; }
    if (!CL.vida.IS_TOP) return;

    const agora = Date.now();
    if (agora < cooldownAte) return;

    if (fase === 'watch') {
      // "Duplicar" cujo card (ate 6 ancestrais) contenha "foi encerrada"
      const cands = candidatosPorTexto('Duplicar').filter((b) => {
        let el = b;
        for (let i = 0; i < 6 && el; i++) {
          el = el.parentElement;
          if (!el) break;
          const t = (el.textContent || '').slice(0, 500);
          if (t.indexOf('foi encerrada') > -1) return true;
        }
        return false;
      });
      if (cands.length) {
        CL.finder.clicar(cands[0]);
        fase = 'm1';
        t0 = agora;
        CL.portas.feed('oferta', 'Oferta relampago encerrada — recriando...');
      }
      return;
    }

    if (fase === 'm1') {
      const b = candidatosPorTexto('Duplicar e comecar agora');
      if (b.length) {
        CL.finder.clicar(b[b.length - 1]);
        fase = 'm2';
        t0 = agora;
        return;
      }
      if (agora - t0 > 20_000) fase = 'watch';
      return;
    }

    if (fase === 'm2') {
      // "Iniciar" dentro do modal da oferta (fallback: qualquer "Iniciar")
      let b = candidatosPorTexto('Iniciar');
      if (b.length) {
        CL.finder.clicar(b[b.length - 1]);
        fase = 'watch';
        cooldownAte = agora + 30_000;
        CL.portas.feed('oferta', 'Oferta relampago relancada');
        return;
      }
      if (agora - t0 > 20_000) fase = 'watch';
    }
  }

  CL.registrarMotor({
    nome: 'oferta',
    ligado: (cfg) => !!(cfg && cfg.flashOffer && cfg.flashOffer.enabled),
    iniciar() {
      if (!CL.vida.IS_TOP) return;
      CL.repetir(passo, 2000);
    },
    resetPorLive() { fase = 'watch'; t0 = 0; cooldownAte = 0; },
    diag() { return { fase, cooldownEmMs: Math.max(0, cooldownAte - Date.now()) }; },
  });
})();
