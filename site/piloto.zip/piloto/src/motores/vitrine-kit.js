/*
 * vitrine-kit.js — recoloca a vitrine (kit) quando a live encerra.
 *
 * SO age fora do ar. A porta CL.portas.recolocarKit ja recusa se aoVivo() —
 * este motor tambem confere no loop, pra que uma nova live comecar no meio
 * da re-tentativa nao injete o kit antigo na live nova.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus) return;

  const ESPERA_MS = 6000;
  const MAX_TENT = 3;
  const RESPIRO_MS = 10_000;

  let atendidaEm = ''; // roomId ja atendido
  let geracao = 0;

  async function ciclo(rid) {
    const g = geracao;
    await new Promise((r) => setTimeout(r, ESPERA_MS));
    for (let n = 0; n < MAX_TENT; n++) {
      if (g !== geracao) return;
      if (CL.vida.aoVivo()) return; // live nova comecou — para
      const cfg = CL.cfg();
      if (!cfg.vitrineKit || !cfg.vitrineKit.enabled || !cfg.vitrineKit.setId) return;
      const ok = await CL.portas.recolocarKit(cfg.vitrineKit.setId);
      if (ok) {
        CL.portas.feed('vitrine-kit', 'Vitrine recolocada (kit ' + (cfg.vitrineKit.setNome || cfg.vitrineKit.setId) + ')');
        atendidaEm = rid;
        return;
      }
      await new Promise((r) => setTimeout(r, RESPIRO_MS));
    }
    CL.portas.feed('vitrine-kit', 'Nao consegui recolocar a vitrine apos 3 tentativas.');
  }

  CL.bus.assinar('vida', (v) => {
    if (!v || v.evento !== 'live-acabou') return;
    const cfg = CL.cfg();
    if (!cfg.vitrineKit || !cfg.vitrineKit.enabled || !cfg.vitrineKit.setId) return;
    const rid = v.roomId || '';
    if (rid && rid === atendidaEm) return;
    if (!CL.vida.IS_TOP) return;
    geracao++;
    ciclo(rid);
  });

  CL.registrarMotor({
    nome: 'vitrine-kit',
    ligado: (cfg) => !!(cfg && cfg.vitrineKit && cfg.vitrineKit.enabled),
    iniciar() {},
    resetPorLive() { geracao++; },
    diag() { return { atendidaEm }; },
  });
})();
