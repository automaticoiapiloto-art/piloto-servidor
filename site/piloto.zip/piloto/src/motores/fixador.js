/*
 * fixador.js — fixar produto na live. Modos: 'produto' (um so, opcao piscar ou
 * rotacionar aleatorio) e 'lista' (sacolinha inteira).
 *
 * Assina 'vitrine' pra saber a lista atual. A cada intervalSec, escolhe o
 * alvo e pede fixacao pela CL.portas.fixar/fixarLista.
 *
 * Modo piscar: alterna fixado (delaySec) / desfixado (delaySec).
 * Modo aleatorio: sorteia produto diferente do ultimo fixado a cada renovacao.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor || !CL.bus) return;

  let vitrine = [];
  let ultimoFixadoId = '';
  let ultimoFixadoAt = 0;
  let piscarFase = 'fixado'; // 'fixado' | 'desfixado'
  let piscarProximoAt = 0;
  const diag = { fixadas: 0, falhas: 0, alvo: '', modo: '' };

  CL.bus.assinar('vitrine', (lista) => {
    if (Array.isArray(lista)) vitrine = lista;
  });

  function escolherAlvo(cfg) {
    if (!vitrine.length) return null;
    if (cfg.rePin.aleatorio && vitrine.length > 1) {
      let i, cand;
      for (let n = 0; n < 8; n++) {
        i = Math.floor(Math.random() * vitrine.length);
        cand = vitrine[i];
        if (cand.id !== ultimoFixadoId) return cand;
      }
      return cand;
    }
    if (cfg.rePin.productId) {
      const p = vitrine.find((x) => x.id === cfg.rePin.productId);
      if (p) return p;
    }
    return vitrine[0];
  }

  async function passoProduto(cfg) {
    const agora = Date.now();
    const intervalMs = Math.max(3, cfg.rePin.intervalSec | 0) * 1000;

    if (cfg.rePin.blink) {
      if (piscarProximoAt && agora < piscarProximoAt) { diag.modo = 'piscar-' + piscarFase; return; }
      const delayMs = Math.max(1, cfg.rePin.delaySec | 0) * 1000;
      if (piscarFase === 'desfixado') {
        const alvo = escolherAlvo(cfg);
        if (alvo) {
          const ok = await CL.portas.fixar(alvo.id);
          if (ok) { ultimoFixadoId = alvo.id; diag.fixadas++; diag.alvo = alvo.titulo; }
          else diag.falhas++;
        }
        piscarFase = 'fixado';
      } else {
        await CL.plataforma.desfixar();
        piscarFase = 'desfixado';
      }
      piscarProximoAt = agora + delayMs;
      return;
    }

    if (ultimoFixadoAt && agora - ultimoFixadoAt < intervalMs) { diag.modo = 'aguardando'; return; }
    const alvo = escolherAlvo(cfg);
    if (!alvo) { diag.modo = 'sem-vitrine'; return; }
    const ok = await CL.portas.fixar(alvo.id);
    if (ok) {
      ultimoFixadoId = alvo.id;
      ultimoFixadoAt = agora;
      diag.fixadas++;
      diag.alvo = alvo.titulo;
      diag.modo = 'ok';
    } else {
      diag.falhas++;
      diag.modo = 'falhou';
    }
  }

  async function passoLista(cfg) {
    const agora = Date.now();
    const intervalMs = Math.max(3, cfg.rePin.intervalSec | 0) * 1000;
    if (ultimoFixadoAt && agora - ultimoFixadoAt < intervalMs) { diag.modo = 'aguardando'; return; }
    if (!vitrine.length) { diag.modo = 'sem-vitrine'; return; }
    const ids = vitrine.map((p) => p.id);
    const ok = await CL.portas.fixarLista(ids);
    if (ok) { ultimoFixadoAt = agora; diag.fixadas++; diag.modo = 'ok-lista'; }
    else { diag.falhas++; diag.modo = 'falhou-lista'; }
  }

  async function tick() {
    const cfg = CL.cfg();
    if (!cfg || !cfg.rePin || !cfg.rePin.enabled) return;
    if (!CL.vida.aoVivo() || CL.vida.pausado() || CL.vida.encerrando()) { diag.modo = 'fora-do-ar'; return; }
    if (CL.vida.licBloqueada('fixar')) { diag.modo = 'lic-bloqueada'; return; }
    if (!CL.vida.IS_TOP) return; // 1 fixador so

    if (cfg.rePin.modo === 'lista') return passoLista(cfg);
    return passoProduto(cfg);
  }

  CL.registrarMotor({
    nome: 'fixador',
    ligado: (cfg) => !!(cfg && cfg.rePin && cfg.rePin.enabled),
    iniciar() {
      CL.repetir(tick, 1500);
    },
    resetPorLive() {
      ultimoFixadoId = ''; ultimoFixadoAt = 0;
      piscarFase = 'fixado'; piscarProximoAt = 0;
    },
    diag() { return Object.assign({}, diag); },
  });
})();
