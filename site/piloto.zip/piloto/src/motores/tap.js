/*
 * tap.js — clique/tap periodico na area do video da live. Serve pra:
 *  1. Manter o Chrome "ativo" (evita throttling de aba em background)
 *  2. Como efeito colateral, cada tap gera um coracao/like na live do TikTok
 *
 * Frequencia: a cada `cfg.tap.intervaloSeg` segundos (default 30s), com
 * jitter aleatorio de ±5s pra o padrao nao ficar robotico.
 * Posicao: centro da area do video +/- 30px aleatorios.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  if (!CL.registrarMotor) return;

  const diag = { taps: 0, ignorados: 0, ultimoAt: 0 };
  let proximoAt = 0;

  function acharAreaVideo() {
    // 1. video element (mais confiavel)
    const v = document.querySelector('video');
    if (v && v.getClientRects().length) return v;
    // 2. fallback: canvas grande
    const canvases = document.querySelectorAll('canvas');
    for (const c of canvases) {
      const r = c.getBoundingClientRect();
      if (r.width > 200 && r.height > 200) return c;
    }
    return null;
  }

  function darTap() {
    const alvo = acharAreaVideo();
    if (!alvo) { diag.ignorados++; return false; }
    const r = alvo.getBoundingClientRect();
    // centro +/- jitter de 30px pra nao ser sempre no MESMO pixel
    const cx = r.left + r.width / 2 + (Math.random() * 60 - 30);
    const cy = r.top + r.height / 2 + (Math.random() * 60 - 30);
    const opt = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
    try {
      alvo.dispatchEvent(new PointerEvent('pointerdown', opt));
      alvo.dispatchEvent(new MouseEvent('mousedown', opt));
      alvo.dispatchEvent(new PointerEvent('pointerup', opt));
      alvo.dispatchEvent(new MouseEvent('mouseup', opt));
      alvo.dispatchEvent(new MouseEvent('click', opt));
      diag.taps++;
      diag.ultimoAt = Date.now();
      return true;
    } catch (_) {
      diag.ignorados++;
      return false;
    }
  }

  function proximoIntervaloMs(cfg) {
    const base = Math.max(10, (cfg.tap && cfg.tap.intervaloSeg) || 30);
    const jitter = Math.floor(Math.random() * 10_000) - 5_000; // ±5s
    return base * 1000 + jitter;
  }

  function passo() {
    const cfg = CL.cfg();
    if (!cfg || !cfg.tap || !cfg.tap.enabled) return;
    if (!CL.vida.IS_TOP) return;
    // so quando a live esta no ar (senao nao faz sentido gerar like)
    if (!CL.vida.aoVivo()) return;
    if (CL.vida.pausado() || CL.vida.encerrando()) return;

    const agora = Date.now();
    if (!proximoAt) { proximoAt = agora + proximoIntervaloMs(cfg); return; }
    if (agora < proximoAt) return;

    darTap();
    proximoAt = Date.now() + proximoIntervaloMs(cfg);
  }

  CL.registrarMotor({
    nome: 'tap',
    ligado: (cfg) => !!(cfg && cfg.tap && cfg.tap.enabled),
    iniciar() {
      CL.repetir(passo, 2000);
    },
    resetPorLive() { proximoAt = 0; diag.taps = 0; diag.ignorados = 0; },
    diag() { return Object.assign({}, diag); },
  });
})();
