/*
 * apibridge.js — roda no MUNDO DA PAGINA (world: MAIN). O content script (mundo
 * isolado) envia __pt_apireq com {path, method, body} e este arquivo faz o
 * fetch AQUI, herdando a assinatura X-Bogus/msToken que a propria pagina do
 * TikTok injeta em todo fetch.
 *
 * So responde a mensagens com o token que o content.js anuncia (canal
 * __pt_capctl). Isso nao e fronteira de privilegio — qualquer script da propria
 * pagina pode fazer fetch assinado. E so higiene pra outro script nao usar a
 * ponte a toa.
 *
 * Passivo: nao muda pagina, nao intercepta chamadas alheias — so responde
 * pedidos vindos com o token certo.
 */
;(function () {
  'use strict';

  let token = '';

  // configuracao de identidade — TikTok Shop tem dois "apps" (streamer_desktop
  // e insights). A regra: rotas /api/vN/insights/ viajam com aid=4068 +
  // app_name=i18n_ecom_shop; qualquer outra rota do streamer_desktop viaja com
  // aid=253642 + app_name=i18n_ecom_alliance.
  const COMMON_STREAMER = 'aid=253642&app_name=i18n_ecom_alliance&device_platform=web&user_language=pt-BR&locale=pt-BR';
  const COMMON_INSIGHTS = 'aid=4068&app_name=i18n_ecom_shop&vertical=3&device_platform=web&user_language=pt-BR&locale=pt-BR';
  const PREFIX_STREAMER = '/api/v1/streamer_desktop/';
  const ROTA_INSIGHTS = /^\/api\/v\d+\/insights\//;

  // cabecalhos que destravam algumas rotas do streamer_desktop no BR
  const ACCEPT = 'application/json, text/plain, */*';
  const STORE_REGION = 'br';

  function montarUrl(path) {
    const isInsights = ROTA_INSIGHTS.test(path);
    const base = isInsights ? path : (path.indexOf('/') === 0 ? path : PREFIX_STREAMER + path);
    const params = isInsights ? COMMON_INSIGHTS : COMMON_STREAMER;
    const sep = base.indexOf('?') >= 0 ? '&' : '?';
    return base + sep + params + '&carrier_region=br';
  }

  async function chamar(path, method, body) {
    const url = montarUrl(path);
    const headers = {
      'accept': ACCEPT,
      'x-tt-store-region': STORE_REGION,
    };
    if (body && typeof body === 'object') {
      headers['content-type'] = 'application/json';
    }
    try {
      const r = await fetch(url, {
        method: method || 'GET',
        credentials: 'include',
        headers,
        body: (body && typeof body === 'object') ? JSON.stringify(body) : (body || undefined),
      });
      let payload = null;
      const ct = r.headers.get('content-type') || '';
      if (ct.indexOf('application/json') >= 0) {
        try { payload = await r.json(); } catch (_) { payload = null; }
      } else {
        try { payload = await r.text(); } catch (_) { payload = null; }
      }
      // sinal de "recusa silenciosa" (200 + corpo vazio): motor precisa saber
      if (r.status === 200 && payload && typeof payload === 'object' && payload.data && !payload.data.products && !payload.data.data && Object.keys(payload.data).length === 0) {
        return { status: r.status, data: payload, vazio: true };
      }
      return { status: r.status, data: payload };
    } catch (e) {
      return { error: String(e && e.message || e) };
    }
  }

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    const d = ev.data;
    if (d.__pt_capctl && typeof d.token === 'string') {
      token = d.token;
      return;
    }
    if (!d.__pt_apireq) return;
    if (!token || d.token !== token) return;
    chamar(d.path, d.method, d.body).then((res) => {
      try {
        window.postMessage({
          __pt_apires: true,
          token,
          id: d.id,
          ok: !res || res.error ? false : true,
          payload: res,
        }, location.origin);
      } catch (_) {}
    });
  });
})();
