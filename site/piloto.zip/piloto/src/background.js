/*
 * background.js — service worker (MV3).
 *
 * Responsabilidades enxutas:
 *   1. Abrir o painel lateral quando clicam no icone.
 *   2. Mostrar notificacoes do sistema (content script nao tem chrome.notifications).
 *   3. Manter uma porta "pt-vivo" viva pro content vigiar se a extensao esta ativa.
 *   4. Backstop de encerramento programado (chrome.alarms).
 *   5. Buffer do feed (mensagens que o painel exibe) — o painel le no boot.
 *
 * Nao decide nada de motor. So infraestrutura.
 */

// ---------- painel lateral: clique no icone abre e leva pro streamer ----------
try {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {});
} catch (_) {}

const URL_STREAMER_TIKTOK = 'https://shop.tiktok.com/streamer';

chrome.action.onClicked.addListener((tab) => {
  // sidePanel.open exige gesto do usuario — chamar JA, antes de qualquer await
  try { chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {}); } catch (_) {}
  // se ja esta numa pagina de streamer, so o painel basta
  if (tab && typeof tab.url === 'string' && tab.url.indexOf(URL_STREAMER_TIKTOK) === 0) return;
  // procura uma aba de streamer aberta na mesma janela; se nao ha, abre uma
  chrome.tabs.query({ url: URL_STREAMER_TIKTOK + '*' }, (tabs) => {
    const mesma = (tabs || []).find((t) => t.windowId === tab.windowId) || (tabs || [])[0];
    if (mesma) {
      try { chrome.tabs.update(mesma.id, { active: true }); } catch (_) {}
      if (mesma.windowId !== tab.windowId) {
        try { chrome.windows.update(mesma.windowId, { focused: true }); } catch (_) {}
        try { chrome.sidePanel.open({ windowId: mesma.windowId }).catch(() => {}); } catch (_) {}
      }
    } else {
      try { chrome.tabs.create({ url: URL_STREAMER_TIKTOK }); } catch (_) {}
    }
  });
});

// ---------- porta pt-vivo (o content usa pra saber se a extensao ainda vive) ----------
chrome.runtime.onConnect.addListener((porta) => {
  if (porta.name !== 'pt-vivo') return;
  // sem listener: a porta so precisa existir. Ela cai naturalmente quando a aba fecha.
});

// ---------- feed / notificacoes / alarmes vindas dos content scripts ----------
const FEED_KEY = 'pt_feed_v1';
const FEED_MAX = 200;
let filaGravacao = Promise.resolve();

function empilharFeed(evento) {
  filaGravacao = filaGravacao.then(async () => {
    try {
      const r = await chrome.storage.session.get(FEED_KEY);
      const arr = r[FEED_KEY] || [];
      arr.push(evento);
      while (arr.length > FEED_MAX) arr.shift();
      await chrome.storage.session.set({ [FEED_KEY]: arr });
      // sinaliza pro painel abrir a leitura (o painel escuta chrome.storage)
    } catch (_) {}
  }).catch(() => {});
}

const ICON_PADRAO = chrome.runtime.getURL('icons/icon-128.png');
function mostrarNotif(tag, titulo, corpo) {
  try {
    chrome.notifications.create('pt-' + tag + '-' + Date.now(), {
      type: 'basic',
      iconUrl: ICON_PADRAO,
      title: String(titulo || 'Piloto Automatico IA'),
      message: String(corpo || ''),
      priority: 1,
      silent: false,
    });
  } catch (_) {}
}

// ---------- backstop de encerramento programado ----------
const ALARM_END = 'pt_end_';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.__piloto) return;
  switch (msg.kind) {
    case 'notify':
      mostrarNotif(msg.tag || 'info', msg.titulo, msg.corpo);
      sendResponse({ ok: true });
      return true;
    case 'feed':
      empilharFeed({ tipo: msg.tipo || 'info', msg: msg.msg || '', ts: msg.ts || Date.now(), from: sender && sender.tab && sender.tab.id });
      sendResponse({ ok: true });
      return true;
    case 'armEnd': {
      const when = Number(msg.when || 0);
      if (when > Date.now()) {
        try { chrome.alarms.create(ALARM_END + (sender.tab && sender.tab.id), { when }); } catch (_) {}
      }
      sendResponse({ ok: true });
      return true;
    }
    case 'disarmEnd':
      try { chrome.alarms.clear(ALARM_END + (sender.tab && sender.tab.id)); } catch (_) {}
      sendResponse({ ok: true });
      return true;
    case 'lerFeed':
      chrome.storage.session.get(FEED_KEY).then((r) => sendResponse({ ok: true, feed: r[FEED_KEY] || [] }));
      return true;
    case 'httpProxy': {
      // fetch em nome do content script (contorna mixed content HTTPS->HTTP
      // que o browser bloqueia quando a pagina host eh HTTPS).
      const { url, method, body, headers } = msg;
      fetch(url, {
        method: method || 'GET',
        headers: Object.assign({ 'content-type': 'application/json' }, headers || {}),
        body: body ? (typeof body === 'string' ? body : JSON.stringify(body)) : undefined,
      }).then(async (r) => {
        const ct = r.headers.get('content-type') || '';
        let payload = null;
        try {
          if (ct.indexOf('application/json') >= 0) payload = await r.json();
          else payload = await r.text();
        } catch (_) {}
        sendResponse({ ok: true, status: r.status, payload });
      }).catch((e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
      return true; // resposta assincrona
    }
    default:
      return false;
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (!alarm.name.startsWith(ALARM_END)) return;
  const tabId = Number(alarm.name.slice(ALARM_END.length));
  if (!tabId) return;
  try { chrome.tabs.sendMessage(tabId, { __piloto: true, kind: 'endNow', motivo: 'alarme' }); } catch (_) {}
});
