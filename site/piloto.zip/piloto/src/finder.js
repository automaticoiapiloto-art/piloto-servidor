/*
 * finder.js — biblioteca de "achar+clicar" resistente a nomes de classe
 * embaralhados. Duas estrategias:
 *   1) por texto exato/parcial (case+acento insensitiveis)
 *   2) por assinatura aprendida (data-attr, aria, caminho DOM curto)
 *
 * Nao decide se DEVE clicar — quem decide e o motor. Aqui so a mecanica.
 */
;(function () {
  const CL = (self.CL = self.CL || {});
  if (CL.finder) return;

  const norma = (s) => (s || '').toString().replace(/\s+/g, ' ').trim();
  const semAcento = (s) => norma(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  const CLICAVEIS = 'button,[role="button"],a,[tabindex],li,div,span';

  function visivel(el) {
    if (!el || el.nodeType !== 1) return false;
    const r = el.getClientRects();
    if (!r || !r.length) return false;
    const s = getComputedStyle(el);
    if (s.visibility === 'hidden' || s.display === 'none') return false;
    if (parseFloat(s.opacity) === 0) return false;
    return true;
  }

  function texto(el, max) {
    return norma((el && (el.innerText || el.textContent)) || '').slice(0, max || 120);
  }

  function caminhoCurto(el, prof) {
    prof = prof || 6;
    const partes = [];
    let cur = el;
    for (let i = 0; i < prof && cur && cur.nodeType === 1 && cur.tagName !== 'BODY'; i++) {
      const tag = cur.tagName.toLowerCase();
      let nth = 1, sib = cur;
      while ((sib = sib.previousElementSibling)) if (sib.tagName === cur.tagName) nth++;
      partes.unshift(`${tag}:nth-of-type(${nth})`);
      cur = cur.parentElement;
    }
    return partes.join(' > ');
  }

  function acharPorTexto(query, raiz) {
    const alvo = semAcento(query);
    if (!alvo) return [];
    const escopo = raiz || document;
    const nodos = escopo.querySelectorAll(CLICAVEIS);
    const casa = [];
    for (const el of nodos) {
      if (!visivel(el)) continue;
      const t = semAcento(texto(el, 200));
      if (t === alvo) { casa.push({ el, exato: true }); continue; }
      if (t.indexOf(alvo) === 0 && t.length <= alvo.length + 3) { casa.push({ el, exato: false }); }
    }
    return casa;
  }

  function clicavelDe(el) {
    if (!el) return null;
    if (el.tagName && el.tagName.toLowerCase() === 'svg') {
      return el.closest('button,[role="button"],a') || el;
    }
    return el.closest('button,[role="button"],a,[tabindex]') || el;
  }

  // clique "de verdade": pointer + mouse + click, com bubbles. Alguns painels do
  // TikTok/YouTube ignoram click() puro se nao vier a sequencia de pointer antes.
  function clicarReal(el) {
    if (!el) return false;
    const alvo = clicavelDe(el);
    if (!alvo || !visivel(alvo)) return false;
    const rect = alvo.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const opt = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy };
    try {
      alvo.dispatchEvent(new PointerEvent('pointerover', opt));
      alvo.dispatchEvent(new MouseEvent('mouseover', opt));
      alvo.dispatchEvent(new PointerEvent('pointerdown', opt));
      alvo.dispatchEvent(new MouseEvent('mousedown', opt));
      alvo.dispatchEvent(new PointerEvent('pointerup', opt));
      alvo.dispatchEvent(new MouseEvent('mouseup', opt));
      alvo.dispatchEvent(new MouseEvent('click', opt));
      return true;
    } catch (_) {
      try { alvo.click(); return true; } catch (__) { return false; }
    }
  }

  // aprendiz: guarda "receita" pra achar de novo elementos que mudam de classe
  const receitas = new Map(); // nome -> {texto, aria, dataAttrs, caminho}
  function aprender(nome, el) {
    if (!nome || !el) return;
    const attrs = {};
    for (const a of el.attributes || []) {
      if (a.name === 'aria-label' || a.name.startsWith('data-')) attrs[a.name] = a.value;
    }
    receitas.set(nome, {
      texto: texto(el, 80),
      aria: el.getAttribute('aria-label') || '',
      attrs,
      caminho: caminhoCurto(el),
    });
  }
  function acharAprendido(nome) {
    const r = receitas.get(nome);
    if (!r) return null;
    if (r.aria) {
      const p = document.querySelector(`[aria-label="${cssEscape(r.aria)}"]`);
      if (p && visivel(p)) return p;
    }
    for (const [k, v] of Object.entries(r.attrs || {})) {
      const p = document.querySelector(`[${k}="${cssEscape(v)}"]`);
      if (p && visivel(p)) return p;
    }
    if (r.texto) {
      const cands = acharPorTexto(r.texto);
      if (cands.length) return cands[0].el;
    }
    return null;
  }

  function cssEscape(s) {
    try { return CSS.escape(s); } catch (_) { return String(s).replace(/["\\]/g, '\\$&'); }
  }

  CL.finder = {
    visivel,
    texto,
    porTexto: acharPorTexto,
    clicavelDe,
    clicar: clicarReal,
    caminhoCurto,
    aprender,
    acharAprendido,
    // atalho comum: achar pelo texto e clicar no primeiro que casar (retorna bool)
    clicarPorTexto(query, raiz) {
      const c = acharPorTexto(query, raiz);
      if (!c.length) return false;
      return clicarReal(c[0].el);
    },
  };
})();
