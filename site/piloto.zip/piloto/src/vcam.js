/*
 * vcam.js — CAMERA VIRTUAL (world: MAIN, document_start).
 *
 * Grampeia navigator.mediaDevices.getUserMedia: quando o vendedor liga a camera
 * virtual no painel e escolhe um video, o proximo pedido de webcam da pagina
 * recebe um MediaStream feito daquele video (imagem + audio embutido) em vez
 * da webcam real. Desligou, volta a webcam.
 *
 * O video toca do DISCO (blob URL criado pelo content script no IndexedDB).
 * A live NAO comeca a tocar sozinha: fica no 1o frame parada ate o content
 * mandar 'restart' (inicio da live) ou 'play' (botao do mini-player).
 *
 * Audio: roteado por Web Audio pra que o audio do video entre no MediaStream
 * (createMediaElementSource desliga o alto-falante local — sem eco/barulho).
 * Um tap quase-mudo (-64dB) mantem a aba "com audio tocando" pra o Chrome
 * nao estrangular o decode quando a aba fica oculta.
 */
;(function () {
  'use strict';

  const cfg = { enabled: false, licBloqueada: false, loop: true, blobUrl: '' };
  let token = '';

  // camera virtual esta OFERECIDA a pagina?
  const ativo = () => cfg.enabled && !cfg.licBloqueada && cfg.blobUrl;

  let vEl = null;         // <video> escondido que toca o arquivo
  let curStream = null;   // MediaStream que a gente devolveu pra live
  let audioCtx = null, mediaSrcNode = null, destNode = null;
  let keepAliveGain = null;
  let wakeLock = null;
  let deveTocar = false;

  const md = navigator.mediaDevices;
  if (!md || typeof md.getUserMedia !== 'function') return;
  const origGUM = md.getUserMedia.bind(md);
  const origEnum = md.enumerateDevices ? md.enumerateDevices.bind(md) : null;

  // ---------- escuta configuracao e comandos vindos do content script ----------
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    const d = ev.data;
    if (d.__pt_capctl && typeof d.token === 'string') { token = d.token; return; }
    if (!token || d.token !== token) return;
    if (d.__pt_vcam) { aplicarCfg(d.cfg || {}); return; }
    if (d.__pt_vcamcmd) { comando(d.cmd); return; }
  });

  function aplicarCfg(c) {
    const reconstruir = c.blobUrl !== undefined && c.blobUrl !== cfg.blobUrl;
    if (typeof c.enabled === 'boolean') cfg.enabled = c.enabled;
    if (typeof c.licBloqueada === 'boolean') cfg.licBloqueada = c.licBloqueada;
    if (typeof c.loop === 'boolean') cfg.loop = c.loop;
    if (typeof c.blobUrl === 'string') cfg.blobUrl = c.blobUrl;
    if (ativo()) garantirVideo(reconstruir);
    else desmontar();
  }

  function comando(cmd) {
    if (!vEl) return;
    try {
      if (cmd === 'play') { deveTocar = true; vEl.play().catch(() => {}); }
      else if (cmd === 'pause') { deveTocar = false; vEl.pause(); }
      else if (cmd === 'reset') { deveTocar = false; vEl.currentTime = 0; vEl.pause(); }
      else if (cmd === 'restart') { deveTocar = true; vEl.currentTime = 0; vEl.play().catch(() => {}); }
      else if (cmd === 'resync') { vEl.currentTime = Math.max(0, vEl.currentTime + 0.001); }
    } catch (_) {}
  }

  function garantirVideo(reconstruir) {
    if (vEl && !reconstruir) return;
    if (vEl) { try { vEl.pause(); vEl.src = ''; vEl.remove(); } catch (_) {} vEl = null; }
    vEl = document.createElement('video');
    vEl.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:2px;height:2px;pointer-events:none';
    vEl.muted = false; // precisa ter audio pra o Web Audio pegar
    vEl.loop = !!cfg.loop;
    vEl.playsInline = true;
    vEl.crossOrigin = 'anonymous';
    vEl.src = cfg.blobUrl;
    document.documentElement.appendChild(vEl);
    vEl.load();
  }

  function desmontar() {
    try { if (vEl) { vEl.pause(); vEl.src = ''; vEl.remove(); } } catch (_) {}
    vEl = null;
    try { if (mediaSrcNode) mediaSrcNode.disconnect(); } catch (_) {}
    try { if (destNode) destNode.disconnect(); } catch (_) {}
    try { if (keepAliveGain) keepAliveGain.disconnect(); } catch (_) {}
    try { if (audioCtx) audioCtx.close(); } catch (_) {}
    audioCtx = mediaSrcNode = destNode = keepAliveGain = null;
    curStream = null;
  }

  async function ensureWakeLock() {
    try {
      if (!ativo()) return;
      if (wakeLock && !wakeLock.released) return;
      if (navigator.wakeLock && document.visibilityState === 'visible') {
        wakeLock = await navigator.wakeLock.request('screen');
      }
    } catch (_) {}
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') ensureWakeLock();
  });

  // ---------- monta o MediaStream (video do vEl + audio via Web Audio) ----------
  function montarStream() {
    if (!vEl) return null;
    // video vem direto do element
    const vs = vEl.captureStream ? vEl.captureStream() : (vEl.mozCaptureStream ? vEl.mozCaptureStream() : null);
    if (!vs) return null;

    // audio: Web Audio pra separar do alto-falante local
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (!mediaSrcNode) mediaSrcNode = audioCtx.createMediaElementSource(vEl);
      if (!destNode) destNode = audioCtx.createMediaStreamDestination();
      mediaSrcNode.connect(destNode);
      // keep-alive: -64dB vai pro alto-falante local pra marcar a aba "com audio"
      if (!keepAliveGain) {
        keepAliveGain = audioCtx.createGain();
        keepAliveGain.gain.value = 0.001;
        mediaSrcNode.connect(keepAliveGain);
        keepAliveGain.connect(audioCtx.destination);
      }
      const at = destNode.stream.getAudioTracks()[0];
      if (at) vs.addTrack(at);
    } catch (_) {}

    return vs;
  }

  // ---------- grampo: getUserMedia ----------
  md.getUserMedia = async function (constraints) {
    // se a live nao pediu VIDEO, deixa passar (audio-only)
    const querVideo = constraints && (constraints.video === true || (constraints.video && typeof constraints.video === 'object'));
    if (!ativo() || !querVideo) return origGUM(constraints);

    // garante o <video> carregado
    garantirVideo(false);
    ensureWakeLock();

    // espera o video ter frames minimamente decodificados
    if (vEl.readyState < 2) {
      await new Promise((r) => {
        const on = () => { vEl.removeEventListener('loadeddata', on); r(); };
        vEl.addEventListener('loadeddata', on);
        setTimeout(r, 2000); // se demorar demais, tenta mesmo assim
      });
    }
    // 1o frame parado ate a live mandar 'restart'
    try { vEl.currentTime = 0; } catch (_) {}

    const s = montarStream();
    if (!s) return origGUM(constraints); // fallback pra webcam real se algo falhou

    curStream = s;
    // watchdog: se o browser pausar involuntariamente e a live "quer" tocando, retoma
    const wd = setInterval(() => {
      if (!vEl) return;
      if (deveTocar && vEl.paused) vEl.play().catch(() => {});
    }, 1000);
    s.oninactive = () => clearInterval(wd);
    return s;
  };

  // enumerateDevices: opcional — algumas paginas checam se ha camera antes de pedir
  if (origEnum) {
    md.enumerateDevices = async function () {
      const arr = await origEnum();
      // deixa como esta (nao precisa fingir um device virtual — grampo intercepta na hora do getUserMedia)
      return arr;
    };
  }
})();
