/*
 * vcam.js — CAMERA VIRTUAL (world: MAIN, document_start).
 *
 * Grampeia navigator.mediaDevices.getUserMedia: quando o vendedor liga a camera
 * virtual no painel e escolhe um video, o proximo pedido de webcam da pagina
 * recebe um MediaStream feito daquele video (imagem + audio embutido) em vez
 * da webcam real. Desligou, volta a webcam.
 *
 * O video toca do DISCO (blob URL criado pelo content script no IndexedDB).
 * A live NAO comeca a tocar sozinha: fica no 1o frame parada ate o content
 * mandar 'restart' (inicio da live) ou 'play' (botao do mini-player).
 *
 * Audio: roteado por Web Audio pra que o audio do video entre no MediaStream
 * (createMediaElementSource desliga o alto-falante local — sem eco/barulho).
 * Um tap quase-mudo (-64dB) mantem a aba "com audio tocando" pra o Chrome
 * nao estrangular o decode quando a aba fica oculta.
 */
;(function () {
  'use strict';

  const cfg = { enabled: false, licBloqueada: false, loop: true, blobUrl: '' };
  let token = '';

  // identidade fixa dos nossos devices virtuais — usados em enumerateDevices e no
  // getUserMedia quando a pagina faz seleção explicita (ex.: TikTok Shop).
  const VCAM_DEVICE_ID = 'pt-simulive-v1';
  const VCAM_GROUP_ID = 'pt-simulive-group-v1';
  const VCAM_LABEL = 'Piloto Automatico IA — Simulive';
  const VMIC_DEVICE_ID = 'pt-simulive-audio-v1';
  const VMIC_LABEL = 'Piloto Automatico IA — Áudio do vídeo';

  // camera virtual esta OFERECIDA a pagina?
  const ativo = () => cfg.enabled && !cfg.licBloqueada && cfg.blobUrl;

  function idBate(d, alvo) {
    if (!d) return false;
    if (typeof d === 'string') return d === alvo;
    if (d.exact === alvo || d.ideal === alvo) return true;
    if (Array.isArray(d.exact) && d.exact.includes(alvo)) return true;
    if (Array.isArray(d.ideal) && d.ideal.includes(alvo)) return true;
    return false;
  }

  // a pagina pediu explicitamente nosso device de VIDEO?
  function pediuVcam(constraints) {
    const v = constraints && constraints.video;
    if (!v || typeof v !== 'object') return false;
    return idBate(v.deviceId, VCAM_DEVICE_ID);
  }

  // a pagina pediu explicitamente nosso device de AUDIO?
  function pediuVmic(constraints) {
    const a = constraints && constraints.audio;
    if (!a || typeof a !== 'object') return false;
    return idBate(a.deviceId, VMIC_DEVICE_ID);
  }

  let vEl = null;         // <video> escondido que toca o arquivo
  let cEl = null;         // <canvas> escondido pra render dos frames
  let ctx2d = null;       // contexto 2d do canvas
  let rafId = 0;          // handle do requestAnimationFrame
  let curStream = null;   // MediaStream que a gente devolveu pra live
  let audioCtx = null, mediaSrcNode = null, destNode = null;
  let keepAliveGain = null;
  let wakeLock = null;
  let deveTocar = false;

  const md = navigator.mediaDevices;
  if (!md || typeof md.getUserMedia !== 'function') return;
  const origGUM = md.getUserMedia.bind(md);
  const origEnum = md.enumerateDevices ? md.enumerateDevices.bind(md) : null;

  // ---------- escuta configuracao e comandos vindos do content script ----------
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    const d = ev.data;
    if (d.__pt_capctl && typeof d.token === 'string') { token = d.token; return; }
    if (!token || d.token !== token) return;
    if (d.__pt_vcam) { aplicarCfg(d.cfg || {}); return; }
    if (d.__pt_vcamcmd) { comando(d.cmd); return; }
  });

  function aplicarCfg(c) {
    const antesAtivo = ativo();
    const reconstruir = c.blobUrl !== undefined && c.blobUrl !== cfg.blobUrl;
    if (typeof c.enabled === 'boolean') cfg.enabled = c.enabled;
    if (typeof c.licBloqueada === 'boolean') cfg.licBloqueada = c.licBloqueada;
    if (typeof c.loop === 'boolean') cfg.loop = c.loop;
    if (typeof c.blobUrl === 'string') cfg.blobUrl = c.blobUrl;
    if (ativo()) garantirVideo(reconstruir);
    else desmontar();
    // se o estado ativo/desativo mudou, dispara devicechange pra a pagina
    // recarregar a lista de cameras (TikTok Shop escuta esse evento).
    if (antesAtivo !== ativo()) {
      try { md.dispatchEvent(new Event('devicechange')); } catch (_) {}
    }
  }

  function comando(cmd) {
    if (!vEl) return;
    try {
      if (cmd === 'play') { deveTocar = true; vEl.play().catch(() => {}); }
      else if (cmd === 'pause') { deveTocar = false; vEl.pause(); }
      else if (cmd === 'reset') { deveTocar = false; vEl.currentTime = 0; vEl.pause(); }
      else if (cmd === 'restart') { deveTocar = true; vEl.currentTime = 0; vEl.play().catch(() => {}); }
      else if (cmd === 'resync') { vEl.currentTime = Math.max(0, vEl.currentTime + 0.001); }
    } catch (_) {}
  }

  function garantirVideo(reconstruir) {
    if (vEl && !reconstruir) return;
    if (vEl) { try { vEl.pause(); vEl.src = ''; vEl.remove(); } catch (_) {} vEl = null; }
    vEl = document.createElement('video');
    vEl.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:2px;height:2px;pointer-events:none';
    // muted=true libera autoplay do Chrome (side_panel NAO conta como user
    // activation na pagina). Web Audio pega o audio antes da saida do elemento.
    vEl.muted = true;
    vEl.autoplay = true;
    vEl.loop = !!cfg.loop;
    vEl.playsInline = true;
    vEl.preload = 'auto';
    vEl.crossOrigin = 'anonymous';
    vEl.src = cfg.blobUrl;
    document.documentElement.appendChild(vEl);
    vEl.load();

    // diagnostico: reporta pra pagina o estado do video conforme carrega
    const diag = (etapa, extra) => diagnostico(etapa, extra);
    diag('criado', { readyState: vEl.readyState, src: !!vEl.src });
    vEl.addEventListener('loadedmetadata', () => diag('loadedmetadata', { w: vEl.videoWidth, h: vEl.videoHeight, dur: vEl.duration }));
    vEl.addEventListener('loadeddata', () => diag('loadeddata', { readyState: vEl.readyState }));
    vEl.addEventListener('canplay', () => {
      diag('canplay', { paused: vEl.paused });
      // toca imediatamente ao poder — pra o captureStream ter frames desde ja
      deveTocar = true;
      vEl.play().then(() => diag('play-ok')).catch((e) => diag('play-erro', { msg: (e && e.message) || String(e) }));
    });
    vEl.addEventListener('playing', () => diag('playing'));
    vEl.addEventListener('error', () => diag('erro-video', { code: vEl.error && vEl.error.code, msg: vEl.error && vEl.error.message }));
  }

  function diagnostico(etapa, extra) {
    try {
      window.postMessage({ __pt_vcamdiag: true, etapa, extra: extra || null, t: Date.now() }, location.origin);
    } catch (_) {}
  }

  function desmontar() {
    try { if (rafId) cancelAnimationFrame(rafId); } catch (_) {}
    rafId = 0;
    try { if (vEl) { vEl.pause(); vEl.src = ''; vEl.remove(); } } catch (_) {}
    try { if (cEl) cEl.remove(); } catch (_) {}
    vEl = null; cEl = null; ctx2d = null;
    try { if (mediaSrcNode) mediaSrcNode.disconnect(); } catch (_) {}
    try { if (destNode) destNode.disconnect(); } catch (_) {}
    try { if (keepAliveGain) keepAliveGain.disconnect(); } catch (_) {}
    try { if (audioCtx) audioCtx.close(); } catch (_) {}
    audioCtx = mediaSrcNode = destNode = keepAliveGain = null;
    curStream = null;
  }

  async function ensureWakeLock() {
    try {
      if (!ativo()) return;
      if (wakeLock && !wakeLock.released) return;
      if (navigator.wakeLock && document.visibilityState === 'visible') {
        wakeLock = await navigator.wakeLock.request('screen');
      }
    } catch (_) {}
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') ensureWakeLock();
  });

  // ---------- monta o MediaStream (video via canvas + audio via Web Audio) ----------
  // Usa canvas.captureStream em vez de video.captureStream — muito mais
  // confiavel no Chrome. Um loop de rAF desenha os frames do <video> no canvas
  // e o canvas gera o stream. Se o video pausar ou trocar, o loop continua
  // servindo o ultimo frame ate voltar.
  function montarStream() {
    if (!vEl) return null;

    const w = vEl.videoWidth || 1280;
    const h = vEl.videoHeight || 720;

    if (!cEl) {
      cEl = document.createElement('canvas');
      cEl.width = w;
      cEl.height = h;
      cEl.style.cssText = 'position:fixed;left:-9999px;top:-9999px;pointer-events:none';
      document.documentElement.appendChild(cEl);
      ctx2d = cEl.getContext('2d', { alpha: false, desynchronized: true });
      diagnostico('canvas-criado', { w, h });
    } else {
      if (cEl.width !== w) cEl.width = w;
      if (cEl.height !== h) cEl.height = h;
    }

    // loop de render: copia o frame atual do video pro canvas ~60fps
    const render = () => {
      try {
        if (vEl && vEl.readyState >= 2) {
          ctx2d.drawImage(vEl, 0, 0, cEl.width, cEl.height);
        }
      } catch (_) {}
      rafId = requestAnimationFrame(render);
    };
    if (!rafId) rafId = requestAnimationFrame(render);

    // video track vem do canvas
    const vs = cEl.captureStream ? cEl.captureStream(30) : null;
    if (!vs) return null;

    // audio: Web Audio pra separar do alto-falante local
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
      if (!mediaSrcNode) mediaSrcNode = audioCtx.createMediaElementSource(vEl);
      if (!destNode) destNode = audioCtx.createMediaStreamDestination();
      mediaSrcNode.connect(destNode);
      if (!keepAliveGain) {
        keepAliveGain = audioCtx.createGain();
        keepAliveGain.gain.value = 0.001;
        mediaSrcNode.connect(keepAliveGain);
        keepAliveGain.connect(audioCtx.destination);
      }
      const at = destNode.stream.getAudioTracks()[0];
      if (at) vs.addTrack(at);
    } catch (e) {
      diagnostico('audio-erro', { msg: (e && e.message) || String(e) });
    }

    diagnostico('stream-montado', { tracks: vs.getTracks().map((t) => t.kind) });
    return vs;
  }

  // ---------- grampo: getUserMedia ----------
  md.getUserMedia = async function (constraints) {
    const querVideo = constraints && (constraints.video === true || (constraints.video && typeof constraints.video === 'object'));
    const querAudio = constraints && (constraints.audio === true || (constraints.audio && typeof constraints.audio === 'object'));
    const pediuVideoNosso = pediuVcam(constraints);
    const pediuAudioNosso = pediuVmic(constraints);

    // caminhos que NAO ativam o grampo (deixa passar pro navegador):
    //  - pediu nossos devices explicitamente mas a camera virtual esta desligada
    //  - nao pediu nossos devices E (camera virtual off OU nao quer video/audio)
    if ((pediuVideoNosso || pediuAudioNosso) && !ativo()) return origGUM(constraints);
    if (!pediuVideoNosso && !pediuAudioNosso && (!ativo() || (!querVideo && !querAudio))) return origGUM(constraints);

    // garante o <video> carregado + play imediato
    garantirVideo(false);
    ensureWakeLock();
    if (vEl.readyState < 2) {
      await new Promise((r) => {
        const on = () => { vEl.removeEventListener('loadeddata', on); r(); };
        vEl.addEventListener('loadeddata', on);
        setTimeout(r, 2000);
      });
    }
    try { vEl.currentTime = 0; } catch (_) {}
    deveTocar = true;
    try { await vEl.play(); } catch (_) {}

    const s = montarStream();
    if (!s) return origGUM(constraints);

    // se pediu SO audio (audio-only, sem video), devolve stream so com track de audio
    if (pediuAudioNosso && !querVideo) {
      const sAudio = new MediaStream();
      const at = s.getAudioTracks()[0];
      if (at) sAudio.addTrack(at);
      curStream = sAudio;
      const wd = setInterval(() => { if (vEl && deveTocar && vEl.paused) vEl.play().catch(() => {}); }, 1000);
      sAudio.oninactive = () => clearInterval(wd);
      return sAudio;
    }

    curStream = s;
    // watchdog: se o browser pausar involuntariamente e a live "quer" tocando, retoma
    const wd = setInterval(() => {
      if (!vEl) return;
      if (deveTocar && vEl.paused) vEl.play().catch(() => {});
    }, 1000);
    s.oninactive = () => clearInterval(wd);
    return s;
  };

  // enumerateDevices: injeta nossos devices virtuais SEMPRE (video + audio).
  // Motivo: paginas como o TikTok Shop chamam enumerateDevices UMA vez ao
  // abrir o modal e cacheiam o resultado. Se so injetassemos quando ativo(),
  // a chamada podia acontecer antes da config chegar via postMessage.
  if (origEnum) {
    md.enumerateDevices = async function () {
      const arr = await origEnum();
      const mk = (id, kind, label) => ({
        deviceId: id,
        groupId: VCAM_GROUP_ID,
        kind,
        label,
        toJSON() { return { deviceId: this.deviceId, groupId: this.groupId, kind: this.kind, label: this.label }; },
      });
      return arr.concat([
        mk(VCAM_DEVICE_ID, 'videoinput', VCAM_LABEL),
        mk(VMIC_DEVICE_ID, 'audioinput', VMIC_LABEL),
      ]);
    };
  }
})();
