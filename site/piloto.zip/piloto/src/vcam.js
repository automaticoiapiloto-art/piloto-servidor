/*
 * vcam.js — CAMERA VIRTUAL (world: MAIN, document_start).
 *
 * Grampeia navigator.mediaDevices.getUserMedia: quando o vendedor liga a camera
 * virtual no painel e escolhe um video, o proximo pedido de webcam da pagina
 * recebe um MediaStream feito daquele video (imagem + audio embutido) em vez
 * da webcam real. Desligou, volta a webcam.
 *
 * O video toca do DISCO (blob URL criado pelo content script no IndexedDB).
 * A live NAO comeca a tocar sozinha: fica no 1o frame parada ate o content
 * mandar 'restart' (inicio da live) ou 'play' (botao do mini-player).
 *
 * Audio: roteado por Web Audio pra que o audio do video entre no MediaStream
 * (createMediaElementSource desliga o alto-falante local — sem eco/barulho).
 * Um tap quase-mudo (-64dB) mantem a aba "com audio tocando" pra o Chrome
 * nao estrangular o decode quando a aba fica oculta.
 */
;(function () {
  'use strict';

  const cfg = { enabled: false, licBloqueada: false, loop: true, blobUrl: '' };
  let token = '';

  // identidade fixa dos nossos devices virtuais — usados em enumerateDevices e no
  // getUserMedia quando a pagina faz seleção explicita (ex.: TikTok Shop).
  const VCAM_DEVICE_ID = 'pt-simulive-v1';
  const VCAM_GROUP_ID = 'pt-simulive-group-v1';
  const VCAM_LABEL = 'Piloto Automatico IA — Simulive';
  const VMIC_DEVICE_ID = 'pt-simulive-audio-v1';
  const VMIC_LABEL = 'Piloto Automatico IA — Áudio do vídeo';

  // camera virtual esta OFERECIDA a pagina?
  const ativo = () => cfg.enabled && !cfg.licBloqueada && cfg.blobUrl;

  function idBate(d, alvo) {
    if (!d) return false;
    if (typeof d === 'string') return d === alvo;
    if (d.exact === alvo || d.ideal === alvo) return true;
    if (Array.isArray(d.exact) && d.exact.includes(alvo)) return true;
    if (Array.isArray(d.ideal) && d.ideal.includes(alvo)) return true;
    return false;
  }

  // a pagina pediu explicitamente nosso device de VIDEO?
  function pediuVcam(constraints) {
    const v = constraints && constraints.video;
    if (!v || typeof v !== 'object') return false;
    return idBate(v.deviceId, VCAM_DEVICE_ID);
  }

  // a pagina pediu explicitamente nosso device de AUDIO?
  function pediuVmic(constraints) {
    const a = constraints && constraints.audio;
    if (!a || typeof a !== 'object') return false;
    return idBate(a.deviceId, VMIC_DEVICE_ID);
  }

  let vEl = null;         // <video> escondido que toca o arquivo
  let curStream = null;   // MediaStream que a gente devolveu pra live
  let audioCtx = null, mediaSrcNode = null, destNode = null;
  let keepAliveGain = null;
  let wakeLock = null;
  let deveTocar = false;

  const md = navigator.mediaDevices;
  if (!md || typeof md.getUserMedia !== 'function') return;
  const origGUM = md.getUserMedia.bind(md);
  const origEnum = md.enumerateDevices ? md.enumerateDevices.bind(md) : null;

  // ---------- escuta configuracao e comandos vindos do content script ----------
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    const d = ev.data;
    if (d.__pt_capctl && typeof d.token === 'string') { token = d.token; return; }
    if (!token || d.token !== token) return;
    if (d.__pt_vcam) { aplicarCfg(d.cfg || {}); return; }
    if (d.__pt_vcamcmd) { comando(d.cmd); return; }
  });

  function aplicarCfg(c) {
    const antesAtivo = ativo();
    const reconstruir = c.blobUrl !== undefined && c.blobUrl !== cfg.blobUrl;
    if (typeof c.enabled === 'boolean') cfg.enabled = c.enabled;
    if (typeof c.licBloqueada === 'boolean') cfg.licBloqueada = c.licBloqueada;
    if (typeof c.loop === 'boolean') cfg.loop = c.loop;
    if (typeof c.blobUrl === 'string') cfg.blobUrl = c.blobUrl;
    if (ativo()) garantirVideo(reconstruir);
    else desmontar();
    // se o estado ativo/desativo mudou, dispara devicechange pra a pagina
    // recarregar a lista de cameras (TikTok Shop escuta esse evento).
    if (antesAtivo !== ativo()) {
      try { md.dispatchEvent(new Event('devicechange')); } catch (_) {}
    }
  }

  function comando(cmd) {
    if (!vEl) return;
    try {
      if (cmd === 'play') { deveTocar = true; vEl.play().catch(() => {}); }
      else if (cmd === 'pause') { deveTocar = false; vEl.pause(); }
      else if (cmd === 'reset') { deveTocar = false; vEl.currentTime = 0; vEl.pause(); }
      else if (cmd === 'restart') { deveTocar = true; vEl.currentTime = 0; vEl.play().catch(() => {}); }
      else if (cmd === 'resync') { vEl.currentTime = Math.max(0, vEl.currentTime + 0.001); }
    } catch (_) {}
  }

  function garantirVideo(reconstruir) {
    if (vEl && !reconstruir) return;
    if (vEl) { try { vEl.pause(); vEl.src = ''; vEl.remove(); } catch (_) {} vEl = null; }
    vEl = document.createElement('video');
    vEl.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:2px;height:2px;pointer-events:none';
    // muted=true libera autoplay do Chrome (importante: cliques no side_panel
    // NAO contam como user activation na pagina do TikTok, entao play() sem
    // muted era rejeitado silenciosamente). Web Audio pega o audio ANTES da
    // saida do elemento — o MediaStream continua com som normal.
    vEl.muted = true;
    vEl.autoplay = true;
    vEl.loop = !!cfg.loop;
    vEl.playsInline = true;
    vEl.crossOrigin = 'anonymous';
    vEl.src = cfg.blobUrl;
    document.documentElement.appendChild(vEl);
    vEl.load();
  }

  function desmontar() {
    try { if (vEl) { vEl.pause(); vEl.src = ''; vEl.remove(); } } catch (_) {}
    vEl = null;
    try { if (mediaSrcNode) mediaSrcNode.disconnect(); } catch (_) {}
    try { if (destNode) destNode.disconnect(); } catch (_) {}
    try { if (keepAliveGain) keepAliveGain.disconnect(); } catch (_) {}
    try { if (audioCtx) audioCtx.close(); } catch (_) {}
    audioCtx = mediaSrcNode = destNode = keepAliveGain = null;
    curStream = null;
  }

  async function ensureWakeLock() {
    try {
      if (!ativo()) return;
      if (wakeLock && !wakeLock.released) return;
      if (navigator.wakeLock && document.visibilityState === 'visible') {
        wakeLock = await navigator.wakeLock.request('screen');
      }
    } catch (_) {}
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') ensureWakeLock();
  });

  // ---------- monta o MediaStream (video do vEl + audio via Web Audio) ----------
  function montarStream() {
    if (!vEl) return null;
    // video vem direto do element
    const vs = vEl.captureStream ? vEl.captureStream() : (vEl.mozCaptureStream ? vEl.mozCaptureStream() : null);
    if (!vs) return null;

    // audio: Web Audio pra separar do alto-falante local
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (!mediaSrcNode) mediaSrcNode = audioCtx.createMediaElementSource(vEl);
      if (!destNode) destNode = audioCtx.createMediaStreamDestination();
      mediaSrcNode.connect(destNode);
      // keep-alive: -64dB vai pro alto-falante local pra marcar a aba "com audio"
      if (!keepAliveGain) {
        keepAliveGain = audioCtx.createGain();
        keepAliveGain.gain.value = 0.001;
        mediaSrcNode.connect(keepAliveGain);
        keepAliveGain.connect(audioCtx.destination);
      }
      const at = destNode.stream.getAudioTracks()[0];
      if (at) vs.addTrack(at);
    } catch (_) {}

    return vs;
  }

  // ---------- grampo: getUserMedia ----------
  md.getUserMedia = async function (constraints) {
    const querVideo = constraints && (constraints.video === true || (constraints.video && typeof constraints.video === 'object'));
    const querAudio = constraints && (constraints.audio === true || (constraints.audio && typeof constraints.audio === 'object'));
    const pediuVideoNosso = pediuVcam(constraints);
    const pediuAudioNosso = pediuVmic(constraints);

    // caminhos que NAO ativam o grampo (deixa passar pro navegador):
    //  - pediu nossos devices explicitamente mas a camera virtual esta desligada
    //  - nao pediu nossos devices E (camera virtual off OU nao quer video/audio)
    if ((pediuVideoNosso || pediuAudioNosso) && !ativo()) return origGUM(constraints);
    if (!pediuVideoNosso && !pediuAudioNosso && (!ativo() || (!querVideo && !querAudio))) return origGUM(constraints);

    // garante o <video> carregado + play imediato
    garantirVideo(false);
    ensureWakeLock();
    if (vEl.readyState < 2) {
      await new Promise((r) => {
        const on = () => { vEl.removeEventListener('loadeddata', on); r(); };
        vEl.addEventListener('loadeddata', on);
        setTimeout(r, 2000);
      });
    }
    try { vEl.currentTime = 0; } catch (_) {}
    deveTocar = true;
    try { await vEl.play(); } catch (_) {}

    const s = montarStream();
    if (!s) return origGUM(constraints);

    // se pediu SO audio (audio-only, sem video), devolve stream so com track de audio
    if (pediuAudioNosso && !querVideo) {
      const sAudio = new MediaStream();
      const at = s.getAudioTracks()[0];
      if (at) sAudio.addTrack(at);
      curStream = sAudio;
      const wd = setInterval(() => { if (vEl && deveTocar && vEl.paused) vEl.play().catch(() => {}); }, 1000);
      sAudio.oninactive = () => clearInterval(wd);
      return sAudio;
    }

    curStream = s;
    // watchdog: se o browser pausar involuntariamente e a live "quer" tocando, retoma
    const wd = setInterval(() => {
      if (!vEl) return;
      if (deveTocar && vEl.paused) vEl.play().catch(() => {});
    }, 1000);
    s.oninactive = () => clearInterval(wd);
    return s;
  };

  // enumerateDevices: injeta nossos devices virtuais SEMPRE (video + audio).
  // Motivo: paginas como o TikTok Shop chamam enumerateDevices UMA vez ao
  // abrir o modal e cacheiam o resultado. Se so injetassemos quando ativo(),
  // a chamada podia acontecer antes da config chegar via postMessage.
  if (origEnum) {
    md.enumerateDevices = async function () {
      const arr = await origEnum();
      const mk = (id, kind, label) => ({
        deviceId: id,
        groupId: VCAM_GROUP_ID,
        kind,
        label,
        toJSON() { return { deviceId: this.deviceId, groupId: this.groupId, kind: this.kind, label: this.label }; },
      });
      return arr.concat([
        mk(VCAM_DEVICE_ID, 'videoinput', VCAM_LABEL),
        mk(VMIC_DEVICE_ID, 'audioinput', VMIC_LABEL),
      ]);
    };
  }
})();
