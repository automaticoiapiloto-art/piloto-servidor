/*
 * vcam.js — CAMERA VIRTUAL. Roda no MUNDO DA PAGINA (world: MAIN), document_start.
 * Grampeia navigator.mediaDevices.getUserMedia: quando ligado e com um video
 * escolhido, devolve pra live um MediaStream feito do VIDEO (imagem + audio
 * embutido) em vez da webcam.
 *
 * O video toca DO DISCO (blob URL criado no content script). Comando vem do
 * content.js por postMessage com o token do canal. Desligou -> webcam real.
 *
 * Compat: escuta AMBOS os canais __cl_* (heranca) e __pt_* (piloto). Assim
 * pode-se migrar o content.js aos poucos sem quebrar.
 */
;(function () {
  'use strict';
  let token = '';
  const cfg = { enabled: false, licBloqueada: false, loop: true, blobUrl: '', blob: null };
  // "estava ligada" e "foi liberada" — write-once. Quando um applyCfg chegou
  // com enabled=true+blob (ligou) OU com licBloqueada=false (liberou),
  // marcamos essas flags e NUNCA revertemos. Assim o vcam ignora sinais
  // transitorios (popup oscilando, license.js voltando pra trial-expirado
  // por race). Uma vez que a live sabe que a licenca vale, vale ate reload.
  let jaLigouComBlob = false;
  let jaFoiLiberadaLic = false;
  const ativo = () => (cfg.enabled || jaLigouComBlob)
    && (jaFoiLiberadaLic || !cfg.licBloqueada)
    && (cfg.blob || cfg.blobUrl);
  let vEl = null;
  let curStream = null;
  let audioCtx = null, mediaSrcNode = null;
  let keepAliveGain = null;
  let wakeLock = null;
  let deveTocar = false;
  // Set de streams JA ENTREGUES pra a pagina — usado pra proteger contra
  // teardown durante live ativa. Declarado antes de applyCfg pra evitar TDZ.
  const nossasFaixas = new WeakSet();
  const streamsEntregues = new Set();

  const VCAM_DEV_ID = 'pt-simulive-v1';
  const VCAM_MIC_ID = 'pt-simulive-audio-v1';
  const VCAM_LABEL = 'Piloto Automatico IA — Simulive';
  const VMIC_LABEL = 'Piloto Automatico IA — Audio do video';

  function diag(etapa, extra) {
    try {
      window.postMessage({ __pt_vcamdiag: true, etapa, extra: extra || null, t: Date.now() }, location.origin);
    } catch (_) {}
  }

  async function ensureWakeLock() {
    try {
      if (!cfg.enabled || (!cfg.blob && !cfg.blobUrl)) return;
      if (wakeLock && !wakeLock.released) return;
      if (navigator.wakeLock && document.visibilityState === 'visible') {
        wakeLock = await navigator.wakeLock.request('screen');
      }
    } catch (_) {}
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') ensureWakeLock();
  });

  const md = navigator.mediaDevices;
  const origGUM = md && typeof md.getUserMedia === 'function' ? md.getUserMedia.bind(md) : null;
  if (!origGUM) return;

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    const d = ev.data;
    // NAO checa token — ev.source === window ja garante mesmo frame/origin.
    // Sem isso, race condition com transporte.js em multiplos frames rejeita
    // mensagens legitimas ("token difere"). O token era defesa em profundidade
    // contra scripts terceiros do mesmo origin, mas nao vale a pena o custo.
    if ((d.__cl_capctl || d.__pt_capctl) && typeof d.token === 'string') {
      token = d.token;
      diag('token-recebido');
      return;
    }
    if (d.__cl_vcam || d.__pt_vcam) { applyCfg(d.cfg || {}); return; }
    if (d.__cl_vcamcmd || d.__pt_vcamcmd) { doCmd(d.cmd); return; }
  });

  function applyCfg(c) {
    const antesAtivo = ativo();
    // detecta se o blob mudou (compara referencia — content.js reusa o mesmo Blob)
    const blobMudou = 'blob' in c && c.blob !== cfg.blob;
    const rebuild = blobMudou || (typeof c.blobUrl === 'string' && c.blobUrl !== cfg.blobUrl);
    if (typeof c.enabled === 'boolean') cfg.enabled = c.enabled;
    if (typeof c.licBloqueada === 'boolean') cfg.licBloqueada = c.licBloqueada;
    if (typeof c.loop === 'boolean') cfg.loop = c.loop;
    if ('blob' in c) {
      cfg.blob = c.blob;
      // revoga URL antiga e cria uma nova NO REALM MAIN — resolve o erro-video code:4
      if (cfg.blobUrl) { try { URL.revokeObjectURL(cfg.blobUrl); } catch (_) {} cfg.blobUrl = ''; }
      if (c.blob instanceof Blob) {
        try { cfg.blobUrl = URL.createObjectURL(c.blob); }
        catch (e) { diag('erro-createObjectURL', { msg: (e && e.message) || String(e) }); }
      }
    } else if (typeof c.blobUrl === 'string') {
      cfg.blobUrl = c.blobUrl;
    }
    // write-once: marca sticky flags se alguma vez chegou o sinal bom
    if (cfg.enabled && (cfg.blob || cfg.blobUrl)) jaLigouComBlob = true;
    if (typeof c.licBloqueada === 'boolean' && c.licBloqueada === false) jaFoiLiberadaLic = true;
    // ativa se: ja ligou uma vez OU enabled=true agora, E (ja liberou uma vez OU lic=false agora), E tem blob
    const querAtivar = (cfg.enabled || jaLigouComBlob)
      && (jaFoiLiberadaLic || !cfg.licBloqueada)
      && (cfg.blob || cfg.blobUrl);
    diag('applyCfg', { enabled: cfg.enabled, jaLigou: jaLigouComBlob, hasBlob: !!(cfg.blob || cfg.blobUrl), lic: cfg.licBloqueada, jaLib: jaFoiLiberadaLic, blobSize: cfg.blob && cfg.blob.size ? (cfg.blob.size / 1024 / 1024).toFixed(1) + 'MB' : '?' });
    if (querAtivar) {
      ensureVideo(rebuild);
    } else {
      // so derruba se o usuario EXPLICITAMENTE removeu o blob OU se lic
      // bloqueou. Nao derruba enquanto ha stream sendo consumido.
      const temStreamAtivo = streamsEntregues && streamsEntregues.size > 0;
      if (!temStreamAtivo) teardown();
      else diag('teardown-ignorado', { motivo: 'stream ativo em uso' });
    }
    const agoraAtivo = ativo();
    if (antesAtivo !== agoraAtivo) {
      try { md.dispatchEvent(new Event('devicechange')); } catch (_) {}
    }
  }

  function doCmd(cmd) {
    if (!vEl) return;
    try {
      if (cmd === 'play') { deveTocar = true; vEl.play().catch(() => {}); }
      else if (cmd === 'pause') { deveTocar = false; vEl.pause(); }
      else if (cmd === 'reset') { deveTocar = false; vEl.currentTime = 0; vEl.pause(); }
      else if (cmd === 'restart') { deveTocar = true; vEl.currentTime = 0; vEl.play().catch(() => {}); }
      else if (cmd === 'resync') { vEl.currentTime = Math.max(0, vEl.currentTime + 0.001); }
    } catch (_) {}
  }

  function ensureVideo(rebuild) {
    if (vEl && !rebuild) { vEl.loop = cfg.loop; return; }
    teardown();
    vEl = document.createElement('video');
    vEl.id = 'pt_vcam_src';
    vEl.src = cfg.blobUrl;
    vEl.loop = cfg.loop;
    vEl.autoplay = false;
    vEl.playsInline = true;
    vEl.setAttribute('playsinline', '');
    // CRITICO: NAO jogar pra fora da tela (-99999px) nem opacity:0. Chrome
    // ESTRANGULA video invisivel/fora da tela e o captureStream sai preto/
    // picotado. 80px opacity 0.06 dentro da viewport, atras de tudo, e o
    // sweet spot — invisivel pro usuario mas nao pro engine de midia.
    vEl.style.cssText = 'position:fixed;left:0;bottom:0;width:80px;height:80px;opacity:0.06;pointer-events:none;z-index:-2147483647;';
    (document.documentElement || document.body).appendChild(vEl);
    diag('criado', { src: !!cfg.blobUrl });
    const start = () => { buildCurStream(); diag('stream-pronto', { tracks: curStream ? curStream.getTracks().map((t) => t.kind) : [] }); };
    if (vEl.readyState >= 2) start();
    else vEl.addEventListener('loadeddata', start, { once: true });
    vEl.addEventListener('loadedmetadata', () => diag('loadedmetadata', { w: vEl.videoWidth, h: vEl.videoHeight, dur: vEl.duration }));
    vEl.addEventListener('canplay', () => diag('canplay'));
    vEl.addEventListener('playing', () => diag('playing'));
    vEl.addEventListener('error', () => diag('erro-video', { code: vEl.error && vEl.error.code }));
  }

  function buildCurStream() {
    if (!vEl) return;
    const out = new MediaStream();
    let cs = null;
    try { cs = vEl.captureStream ? vEl.captureStream() : (vEl.mozCaptureStream ? vEl.mozCaptureStream() : null); } catch (_) {}
    if (cs) cs.getVideoTracks().forEach((t) => out.addTrack(t));
    let gotAudio = false;
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (!mediaSrcNode) mediaSrcNode = audioCtx.createMediaElementSource(vEl);
      const dest = audioCtx.createMediaStreamDestination();
      mediaSrcNode.connect(dest);
      if (!keepAliveGain) {
        keepAliveGain = audioCtx.createGain();
        keepAliveGain.gain.value = 0.0006;
        keepAliveGain.connect(audioCtx.destination);
      }
      if (!mediaSrcNode.__ptKeepAlive) { mediaSrcNode.connect(keepAliveGain); mediaSrcNode.__ptKeepAlive = true; }
      dest.stream.getAudioTracks().forEach((t) => { out.addTrack(t); gotAudio = true; });
    } catch (e) {
      diag('audio-erro', { msg: (e && e.message) || String(e) });
    }
    ensureWakeLock();
    if (!gotAudio && cs) cs.getAudioTracks().forEach((t) => out.addTrack(t));
    curStream = out;
  }

  function teardown() {
    if (vEl) { try { vEl.pause(); vEl.removeAttribute('src'); vEl.load(); vEl.remove(); } catch (_) {} vEl = null; }
    try { if (mediaSrcNode) mediaSrcNode.disconnect(); } catch (_) {}
    mediaSrcNode = null;
    curStream = null;
    try { if (wakeLock) { wakeLock.release(); } } catch (_) {}
    wakeLock = null;
  }

  // WATCHDOG anti-travamento
  let wLastCt = -1, wLastAt = 0;
  setInterval(() => {
    try { reporFaixasMortas(); } catch (_) {}
    try { if (audioCtx && audioCtx.state !== 'running' && curStream) audioCtx.resume(); } catch (_) {}
    try { if (curStream) ensureWakeLock(); } catch (_) {}
    if (!vEl) { wLastCt = -1; return; }
    if (deveTocar && vEl.paused && !vEl.ended) { try { vEl.play().catch(() => {}); } catch (_) {} }
    if (vEl.paused) { wLastCt = -1; return; }
    const ct = vEl.currentTime, now = Date.now();
    if (ct === wLastCt) {
      if (wLastAt && now - wLastAt > 2000) { try { vEl.play().catch(() => {}); } catch (_) {} wLastAt = now; }
    } else { wLastCt = ct; wLastAt = now; }
  }, 1000);

  // ---- FAIXAS CLONADAS + AUTO-REPARO ----
  // Entregamos CLONES: se a pagina mandar t.stop(), morre so a copia e a nossa
  // fonte segue viva. Guardamos os streams entregues pra repor faixas mortas.
  // (nossasFaixas e streamsEntregues declarados no topo pra applyCfg poder ler.)
  function novaFaixa(kind) {
    if (!curStream) return null;
    const src = (kind === 'video' ? curStream.getVideoTracks() : curStream.getAudioTracks())[0];
    if (!src) return null;
    let t = src;
    try { t = src.clone(); } catch (_) { t = src; }
    nossasFaixas.add(t);
    return t;
  }
  function reporFaixasMortas() {
    if (!curStream || !streamsEntregues.size) return false;
    let trocou = false;
    for (const s of streamsEntregues) {
      let vivo = false;
      for (const kind of ['video', 'audio']) {
        const atuais = kind === 'video' ? s.getVideoTracks() : s.getAudioTracks();
        const mortas = atuais.filter((t) => nossasFaixas.has(t) && t.readyState === 'ended');
        if (atuais.some((t) => t.readyState === 'live')) vivo = true;
        if (!mortas.length) continue;
        mortas.forEach((t) => { try { s.removeTrack(t); } catch (_) {} });
        const nova = novaFaixa(kind);
        if (nova) { try { s.addTrack(nova); vivo = true; trocou = true; } catch (_) {} }
      }
      if (!vivo) streamsEntregues.delete(s);
    }
    return trocou;
  }

  function buildStream(constraints) {
    const out = new MediaStream();
    if (!curStream) return out;
    const querVideo = !!(constraints && constraints.video);
    const querAudio = !!(constraints && constraints.audio);
    if (querVideo) { const t = novaFaixa('video'); if (t) out.addTrack(t); }
    if (querAudio) { const t = novaFaixa('audio'); if (t) out.addTrack(t); }
    if (out.getTracks().length) streamsEntregues.add(out);
    return out;
  }

  function pediuNossoDispositivo(constraints) {
    const idDe = (c) => {
      if (!c || typeof c !== 'object') return '';
      const d = c.deviceId;
      if (!d) return '';
      return typeof d === 'string' ? d : String(d.exact || d.ideal || '');
    };
    return idDe(constraints && constraints.video) === VCAM_DEV_ID
      || idDe(constraints && constraints.audio) === VCAM_MIC_ID;
  }
  function semNossoDispositivo(constraints) {
    try {
      const c = JSON.parse(JSON.stringify(constraints || {}));
      for (const k of ['video', 'audio']) {
        if (c[k] && typeof c[k] === 'object' && c[k].deviceId) {
          delete c[k].deviceId;
          if (!Object.keys(c[k]).length) c[k] = true;
        }
      }
      return c;
    } catch (_) {
      return { video: !!(constraints && constraints.video), audio: !!(constraints && constraints.audio) };
    }
  }

  function esperaStream(ms) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      (function tick() {
        if (curStream || Date.now() - t0 > ms) return resolve(!!curStream);
        setTimeout(tick, 100);
      })();
    });
  }

  function pediuOutroDispositivo(constraints) {
    const idDe = (c) => {
      if (!c || typeof c !== 'object') return '';
      const d = c.deviceId;
      if (!d) return '';
      return typeof d === 'string' ? d : String(d.exact || d.ideal || '');
    };
    const v = idDe(constraints && constraints.video);
    const a = idDe(constraints && constraints.audio);
    return (!!v && v !== VCAM_DEV_ID) || (!!a && a !== VCAM_MIC_ID);
  }

  const wrapped = async function (constraints) {
    if (ativo() && pediuOutroDispositivo(constraints)) {
      try { return await origGUM(constraints); } catch (_) {}
    }
    try {
      if (ativo() && constraints && (constraints.video || constraints.audio)) {
        try { if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume(); } catch (_) {}
        if (vEl && vEl.paused) { try { vEl.play().catch(() => {}); } catch (_) {} }
        ensureWakeLock();
        if (!curStream) { try { ensureVideo(false); } catch (_) {} await esperaStream(3000); }
        const s = buildStream(constraints);
        if (s.getTracks().length) { diag('gum-entregou', { tracks: s.getTracks().map((t) => t.kind) }); return s; }
      }
    } catch (_) {}
    if (pediuNossoDispositivo(constraints)) return origGUM(semNossoDispositivo(constraints));
    return origGUM(constraints);
  };
  try { md.getUserMedia = wrapped; }
  catch (_) { try { Object.defineProperty(md, 'getUserMedia', { value: wrapped, configurable: true, writable: true }); } catch (__) {} }

  // ---- enumerateDevices ----
  const origEnum = md && typeof md.enumerateDevices === 'function' ? md.enumerateDevices.bind(md) : null;
  if (origEnum) {
    // ⚠️ objeto entra NA FRENTE. TikTok chama getCapabilities/getSettings — precisam existir.
    const fakeDev = (deviceId, kind, label) => ({
      deviceId, kind, label, groupId: 'piloto-automatico-ia',
      toJSON() { return { deviceId, kind, label, groupId: 'piloto-automatico-ia' }; },
      getCapabilities() {
        if (kind !== 'videoinput') return { deviceId, groupId: 'piloto-automatico-ia' };
        const w = (vEl && vEl.videoWidth) ? vEl.videoWidth : 1080;
        const h = (vEl && vEl.videoHeight) ? vEl.videoHeight : 1920;
        return { deviceId, groupId: 'piloto-automatico-ia', facingMode: [], width: { min: 1, max: w }, height: { min: 1, max: h }, frameRate: { min: 1, max: 30 } };
      },
      getSettings() { return { deviceId, groupId: 'piloto-automatico-ia' }; },
    });
    // injeta SEMPRE (mesmo quando o toggle esta off): o TikTok pode chamar
    // enumerateDevices UMA vez ao abrir o modal e cachear o resultado. Se
    // dependessemos de ativo() e ainda nao tivesse recebido a config,
    // ficariamos fora da lista pra sempre. Se o usuario escolher nosso
    // device sem ter ligado o toggle, o getUserMedia remove o deviceId
    // falso e cai na webcam real.
    const wrappedEnum = function () {
      return origEnum().then((lista) => {
        try {
          const reais = (Array.isArray(lista) ? lista : []).filter((d) => d && d.deviceId !== VCAM_DEV_ID && d.deviceId !== VCAM_MIC_ID);
          const nossos = [
            fakeDev(VCAM_DEV_ID, 'videoinput', VCAM_LABEL),
            fakeDev(VCAM_MIC_ID, 'audioinput', VMIC_LABEL),
          ];
          return nossos.concat(reais);
        } catch (_) { return lista; }
      }).catch((e) => {
        return [
          fakeDev(VCAM_DEV_ID, 'videoinput', VCAM_LABEL),
          fakeDev(VCAM_MIC_ID, 'audioinput', VMIC_LABEL),
        ];
      });
    };
    try { md.enumerateDevices = wrappedEnum; }
    catch (_) { try { Object.defineProperty(md, 'enumerateDevices', { value: wrappedEnum, configurable: true, writable: true }); } catch (__) {} }
  }
})();
