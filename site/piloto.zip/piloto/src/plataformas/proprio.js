/*
 * plataformas/proprio.js — adapter GENERICO pro seu site.
 *
 * Voce configura em cfg.proprio.{baseUrl, endpoints, headers}. Toda chamada
 * eh um POST JSON simples no seu backend, que decide o que fazer.
 *
 * Ativa se: (1) location bate cfg.proprio.host, OU (2) cfg.plataforma === 'proprio'
 * (mesmo com host diferente — util pra painel remoto acionando site parceiro).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});

  function pegarCfg() {
    const cfg = CL.cfg && CL.cfg();
    return (cfg && cfg.proprio) || {};
  }

  function deveAtivar() {
    const cfg = CL.cfg && CL.cfg();
    if (!cfg) return false;
    if (cfg.plataforma === 'proprio') return true;
    const pcfg = cfg.proprio || {};
    if (!pcfg.host) return false;
    try { return location.hostname.indexOf(pcfg.host) >= 0; } catch (_) { return false; }
  }

  async function chamar(rota, corpo) {
    const cfg = pegarCfg();
    const base = (cfg.baseUrl || '').replace(/\/$/, '');
    const path = (cfg.endpoints && cfg.endpoints[rota]) || '/' + rota;
    if (!base) return null;
    try {
      const r = await fetch(base + path, {
        method: 'POST',
        headers: Object.assign({ 'content-type': 'application/json' }, cfg.headers || {}),
        body: JSON.stringify(corpo || {}),
      });
      if (!r.ok) return null;
      return await r.json().catch(() => null);
    } catch (_) { return null; }
  }

  const adapter = {
    nome: 'proprio',
    async postarChat(texto) {
      const r = await chamar('postarChat', { texto });
      return !!(r && r.ok);
    },
    async fixar(productId) {
      const r = await chamar('fixar', { productId });
      return !!(r && r.ok);
    },
    async fixarLista(ids) {
      const r = await chamar('fixarLista', { ids });
      return !!(r && r.ok);
    },
    async desfixar() {
      const r = await chamar('desfixar', {});
      return !!(r && r.ok);
    },
    async recolocarKit(setId) {
      const r = await chamar('recolocarKit', { setId });
      return !!(r && r.ok);
    },
    async encerrarLive() {
      const r = await chamar('encerrarLive', {});
      return !!(r && r.ok);
    },
    async lerViolacoes() {
      const r = await chamar('lerViolacoes', {});
      return (r && r.data) || null;
    },
    async bloquearUsuario(userId, motivo) {
      const r = await chamar('bloquearUsuario', { userId, motivo });
      return !!(r && r.ok);
    },
    async ajustarChat(aberto) {
      const r = await chamar('ajustarChat', { aberto: !!aberto });
      return !!(r && r.ok);
    },
    async iniciarLive() {
      const r = await chamar('iniciarLive', {});
      return !!(r && r.ok);
    },
  };

  // registra se a config pedir (o content.js pode chamar reavaliar quando a cfg mudar)
  function talvezRegistrar() {
    if (!deveAtivar()) return;
    // so' sobrescreve se ainda nao ha adapter (nao pisa em TikTok Shop se tudo bater)
    if (!CL.plataforma || CL.plataforma.nome === 'desconhecida') CL.plataforma = adapter;
    else if (CL.cfg().plataforma === 'proprio') CL.plataforma = adapter; // vendedor pediu explicitamente
  }
  if (CL.onCfgChange) CL.onCfgChange(talvezRegistrar);
  talvezRegistrar();
})();
