/*
 * plataformas/tiktok-live.js — adapter do TikTok Live regular (nao-Shop).
 *
 * Nao tem vitrine/kit/fixar. So chat + moderacao + encerrar. Usa endpoints
 * do webcast, quando disponiveis pela pagina, via ponte assinada.
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  const h = location.hostname;
  const p = location.pathname;
  // TikTok Live regular: live.tiktok.com/ ou www.tiktok.com/@user/live
  const eLive = h === 'live.tiktok.com' || (/tiktok\.com$/.test(h) && /\/live\/?$/i.test(p));
  if (!eLive) return;

  const roomIdDaTela = () => {
    // TikTok Live tem window.SIGI_STATE.LiveRoom.liveRoomUserInfo.userInfo.roomId em algumas versoes;
    // aqui pega o pathname (/@user/live) como fallback e tenta o meta.
    try {
      const m = document.querySelector('meta[name="room_id"]');
      if (m && m.content) return m.content;
    } catch (_) {}
    return '';
  };

  CL.plataforma = {
    nome: 'tiktok-live',

    async postarChat(texto) {
      const rid = (CL.vida && CL.vida.roomId()) || roomIdDaTela();
      if (!rid) return false;
      const r = await CL.api.call('/webcast/room/chat/', 'POST', { room_id: rid, content: String(texto || '') });
      return CL.api.ok(r);
    },

    async encerrarLive() {
      // fallback DOM: procura o botao "Finalizar" — TikTok Live regular
      // encerra na tela do streamer, nao pela API pub.
      const cand = CL.finder && CL.finder.porTexto('Finalizar transmissão').concat(CL.finder.porTexto('End'));
      if (cand && cand.length) return CL.finder.clicar(cand[0].el);
      return false;
    },

    async bloquearUsuario(userId) {
      const rid = (CL.vida && CL.vida.roomId()) || roomIdDaTela();
      if (!rid || !userId) return false;
      const r = await CL.api.call('/webcast/room/user_block/', 'POST', { room_id: rid, user_id: String(userId) });
      return CL.api.ok(r);
    },

    async iniciarLive() {
      const F = CL.finder;
      if (!F) return false;
      const c = F.porTexto('Ir ao vivo').concat(F.porTexto('Go LIVE'));
      if (c.length) return F.clicar(c[0].el);
      return false;
    },

    async fixar() { return false; },
    async fixarLista() { return false; },
    async desfixar() { return false; },
    async recolocarKit() { return false; },
    async lerViolacoes() { return null; },
    async ajustarChat() { return false; },
  };
})();
