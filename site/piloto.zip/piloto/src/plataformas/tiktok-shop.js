/*
 * plataformas/tiktok-shop.js — adapter do TikTok Shop.
 *
 * Auto-registra CL.plataforma se location.hostname bater. Todas as chamadas
 * saem por CL.api (que vai pela ponte assinada apibridge.js).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  const h = location.hostname;
  if (h !== 'shop.tiktok.com' && h !== 'seller-br.tiktok.com') return;

  CL.plataforma = {
    nome: 'tiktok-shop',

    async postarChat(texto) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('room/chat', 'POST', { room_id: rid, content: String(texto || '') });
      return CL.api.ok(r);
    },

    async fixar(productId) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !productId) return false;
      const r = await CL.api.call('live_product/pin', 'POST', { room_id: rid, product_id: String(productId) });
      return CL.api.ok(r);
    },

    async fixarLista(ids) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !Array.isArray(ids) || !ids.length) return false;
      const r = await CL.api.call('live_product/pin_multiple', 'POST', {
        room_id: rid, product_ids: ids.map(String),
      });
      return CL.api.ok(r);
    },

    async desfixar() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('live_product/unpin', 'POST', { room_id: rid });
      return CL.api.ok(r);
    },

    async recolocarKit(setId) {
      if (!setId) return false;
      const r = await CL.api.call('live_product_set/add', 'POST', { product_set_id: String(setId) });
      return CL.api.ok(r);
    },

    async encerrarLive() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('live/end', 'POST', { room_id: rid });
      return CL.api.ok(r);
    },

    async lerViolacoes() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return null;
      const r = await CL.api.call('/webcast/im/violation_list/', 'POST', { room_id: rid });
      if (!CL.api.ok(r)) return null;
      return (r.data && r.data.data) || null;
    },

    async bloquearUsuario(userId, motivo) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !userId) return false;
      const r = await CL.api.call('room/user/kick_out', 'POST', {
        room_id: rid, user_id: String(userId), reason: String(motivo || '').slice(0, 100),
      });
      return CL.api.ok(r);
    },

    async ajustarChat(aberto) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('room/basic_settings/update', 'POST', {
        room_id: rid, live_source: 3,
        settings: { comment_switch_setting: { chat: aberto ? 1 : 2 } },
      });
      return CL.api.ok(r);
    },

    // sobe a live pela UI (clica "Iniciar LIVE"). API pura pra criar sala existe
    // mas exige varias assinaturas; clique cobre a maioria dos casos.
    async iniciarLive() {
      const F = CL.finder;
      if (!F) return false;

      // 1. Acha e clica no botao "Iniciar live" AZUL do dashboard
      const clicouAzul = clicarBotaoIniciarLiveAzul(F);
      if (!clicouAzul) return false;

      // 2. Aguarda modal "Configuracoes de audio e video" e auto-preenche
      autoPreencherModal(F).catch(() => {});
      return true;
    },
  };

  function clicarBotaoIniciarLiveAzul(F) {
    // BOTAO CERTO: o VERDE do Console de LIVE (perto dos toggles Video/Roteiro) — o que
    // abre o modal "Configuracoes de audio e video". IGNORA o vermelho "Iniciar LIVE agora"
    // do canto superior esquerdo (que abre outro fluxo sem modal, e e' o principal motivo
    // do modal nao abrir quando clicamos).
    const clicaveis = document.querySelectorAll('button,[role="button"],a,[tabindex]');
    // fase 1: acha TODOS os candidatos com texto "Iniciar LIVE" (exato ou contem)
    const candidatos = [];
    for (const el of clicaveis) {
      if (!F.visivel(el)) continue;
      const t = (el.innerText || el.textContent || '').trim();
      if (!t || t.length > 40) continue;
      const tLow = t.toLowerCase();
      // IGNORA "Iniciar LIVE agora" (outro fluxo — vermelho, canto superior esquerdo)
      if (tLow.includes('agora') || tLow.includes('now')) continue;
      // aceita "Iniciar LIVE" exato ou variantes proximas
      if (/^(iniciar|start|go)\s+live$/i.test(t)) {
        candidatos.push({ el, texto: t, score: 10 });
      } else if (tLow.includes('iniciar live') || tLow.includes('start live')) {
        candidatos.push({ el, texto: t, score: 5 });
      }
    }
    if (!candidatos.length) return false;
    // fase 2: prioriza pelo ESCOPO — botao dentro do console de LIVE (perto de "Console de LIVE",
    // "Video", "Roteiro") tem score alto. Distancia do topo da pagina tambem serve: o vermelho
    // fica no header do menu lateral (top < 100px), o verde fica na area central.
    for (const c of candidatos) {
      const r = c.el.getBoundingClientRect();
      if (r.top > 150) c.score += 5; // fora do header do menu lateral
      // busca ancoras de contexto proximas (mesma linha/regiao)
      let anc = c.el;
      for (let i = 0; i < 8 && anc; i++) {
        anc = anc.parentElement;
        if (!anc) break;
        const txt = (anc.textContent || '').toLowerCase();
        if (txt.length > 500) break;
        if (txt.includes('roteiro') || txt.includes('vídeo')) { c.score += 8; break; }
      }
    }
    candidatos.sort((a, b) => b.score - a.score);
    for (const c of candidatos) {
      if (F.clicar(c.el)) return true;
    }
    return false;
  }

  // aguarda uma condicao virar true, ate timeoutMs; retorna o resultado
  function aguardar(fn, timeoutMs, intervalMs) {
    return new Promise((res) => {
      const t0 = Date.now();
      const iv = setInterval(() => {
        let v;
        try { v = fn(); } catch (_) { v = null; }
        if (v) { clearInterval(iv); res(v); return; }
        if (Date.now() - t0 > timeoutMs) { clearInterval(iv); res(null); }
      }, intervalMs || 200);
    });
  }

  // normaliza texto (sem acentos, minusculas, espacos colapsados)
  function norm(s) {
    return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '')
      .toLowerCase().replace(/\s+/g, ' ').trim();
  }

  // acha o container clicavel do dropdown associado a um label
  // ("Fonte de vídeo" / "Fonte de áudio"). TikTok usa Arco Design.
  function acharDropdownDoLabel(labelNorm) {
    const nos = Array.from(document.querySelectorAll('div,span,label,p'));
    for (const n of nos) {
      if (n.children.length > 3) continue; // pega folha ou linha curta
      const t = norm(n.innerText || n.textContent);
      if (t !== labelNorm) continue;
      // procura o combobox/select mais proximo (irmao, sobrinho ou ancestral proximo)
      let cur = n;
      for (let i = 0; i < 8 && cur; i++) {
        cur = cur.parentElement;
        if (!cur) break;
        // Arco Design usa .arco-select-view como container clicavel
        const cand = cur.querySelector('.arco-select-view, .arco-select, [role="combobox"], [class*="select-view" i]');
        if (cand) return cand;
      }
    }
    return null;
  }

  // clica numa opcao do dropdown aberto por texto (Arco: .arco-select-option)
  function clicarOpcao(F, matcher) {
    const opcoes = document.querySelectorAll('.arco-select-option, [role="option"], li[class*="option" i]');
    for (const op of opcoes) {
      if (!F.visivel(op)) continue;
      const t = (op.innerText || op.textContent || '').trim();
      if (matcher(t)) {
        if (F.clicar(op)) return true;
      }
    }
    return false;
  }

  async function autoPreencherModal(F) {
    const feed = (m) => { try { CL.portas.feed('tempo', m); } catch (_) {} };
    // labels normalizados (sem acento, minusculas)
    const LABEL_VIDEO = norm('Fonte de vídeo'); // 'fonte de video'
    const LABEL_AUDIO = norm('Fonte de áudio'); // 'fonte de audio'

    // aguarda o modal aparecer
    const dropVideo = await aguardar(() => acharDropdownDoLabel(LABEL_VIDEO), 6000);
    if (!dropVideo) {
      feed('✗ Modal aberto mas nao achei o dropdown "Fonte de video" — preencha manual');
      return;
    }
    feed('Preenchendo campos automaticamente...');

    // 1. Video: abre o dropdown, escolhe Simulive
    F.clicar(dropVideo);
    await new Promise((r) => setTimeout(r, 500));
    let ok = clicarOpcao(F, (t) => /simulive|piloto automatico/i.test(t));
    if (!ok) {
      await new Promise((r) => setTimeout(r, 600));
      F.clicar(dropVideo);
      await new Promise((r) => setTimeout(r, 500));
      ok = clicarOpcao(F, (t) => /simulive|piloto automatico/i.test(t));
    }
    if (!ok) feed('✗ Simulive nao apareceu na lista de fontes de video');

    // 2. Audio: escolhe "Piloto Automatico IA — Audio do video"
    await new Promise((r) => setTimeout(r, 600));
    const dropAudio = acharDropdownDoLabel(LABEL_AUDIO);
    if (dropAudio) {
      F.clicar(dropAudio);
      await new Promise((r) => setTimeout(r, 500));
      const okAudio = clicarOpcao(F, (t) => /piloto automatico|audio do video|áudio do vídeo/i.test(t));
      if (!okAudio) {
        clicarOpcao(F, (t) => t && !/selecionar/i.test(t) && t.length > 0);
      }
    }

    // NAO clica no "Iniciar LIVE" verde — deixa o vendedor conferir a preview
    feed('✓ Fontes preenchidas — confira a pré-visualização e clique "Iniciar LIVE" verde');
  }
})();
