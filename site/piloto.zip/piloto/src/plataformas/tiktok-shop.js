/*
 * plataformas/tiktok-shop.js — adapter do TikTok Shop.
 *
 * Auto-registra CL.plataforma se location.hostname bater. Todas as chamadas
 * saem por CL.api (que vai pela ponte assinada apibridge.js).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  const h = location.hostname;
  if (h !== 'shop.tiktok.com' && h !== 'seller-br.tiktok.com') return;

  CL.plataforma = {
    nome: 'tiktok-shop',

    async postarChat(texto) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('room/chat', 'POST', { room_id: rid, content: String(texto || '') });
      return CL.api.ok(r);
    },

    async fixar(productId) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !productId) return false;
      const r = await CL.api.call('live_product/pin', 'POST', { room_id: rid, product_id: String(productId) });
      return CL.api.ok(r);
    },

    async fixarLista(ids) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !Array.isArray(ids) || !ids.length) return false;
      const r = await CL.api.call('live_product/pin_multiple', 'POST', {
        room_id: rid, product_ids: ids.map(String),
      });
      return CL.api.ok(r);
    },

    async desfixar() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('live_product/unpin', 'POST', { room_id: rid });
      return CL.api.ok(r);
    },

    async recolocarKit(setId) {
      if (!setId) return false;
      const r = await CL.api.call('live_product_set/add', 'POST', { product_set_id: String(setId) });
      return CL.api.ok(r);
    },

    async encerrarLive() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('live/end', 'POST', { room_id: rid });
      return CL.api.ok(r);
    },

    async lerViolacoes() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return null;
      const r = await CL.api.call('/webcast/im/violation_list/', 'POST', { room_id: rid });
      if (!CL.api.ok(r)) return null;
      return (r.data && r.data.data) || null;
    },

    async bloquearUsuario(userId, motivo) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !userId) return false;
      const r = await CL.api.call('room/user/kick_out', 'POST', {
        room_id: rid, user_id: String(userId), reason: String(motivo || '').slice(0, 100),
      });
      return CL.api.ok(r);
    },

    async ajustarChat(aberto) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('room/basic_settings/update', 'POST', {
        room_id: rid, live_source: 3,
        settings: { comment_switch_setting: { chat: aberto ? 1 : 2 } },
      });
      return CL.api.ok(r);
    },

    // sobe a live pela UI (clica "Iniciar LIVE"). API pura pra criar sala existe
    // mas exige varias assinaturas; clique cobre a maioria dos casos.
    async iniciarLive() {
      const F = CL.finder;
      if (!F) return false;

      // 1. Tenta por seletores especificos do TikTok primeiro
      const seletores = [
        'button[data-e2e*="start-live"]',
        'button[data-e2e*="go-live"]',
        'button[data-e2e*="startLive"]',
        '[data-e2e*="live-start"]',
        'button[class*="start-live" i]',
        'button[class*="StartLive"]',
      ];
      for (const sel of seletores) {
        const el = document.querySelector(sel);
        if (el && F.visivel && F.visivel(el)) {
          if (F.clicar(el)) return true;
        }
      }

      // 2. Busca por texto — varias variacoes + contains (nao so exact)
      const queries = ['Iniciar LIVE', 'Iniciar live', 'INICIAR LIVE', 'Start LIVE', 'Go LIVE', 'GO LIVE'];
      const clicaveis = document.querySelectorAll('button,[role="button"],a,[tabindex]');
      for (const el of clicaveis) {
        if (F.visivel && !F.visivel(el)) continue;
        const t = (el.innerText || el.textContent || '').trim();
        for (const q of queries) {
          if (t === q || t.toLowerCase() === q.toLowerCase()) {
            if (F.clicar(el)) return true;
          }
        }
        // contains: se o botao tem texto "Iniciar LIVE" no meio (com icone/etc)
        const tLow = t.toLowerCase();
        if ((tLow.includes('iniciar live') || tLow.includes('iniciar l') && tLow.includes('ive'))
            && t.length < 40) {
          if (F.clicar(el)) return true;
        }
      }

      return false;
    },
  };
})();
