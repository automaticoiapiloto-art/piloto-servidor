/*
 * plataformas/tiktok-shop.js — adapter do TikTok Shop.
 *
 * Auto-registra CL.plataforma se location.hostname bater. Todas as chamadas
 * saem por CL.api (que vai pela ponte assinada apibridge.js).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  const h = location.hostname;
  if (h !== 'shop.tiktok.com' && h !== 'seller-br.tiktok.com') return;

  CL.plataforma = {
    nome: 'tiktok-shop',

    async postarChat(texto) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('room/chat', 'POST', { room_id: rid, content: String(texto || '') });
      return CL.api.ok(r);
    },

    async fixar(productId) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !productId) return false;
      const r = await CL.api.call('live_product/pin', 'POST', { room_id: rid, product_id: String(productId) });
      return CL.api.ok(r);
    },

    async fixarLista(ids) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !Array.isArray(ids) || !ids.length) return false;
      const r = await CL.api.call('live_product/pin_multiple', 'POST', {
        room_id: rid, product_ids: ids.map(String),
      });
      return CL.api.ok(r);
    },

    async desfixar() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('live_product/unpin', 'POST', { room_id: rid });
      return CL.api.ok(r);
    },

    async recolocarKit(setId) {
      if (!setId) return false;
      const r = await CL.api.call('live_product_set/add', 'POST', { product_set_id: String(setId) });
      return CL.api.ok(r);
    },

    async encerrarLive() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('live/end', 'POST', { room_id: rid });
      return CL.api.ok(r);
    },

    async lerViolacoes() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return null;
      const r = await CL.api.call('/webcast/im/violation_list/', 'POST', { room_id: rid });
      if (!CL.api.ok(r)) return null;
      return (r.data && r.data.data) || null;
    },

    async bloquearUsuario(userId, motivo) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !userId) return false;
      const r = await CL.api.call('room/user/kick_out', 'POST', {
        room_id: rid, user_id: String(userId), reason: String(motivo || '').slice(0, 100),
      });
      return CL.api.ok(r);
    },

    async ajustarChat(aberto) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('room/basic_settings/update', 'POST', {
        room_id: rid, live_source: 3,
        settings: { comment_switch_setting: { chat: aberto ? 1 : 2 } },
      });
      return CL.api.ok(r);
    },

    // sobe a live pela UI (clica "Iniciar LIVE"). API pura pra criar sala existe
    // mas exige varias assinaturas; clique cobre a maioria dos casos.
    async iniciarLive() {
      const F = CL.finder;
      if (!F) return false;
      const cand = F.porTexto('Iniciar LIVE').concat(F.porTexto('Iniciar live')).concat(F.porTexto('Iniciar'));
      const primeiro = cand.find((c) => {
        const t = F.texto(c.el, 40).toLowerCase();
        return t.indexOf('live') > -1 || t === 'iniciar';
      });
      if (!primeiro) return false;
      return F.clicar(primeiro.el);
    },
  };
})();
