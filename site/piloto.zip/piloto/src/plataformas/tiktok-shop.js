/*
 * plataformas/tiktok-shop.js — adapter do TikTok Shop.
 *
 * Auto-registra CL.plataforma se location.hostname bater. Todas as chamadas
 * saem por CL.api (que vai pela ponte assinada apibridge.js).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  const h = location.hostname;
  if (h !== 'shop.tiktok.com' && h !== 'seller-br.tiktok.com') return;

  CL.plataforma = {
    nome: 'tiktok-shop',

    async postarChat(texto) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('room/chat', 'POST', { room_id: rid, content: String(texto || '') });
      return CL.api.ok(r);
    },

    async fixar(productId) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !productId) return false;
      const r = await CL.api.call('live_product/pin', 'POST', { room_id: rid, product_id: String(productId) });
      return CL.api.ok(r);
    },

    async fixarLista(ids) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !Array.isArray(ids) || !ids.length) return false;
      const r = await CL.api.call('live_product/pin_multiple', 'POST', {
        room_id: rid, product_ids: ids.map(String),
      });
      return CL.api.ok(r);
    },

    async desfixar() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('live_product/unpin', 'POST', { room_id: rid });
      return CL.api.ok(r);
    },

    async recolocarKit(setId) {
      if (!setId) return false;
      const r = await CL.api.call('live_product_set/add', 'POST', { product_set_id: String(setId) });
      return CL.api.ok(r);
    },

    async encerrarLive() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('live/end', 'POST', { room_id: rid });
      return CL.api.ok(r);
    },

    async lerViolacoes() {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return null;
      const r = await CL.api.call('/webcast/im/violation_list/', 'POST', { room_id: rid });
      if (!CL.api.ok(r)) return null;
      return (r.data && r.data.data) || null;
    },

    async bloquearUsuario(userId, motivo) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid || !userId) return false;
      const r = await CL.api.call('room/user/kick_out', 'POST', {
        room_id: rid, user_id: String(userId), reason: String(motivo || '').slice(0, 100),
      });
      return CL.api.ok(r);
    },

    async ajustarChat(aberto) {
      const rid = CL.vida && CL.vida.roomId();
      if (!rid) return false;
      const r = await CL.api.call('room/basic_settings/update', 'POST', {
        room_id: rid, live_source: 3,
        settings: { comment_switch_setting: { chat: aberto ? 1 : 2 } },
      });
      return CL.api.ok(r);
    },

    // sobe a live pela UI (clica "Iniciar LIVE"). API pura pra criar sala existe
    // mas exige varias assinaturas; clique cobre a maioria dos casos.
    async iniciarLive() {
      const F = CL.finder;
      if (!F) return false;

      // 1. Acha e clica no botao "Iniciar live" AZUL do dashboard
      const clicouAzul = clicarBotaoIniciarLiveAzul(F);
      if (!clicouAzul) return false;

      // 2. Aguarda modal "Configuracoes de audio e video" e auto-preenche
      autoPreencherModal(F).catch(() => {});
      return true;
    },
  };

  function clicarBotaoIniciarLiveAzul(F) {
    // seletores especificos do TikTok
    const seletores = [
      'button[data-e2e*="start-live"]',
      'button[data-e2e*="go-live"]',
      'button[data-e2e*="startLive"]',
      '[data-e2e*="live-start"]',
      'button[class*="start-live" i]',
      'button[class*="StartLive"]',
    ];
    for (const sel of seletores) {
      const el = document.querySelector(sel);
      if (el && F.visivel(el)) {
        if (F.clicar(el)) return true;
      }
    }
    // busca por texto
    const queries = ['Iniciar LIVE', 'Iniciar live', 'INICIAR LIVE', 'Start LIVE', 'Go LIVE', 'GO LIVE'];
    const clicaveis = document.querySelectorAll('button,[role="button"],a,[tabindex]');
    for (const el of clicaveis) {
      if (!F.visivel(el)) continue;
      const t = (el.innerText || el.textContent || '').trim();
      for (const q of queries) {
        if (t.toLowerCase() === q.toLowerCase()) {
          if (F.clicar(el)) return true;
        }
      }
      const tLow = t.toLowerCase();
      if (tLow.includes('iniciar live') && t.length < 40) {
        if (F.clicar(el)) return true;
      }
    }
    return false;
  }

  // aguarda uma condicao virar true, ate timeoutMs; retorna o resultado
  function aguardar(fn, timeoutMs, intervalMs) {
    return new Promise((res) => {
      const t0 = Date.now();
      const iv = setInterval(() => {
        let v;
        try { v = fn(); } catch (_) { v = null; }
        if (v) { clearInterval(iv); res(v); return; }
        if (Date.now() - t0 > timeoutMs) { clearInterval(iv); res(null); }
      }, intervalMs || 200);
    });
  }

  // acha o container clicavel do dropdown associado a um label ("Fonte de video" / "Fonte de audio")
  function acharDropdownDoLabel(label) {
    const nos = Array.from(document.querySelectorAll('div,span,label,p'));
    for (const n of nos) {
      const t = (n.innerText || n.textContent || '').trim();
      if (t === label) {
        // sobe procurando um irmao/descendente com role=combobox ou input
        let cur = n;
        for (let i = 0; i < 6 && cur; i++) {
          const cand = cur.querySelector('[role="combobox"],input,.arco-select,[class*="select" i]');
          if (cand) return cand;
          cur = cur.parentElement;
        }
      }
    }
    return null;
  }

  // clica numa opcao do dropdown aberto por texto
  function clicarOpcao(F, matcher) {
    // procura em elementos com role=option ou li dentro de qualquer dropdown aberto
    const opcoes = document.querySelectorAll('[role="option"],li,.arco-select-option');
    for (const op of opcoes) {
      if (!F.visivel(op)) continue;
      const t = (op.innerText || op.textContent || '').trim();
      if (matcher(t)) {
        if (F.clicar(op)) return true;
      }
    }
    return false;
  }

  async function autoPreencherModal(F) {
    // aguarda o modal aparecer
    const dropVideo = await aguardar(
      () => acharDropdownDoLabel('Fonte de vídeo') || acharDropdownDoLabel('Fonte de video'),
      6000
    );
    if (!dropVideo) return;

    // 1. Video: abre o dropdown, escolhe Simulive
    F.clicar(dropVideo);
    await new Promise((r) => setTimeout(r, 400));
    let ok = clicarOpcao(F, (t) => /simulive|piloto automatico/i.test(t));
    if (!ok) {
      // fecha e tenta de novo depois de um respiro
      await new Promise((r) => setTimeout(r, 600));
      F.clicar(dropVideo);
      await new Promise((r) => setTimeout(r, 400));
      clicarOpcao(F, (t) => /simulive|piloto automatico/i.test(t));
    }

    // 2. Audio: escolhe "Piloto Automatico IA — Audio do video" (audio injetado
    // via Web Audio a partir do arquivo). Fallback pro primeiro microfone real
    // se por algum motivo nosso device de audio nao aparecer na lista.
    await new Promise((r) => setTimeout(r, 500));
    const dropAudio = acharDropdownDoLabel('Fonte de áudio') || acharDropdownDoLabel('Fonte de audio');
    if (dropAudio) {
      F.clicar(dropAudio);
      await new Promise((r) => setTimeout(r, 400));
      const okAudio = clicarOpcao(F, (t) => /piloto automatico|áudio do vídeo|audio do video/i.test(t));
      if (!okAudio) {
        clicarOpcao(F, (t) => t && !/selecionar/i.test(t) && t.length > 0);
      }
    }

    // 3. Aguarda 2s e clica no botao "Iniciar LIVE" VERDE dentro do modal
    await new Promise((r) => setTimeout(r, 2000));
    const clicaveis = document.querySelectorAll('button,[role="button"]');
    for (const el of clicaveis) {
      if (!F.visivel(el)) continue;
      const t = (el.innerText || el.textContent || '').trim();
      if (/^iniciar live$/i.test(t) && el.getBoundingClientRect().top > 100) {
        if (F.clicar(el)) return;
      }
    }
  }
})();
