/*
 * plataformas/youtube.js — adapter do YouTube Studio Live.
 *
 * YouTube Live nao tem vitrine/fixar. Chat sai pelo DOM (o campo do proprio
 * streamer no studio.youtube.com/live). Moderacao/encerrar via UI tambem.
 *
 * Sem API oficial aqui (a LiveChat API exige OAuth server-side; usar DOM
 * fica mais robusto e sem servidor).
 */
;(function () {
  'use strict';
  const CL = (self.CL = self.CL || {});
  const h = location.hostname;
  if (!/youtube\.com$/.test(h)) return;
  if (h.indexOf('studio.youtube.com') < 0 && h.indexOf('www.youtube.com') < 0) return;

  function acharCampoChat() {
    // studio.youtube.com/live: contenteditable com placeholder tipo "Send a message..."
    const c = document.querySelectorAll('div[contenteditable="true"]');
    for (const el of c) {
      const ph = el.getAttribute('aria-label') || el.getAttribute('placeholder') || '';
      if (/mens|send|chat/i.test(ph)) return el;
    }
    return null;
  }

  function acharBotaoEnviar() {
    const b = document.querySelectorAll('button, [role="button"]');
    for (const el of b) {
      const t = (el.textContent || '').trim();
      const al = el.getAttribute('aria-label') || '';
      if (/enviar|send/i.test(t) || /enviar|send/i.test(al)) return el;
    }
    return null;
  }

  CL.plataforma = {
    nome: 'youtube',

    async postarChat(texto) {
      const campo = acharCampoChat();
      if (!campo) return false;
      try {
        campo.focus();
        // fake typing via InputEvent (respeita content-editable + react-controlled)
        const t = String(texto || '');
        campo.innerText = t;
        campo.dispatchEvent(new InputEvent('input', { bubbles: true, data: t }));
        await new Promise((r) => setTimeout(r, 200));
        const b = acharBotaoEnviar();
        if (b) return CL.finder.clicar(b);
        // fallback: Enter
        campo.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
        return true;
      } catch (_) { return false; }
    },

    async encerrarLive() {
      const cands = CL.finder.porTexto('Finalizar transmissão').concat(CL.finder.porTexto('End stream'));
      if (cands.length) return CL.finder.clicar(cands[0].el);
      return false;
    },

    async bloquearUsuario(_userId) {
      // YouTube nao tem API publica de kick pelo usuario no chat da conta do
      // dono da live. Motor de moderacao vai chamar por texto e aqui devolve
      // false — moderacao publica um aviso no feed pro streamer bloquear na mao.
      return false;
    },

    async iniciarLive() {
      const F = CL.finder;
      if (!F) return false;
      const c = F.porTexto('Iniciar transmissão').concat(F.porTexto('Go live'));
      if (c.length) return F.clicar(c[0].el);
      return false;
    },

    async fixar() { return false; },
    async fixarLista() { return false; },
    async desfixar() { return false; },
    async recolocarKit() { return false; },
    async lerViolacoes() { return null; },
    async ajustarChat() { return false; },
  };
})();
