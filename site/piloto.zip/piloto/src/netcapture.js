/*
 * netcapture.js — grampo passivo de fetch/XHR/WebSocket (world: MAIN, document_start).
 *
 * NAO altera as chamadas. So OBSERVA: quando a pagina fala com a API do TikTok
 * (ou o WebSocket da live traz frames binarios), a gente publica um evento
 * pro content script pelo canal __pt_netcap ({url, method, status, body, resp}).
 *
 * Ignora recursos de midia (imagem/css/js/fonte). So captura chamadas de DADOS.
 * Nao captura headers (evita gravar token/cookie).
 *
 * WebSocket: quando ligado, publica frames binarios em __pt_livefeed pro
 * coletor-ws decodificar. Sem custo quando desligado (wrapper que apenas
 * repassa).
 */
;(function () {
  'use strict';

  const TAG = 'PT_NETCAP';
  let habilitado = false;
  let feedAtivo = false;
  let token = '';

  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    if (ev.data.__pt_capctl) {
      habilitado = !!ev.data.enabled;
      feedAtivo = !!ev.data.feed;
      if (typeof ev.data.token === 'string') token = ev.data.token;
    }
  });

  function publicar(entrada) {
    if (!token) return;
    try {
      window.postMessage({ __pt_netcap: true, tag: TAG, token, entry: entrada }, location.origin);
    } catch (_) {}
  }
  function publicarLive(dados) {
    if (!token) return;
    try {
      window.postMessage({ __pt_livefeed: true, token, dados }, location.origin);
    } catch (_) {}
  }

  function absURL(u) {
    try { return new URL(u, location.href).href; } catch (_) { return String(u || ''); }
  }
  function corta(s, max) {
    if (typeof s !== 'string') return '';
    max = max || 6000;
    return s.length > max ? s.slice(0, max) + '...[cortado]' : s;
  }
  function interessante(url) {
    if (typeof url !== 'string') return false;
    if (!url) return false;
    // pula midia/estatico
    if (/\.(png|jpg|jpeg|gif|webp|svg|css|js|woff2?|mp4|m3u8|ts)(\?|$)/i.test(url)) return false;
    // interessa: /api/... /webcast/... /pack/... (endpoints do TikTok)
    return /(\/api\/|\/webcast\/|\/pack\/)/i.test(url);
  }

  // ---------- grampo: fetch ----------
  const origFetch = window.fetch ? window.fetch.bind(window) : null;
  if (origFetch) {
    window.fetch = async function (input, init) {
      if (!habilitado) return origFetch(input, init);
      const url = absURL(typeof input === 'string' ? input : (input && input.url));
      const method = (init && init.method) || (input && input.method) || 'GET';
      let bodyEnv = '';
      if (init && init.body) {
        try { bodyEnv = typeof init.body === 'string' ? init.body : ''; } catch (_) {}
      }
      const r = await origFetch(input, init);
      if (interessante(url)) {
        // clona pra nao consumir o body do consumidor
        try {
          const clone = r.clone();
          const ct = clone.headers.get('content-type') || '';
          if (ct.indexOf('application/json') >= 0 || ct.indexOf('text') >= 0) {
            clone.text().then((txt) => {
              publicar({ tipo: 'fetch', url, method, status: r.status, body: corta(bodyEnv, 3000), resp: corta(txt, 8000) });
            }).catch(() => {});
          } else {
            publicar({ tipo: 'fetch', url, method, status: r.status, body: corta(bodyEnv, 3000), resp: '' });
          }
        } catch (_) {}
      }
      return r;
    };
  }

  // ---------- grampo: XMLHttpRequest ----------
  try {
    const OrigXHR = window.XMLHttpRequest;
    const proto = OrigXHR.prototype;
    const origOpen = proto.open;
    const origSend = proto.send;
    proto.open = function (method, url) {
      this.__pt_url = absURL(url);
      this.__pt_method = method;
      return origOpen.apply(this, arguments);
    };
    proto.send = function (body) {
      if (habilitado && interessante(this.__pt_url)) {
        const bodyStr = typeof body === 'string' ? body : '';
        this.addEventListener('loadend', () => {
          try {
            let resp = '';
            const rt = this.responseType;
            if (!rt || rt === 'text' || rt === '') resp = this.responseText || '';
            else if (rt === 'json') { try { resp = JSON.stringify(this.response); } catch (_) {} }
            publicar({ tipo: 'xhr', url: this.__pt_url, method: this.__pt_method, status: this.status, body: corta(bodyStr, 3000), resp: corta(resp, 8000) });
          } catch (_) {}
        });
      }
      return origSend.apply(this, arguments);
    };
  } catch (_) {}

  // ---------- grampo: WebSocket ----------
  try {
    const OrigWS = window.WebSocket;
    if (OrigWS) {
      window.WebSocket = function (url, protocols) {
        const s = protocols === undefined ? new OrigWS(url) : new OrigWS(url, protocols);
        try {
          s.addEventListener('message', (ev) => {
            if (!feedAtivo) return;
            // frames binarios da live vem como ArrayBuffer/Blob
            if (ev.data instanceof ArrayBuffer) {
              // publica cru — o coletor-ws parseia o envelope + protobuf
              publicarLive({ tipo: 'ws-bin', bytes: Array.from(new Uint8Array(ev.data)) });
            } else if (typeof ev.data === 'string') {
              publicarLive({ tipo: 'ws-txt', texto: ev.data.slice(0, 8000) });
            }
          });
        } catch (_) {}
        return s;
      };
      window.WebSocket.prototype = OrigWS.prototype;
      Object.setPrototypeOf(window.WebSocket, OrigWS);
    }
  } catch (_) {}
})();
