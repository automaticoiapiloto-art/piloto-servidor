# Piloto Automático IA — Extensão

Extensão Chrome MV3. Cliente-side: painel lateral, motores de automação, câmera virtual, netcapture, coletores e adaptadores multi-plataforma.

## Instalar (dev)

1. `chrome://extensions` → **Modo desenvolvedor** → **Carregar sem compactação**
2. Selecione esta pasta (`piloto/`)
3. Clique no ícone (robozinho azul) → painel abre

## Arquitetura

```
src/
├── background.js             service worker (feed, notif, httpProxy, alarmes)
├── content.js                COLA — inicia motores, ponte com vcam, diag pro painel
├── apibridge.js              (world: MAIN) fetch assinado da página do TikTok
├── vcam.js                   (world: MAIN) grampeia getUserMedia → vídeo em vez da webcam
├── netcapture.js             (world: MAIN) passivo — grampeia fetch/XHR/WebSocket
├── finder.js                 achar+clicar elementos resistente a classes embaralhadas
├── storage.js                CL.cfg / CL.setCfg — schema completo em piloto_config_v1
├── license.js                cliente do servidor de licença (Ed25519 offline)
├── popup.html/css/js         painel lateral (7 abas + onboarding + indicadores)
├── nucleo/
│   ├── barramento.js         pub/sub minimal — canais: sala, vitrine, atividade, stats,
│   │                                              tela:chat, oficial, vida, licenca, etc
│   ├── vida.js               CL.vida — aoVivo(), pausado(), roomId(), IS_TOP, licBloqueada()
│   ├── plano.js              CL.plano — decide feature por plano (basico/pro/premium)
│   ├── portas.js             CL.portas — ÚNICA camada que age na conta (chat/fixar/etc)
│   ├── transporte.js         CL.api — fala com apibridge (mundo da página)
│   ├── texto.js              funções puras — precoBR, normalizar, nomeSeguro, renderTemplate
│   ├── coletor-room.js       poll live_room_info (roomId, status, gmv/itens/viewers)
│   ├── coletor-vitrine.js    poll live_product/list (sacolinha)
│   ├── coletor-ws.js         ponte com netcapture — parse de frames binários
│   └── coletor-tela.js       MutationObserver no chat (reserva quando ws falha)
├── plataformas/              cada arquivo se auto-registra se location bater
│   ├── tiktok-shop.js
│   ├── tiktok-live.js
│   ├── youtube.js
│   └── proprio.js            genérico — cfg.proprio.baseUrl aponta pro seu backend
└── motores/                  auto-registrados no barramento
    ├── fixador.js            fixar produto (um / lista / piscar / aleatório)
    ├── mensagens.js          mensagens programadas em intervalo aleatório
    ├── respostas.js          Q&A por gatilho no chat
    ├── oferta.js             oferta relâmpago (recria via UI quando encerra)
    ├── carrinho.js           aviso "{nome} adicionou ao carrinho"
    ├── venda-chat.js         aviso "Vendido para {nome}"
    ├── tempo-live.js         cronômetro + auto-end + auto-start (simulive)
    ├── dinheiro.js           conta vendas + soma GMV + reconcilia com oficial
    ├── vitrine-kit.js        recoloca kit ao fim da live
    ├── chat-liberado.js      liga/desliga comentários da live
    ├── espelho.js            POST estado a cada 3s pro PWA (via httpProxy)
    ├── guardiao-aviso.js     poll violation_list — só ALERTA, não encerra
    └── moderacao.js          modera por comportamento (palavrão/spam), nunca por identidade
```

## Regras de ouro

1. **Motor nunca age direto na conta.** Vai por `CL.portas.chat/fixar/etc` — é lá que as travas de licença/pausa moram.
2. **Coletor não decide.** Ele PUBLICA (`vitrine`, `atividade`, `sala`). Motor decide se age.
3. **Adapter de plataforma se auto-registra.** Cada arquivo em `plataformas/` só sobrescreve `CL.plataforma` se `location` bater.
4. **Fila de chat global.** `CL.portas.chat` tem gap de 1s + 3 retries com 4s de respiro.
5. **Fail-open na licença.** Servidor caído não trava live.

## Config (piloto_config_v1)

Toda config vive em `chrome.storage.local` sob a chave `piloto_config_v1`. Schema completo em [`src/storage.js`](src/storage.js).

Campos principais:
- `plataforma` — `tiktok-shop | tiktok-live | youtube | proprio`
- `licenca.servidor` — URL do seu servidor (dev: `http://localhost:8443`)
- `licenca.plano` — atualizado pelo servidor (`trial|basico|pro|premium|dev`)
- `rePin`, `chat.broadcast`, `chat.qa`, `chat.saleAlert`, `chat.cartAlert`
- `vcam`, `autoStart.series` (simulive), `autoEnd`
- `espelho.pin`, `moderacao.palavras`
- `proprio.baseUrl/endpoints/headers` — pro adapter do seu site

## Publicar na Chrome Web Store

1. Zip a pasta `piloto/` (sem `.git`, `README.md` opcional)
2. Registre uma conta de developer Chrome ($5 uma vez)
3. Upload em https://chrome.google.com/webstore/devconsole
4. Preencha screenshots, descrição, política de privacidade
5. Depois de publicada, atualize `Caddyfile` do servidor pra permitir CORS do `chrome-extension://<id-real>`

## Espelho no celular (PWA)

Fica em [`espelho-pwa/`](espelho-pwa/). O comprador acessa a URL onde você hospeda esse HTML, faz "Adicionar à tela inicial" no Chrome do celular, e vira app.

Você pode hospedar em:
- Netlify/Vercel (grátis, alguns cliques)
- Junto do próprio servidor Node (basta servir `espelho-pwa/` como estático)
